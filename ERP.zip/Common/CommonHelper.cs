﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Common
{
    public class CommonHelper
    {
        public static bool CheckPositionIsStaff(int titleID)
        {
            bool isStaff = false;
            if (titleID.Equals((int)Config.PositionTitle.Staff) ||
                titleID.Equals((int)Config.PositionTitle.Cashier) ||
                titleID.Equals((int)Config.PositionTitle.Purchase) ||
                titleID.Equals((int)Config.PositionTitle.NetworkManagement) ||
                titleID.Equals((int)Config.PositionTitle.CashierLeader))
            {
                isStaff = true;
            }
            return isStaff;
        }

        public static bool CheckPositionIsDirector(int titleID)
        {
            bool isDirector = false;
            if (titleID.Equals((int)Config.PositionTitle.DD) ||
                titleID.Equals((int)Config.PositionTitle.AD) ||
                titleID.Equals((int)Config.PositionTitle.HRD) || 
                titleID.Equals((int)Config.PositionTitle.NCD) || 
                titleID.Equals((int)Config.PositionTitle.CashierManagement) ||
                titleID.Equals((int)Config.PositionTitle.TD) ||
                titleID.Equals((int)Config.PositionTitle.CD))
            {
                isDirector = true;
            }
            return isDirector;
        }

        public static List<int> CheckPositionAttendance()
        {
            List<int> list = new List<int>();
            list.Add((int)Config.PositionTitle.Staff);
            list.Add((int)Config.PositionTitle.Cashier);
            list.Add((int)Config.PositionTitle.Purchase);
            list.Add((int)Config.PositionTitle.NetworkManagement);
            list.Add((int)Config.PositionTitle.CashierLeader);
            //list.Add((int)Config.PositionTitle.CashierManagement);
            list.Add((int)Config.PositionTitle.DM);
            list.Add((int)Config.PositionTitle.FunctionalDH);
            return list;
        }

        public static List<int> CheckPositionDirectorAttendance()
        {
            List<int> list = new List<int>();
            list.Add((int)Config.PositionTitle.DD);
            list.Add((int)Config.PositionTitle.AD);
            list.Add((int)Config.PositionTitle.HRD);
            list.Add((int)Config.PositionTitle.NCD);
            list.Add((int)Config.PositionTitle.CashierManagement);
            list.Add((int)Config.PositionTitle.TD);
            list.Add((int)Config.PositionTitle.CD);
            return list;
        }

        public static bool CheckPositionIsSpecialDirector(int titleID)
        {
            bool isDirector = false;
            if (titleID.Equals((int)Config.PositionTitle.FunctionalDH) ||
                titleID.Equals((int)Config.PositionTitle.AD) ||
                titleID.Equals((int)Config.PositionTitle.HRD) || 
                titleID.Equals((int)Config.PositionTitle.NCD) || 
                titleID.Equals((int)Config.PositionTitle.GMOOperations) ||
                titleID.Equals((int)Config.PositionTitle.GMOManagement) ||
                titleID.Equals((int)Config.PositionTitle.CashierManagement) ||
                titleID.Equals((int)Config.PositionTitle.TD) ||
                titleID.Equals((int)Config.PositionTitle.CD))
            {
                isDirector = true;
            }
            return isDirector;
        }

        public static int GetChineseNumber(string name)
        {
            if (string.IsNullOrEmpty(name)) return 0;
            else if (name.IndexOf("十九") >= 0) return 19;
            else if (name.IndexOf("十八") >= 0) return 18;
            else if (name.IndexOf("十七") >= 0) return 17;
            else if (name.IndexOf("十六") >= 0) return 16;
            else if (name.IndexOf("十五") >= 0) return 15;
            else if (name.IndexOf("十四") >= 0) return 14;
            else if (name.IndexOf("十三") >= 0) return 13;
            else if (name.IndexOf("十二") >= 0) return 12;
            else if (name.IndexOf("十一") >= 0) return 11;
            else if (name.IndexOf("十") >= 0) return 10;
            else if (name.IndexOf("九") >= 0) return 9;
            else if (name.IndexOf("八") >= 0) return 8;
            else if (name.IndexOf("七") >= 0) return 7;
            else if (name.IndexOf("六") >= 0) return 6;
            else if (name.IndexOf("五") >= 0) return 5;
            else if (name.IndexOf("四") >= 0) return 4;
            else if (name.IndexOf("三") >= 0) return 3;
            else if (name.IndexOf("二") >= 0) return 2;
            else if (name.IndexOf("一") >= 0) return 1;
            return 0;
        }

        public static string StaffNumberLength(int StaffNumber)
        {
            var length = StaffNumber.ToString().Length;
            string number = "";

            if (length < 5)
            {
                for (int i = 0; i < (5 - length); i++)
                {
                    number += "0";
                }
                number += StaffNumber.ToString();
            }
            return number;
        }

        public static bool CheckPositionIsAllDirector(int titleID)
        {
            bool isDirector = false;
            if (titleID.Equals((int)Config.PositionTitle.DD) || 
                titleID.Equals((int)Config.PositionTitle.FunctionalDH) ||
                titleID.Equals((int)Config.PositionTitle.AD) ||
                titleID.Equals((int)Config.PositionTitle.HRD) ||
                titleID.Equals((int)Config.PositionTitle.NCD) ||
                titleID.Equals((int)Config.PositionTitle.GMOOperations) ||
                titleID.Equals((int)Config.PositionTitle.GMOManagement) ||
                titleID.Equals((int)Config.PositionTitle.CashierManagement) ||
                titleID.Equals((int)Config.PositionTitle.TD) ||
                titleID.Equals((int)Config.PositionTitle.CD))
            {
                isDirector = true;
            }
            return isDirector;
        }
    }
    
}
