﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace ZhongLuan.ERP.Common
{
    public class Config
    {
        public static string App_Module = "ERP_Module";

        public static string Cookie_Account = "ERP_Account";
        public static string Cookie_UserName = "ERP_UserName";
        public static string Cookie_Password = "ERP_Password";

        public static string Session_Account = "ERP_Account";
        public static string Session_Departments = "ERP_Departments";
        public static string Session_Titles = "ERP_Titles";
        public static string Session_Task = "ERP_Task";
        public static string Session_Month_Record = "ERP_Month_Record";
        public static string Session_Month_Daily = "ERP_Month_Daily";
        public static string Session_Item_Record = "ERP_Item_Record";
        public static string Session_Award_Record = "ERP_Award_Record";
        public static string Session_Item_Apply = "ERP_Item_Apply";
        public static string Session_Reimbursement_Record = "ERP_Reimbursement_Record";

        public static string Staff_Module = "/hr/staff.aspx";
        public static string Item_Module = "/admin/item_storage.aspx";
        public static string Self_Attendance = "/hr/self_attendance.aspx";

        public static string Upload_Avatar = "/upload/avatar/";
        public static string Upload_IDCard = "/upload/card/";
        public static string Upload_Finance = "/upload/finance/";
        public static string Upload_Customer = "/upload/customer/";
        public static string Upload_Finance_Customer = "/upload/finance/customer/";

        public static string Security_Key = ConfigurationManager.AppSettings["Security_Key"];
        public static string DataBase_Key = "zluan335";

        public static string Default_Password = ConfigurationManager.AppSettings["Default_Password"];

        public static string Work_Start_Time = ConfigurationManager.AppSettings["Work_Start_Time"];
        public static string Work_End_Time = ConfigurationManager.AppSettings["Work_End_Time"];
        public static string Default_Mini_Time = ConfigurationManager.AppSettings["Default_Mini_Time"];
        public static string Staff_Mini_Time = ConfigurationManager.AppSettings["Staff_Mini_Time"];

        public static string Date_Fomart = "yyyy-MM-dd HH:mm:ss";
        public static string Date_Fomart_ShortDate = "yyyy-MM-dd";
        public static DateTime SQL_Default_Date = new DateTime(2000, 1, 1);

        public static int Headquarters = 1;
        public static int Workflow_Process_IsApprove = 1;

        public static int AbnormalLimit = 3;

        //public static string ZKTeco_IT = "ZKTeco_IT";
        public static string ZKTeco_SH = "ZKTeco_SH";
        public static string ZKTeco_GL = "ZKTeco_GL";
        public static string ZKTeco_GL38 = "ZKTeco_GL38";

        public static string DataBase_Conn = SecurityHelper.Decrypt(DataBase_Key, ConfigurationManager.ConnectionStrings["DBConnString"].ConnectionString);

        public enum AccountStatus
        {
            Delete = 0,
            Inactive = 1,
            Active = 2,
            Disable = 3
        }

        public enum AccountType
        {
            Admin = 0,
            Normal = 1
        }

        public enum StaffStatus
        {
            Entry = 1,
            OnJob = 2,
            Active = 3,
            Quit = 4
        }

        public enum TaskStatus
        {
            Active = 1,
            Finish = 2,
            Over = 3,
            Delete = 4
        }

        public enum LeaveStatus
        {
            Apply = 1,
            success = 2
        }

        public enum WorkflowStatus
        {
            Inactive = 0,
            Active = 1
        }

        public enum WorkflowProcessStatus
        {
            Inactive = 0,
            Active = 1
        }

        public enum Purview
        {
            View = 1,
            Add = 2,
            Modify = 3,
            Delete = 4,
            Approval = 5,
            Chart = 6,
            BankCard = 7,
            Print = 8
        }

        public enum Workflow
        {
            Entry = 1010001,
            OperationCenterEntry = 1012001, 
            Leave = 1020501,
            FunctionalStaffLeave = 1021501,
            MarketStaffLeave = 1022501, 
            StaffAbnormal = 1030001, 
            OperationCenterStaffAbnormal = 1032001, 
            ManagerAbnormal = 1030002, 
            OperationCenterManagerAbnormal = 1032002, 
            DirectorAbnormal = 1030003,
            ManagerCenterDirectorAbnormal = 1030004, 
            FunctionalManagerLeave2 = 1021601,
            FunctionalManagerLeave3 = 1021602,
            FunctionalDirectorLeave2 = 1021401,
            FunctionalDirectorLeave3 = 1021402,
            MarketManagerLeave2 = 1022601,
            MarketManagerLeave3 = 1022602,
            MarketDirectorLeave2 = 1022401,
            MarketDirectorLeave3 = 1022402,
            StaffQuit = 1030501,
            OperationCenterStaffQuit = 1032501, 
            ManagerQuit = 1030601,
            OperationCenterManagerQuit = 1032601, 
            FunctionalDirectorQuit = 1031401,
            MarketDirectorQuit = 1032401,
            StaffPositive = 1040501,
            CancelLeave = 1050501,
            ManagerCenterStaffCancelLeave = 1051501,
            OperationCenterStaffCancelLeave = 1052501,
            ManagerCenterManagerCancelLeave2 = 1051601,
            ManagerCenterManagerCancelLeave3 = 1051602,
            ManagerCenterDirectorCancelLeave2 = 1051401,
            ManagerCenterDirectorCancelLeave3 = 1051402,
            OperationCenterManagerCancelLeave2 = 1052601,
            OperationCenterManagerCancelLeave3 = 1052602,
            OperationCenterDirectorCancelLeave2 = 1052401,
            OperationCenterDirectorCancelLeave3 = 1052402,

            Room = 2010001,
            OperationCenterRoom = 2012001, 
            ItemApply = 2020001,
            OperationCenterItemApply = 2022001, 
            StaffItemShop = 2031001, 
            FunctionalItemShop = 2031401,
            MarketItemShop = 2032401,
            MarketSelfItemShop = 2032402,
            EquipmentShop = 2031402,
            OperationCenterDirectorEquipmentShop = 2032404, 
            OperationCenterStaffEquipmentShop = 2032504, 
            BranchStaffAwardShop = 2032503, 
            BranchManagerAwardShop = 2032603, 
            BranchDirectorAwardShop = 2032403, 
            FunctionalCertificate = 2041401,
            FunctionalStaffCertificate = 2041501, 
            MarketCertificate = 2042401,
            MarketSelfCertificate = 2042402, 
            HeadquartersStaffInstantlyPayment = 2051001,
            HeadquartersDirectorInstantlyPayment = 2051401,
            MediationPayMent = 2051402,
            BranchDirectorInstantlyPayment = 2052401,
            BranchDirectorBonusPayment = 2052402,
            BranchSalary = 2052403,
            BranchCycleBonus = 2052404, 
            OperationCenterCompensation = 2052505, 
            HeadquartersStaffBeforehandPayment = 2061001, 
            BranchDirectorBeforehanPayment = 2062401,
            HeadquartersDirectorBeforehandPayment = 2061401, 
            EquipmentCollar = 2070001,
            ReturnEquipment = 2080001,
            HeadquartersMonthShop = 2091001,
            BranchMonthShop = 2092001,
            CertificateBack = 2100001, 
            Loan =  2110001,
            Reimbursement = 2120001,
            HeadquartersDirectorReimbursement = 2120401,

            ManagerCenterNotice = 9011001,
            OperationCenterNotice = 9012001
        }

        public enum RoomStatus
        {
            Delete = 0,
            Active = 1,
            Inactive = 2
        }

        public enum PositionStatus
        {
            Delete = 0,
            Active = 1,
            Inactive = 2
        }
        
        public enum PositionTitle
        {
            GMO = 1,
            HRD = 2,
            AD = 3,
            DD = 4,
            Staff = 5,
            DM = 6,
            GMOOperations = 7, 
            GMOManagement = 8, 
            Purchase = 21,
            NetworkManagement = 22, 
            Cashier = 31,
            CashierLeader = 32, 
            CashierManagement = 33, 
            NCD = 41, 
            TD = 51, 
            CD = 61, 
            FunctionalDH = 75  
        }

        public enum ItemApply
        {
            Off = 0,
            On = 1
        }

        public enum LeaveType
        {
            Absence = 1,
            Sick = 2,
            Marriage = 3,
            Maternity = 4,
            Funeral = 5,
            MakeFalse = 6,
            Special = 7,
            Egress = 8
        }

        public enum Certificate
        {
            seal = 1,
            certificate = 2
        }

        public enum PaymentType
        {
            instantly = 1, 
            beforehand = 2,
            cycleBonus = 3
        }

        public enum ItemType
        {
            OfficeSupplies = 1,
            DailySupplies = 2,
            Equipment = 3,
            OfficeEquipment = 4,
            OfficeFurniture = 5, 
            CommonElectrical = 6,
            EmployeeWelfare = 7
        }

        public enum EquipmentOperationType
        {
            Out = 1,
            Into = 2
        }

        public enum Department
        {
            Data = 6,
            Finance = 72
        }
        public enum DepartmentGroup
        {
            Functional = 1,
            Market = 2 
        }

        public enum ItemShopRecordStatus
        {
            Defualt = 1, 
            AlreadyPurchased = 2,
            NoPurchase = 3 
        }

        public enum CertificateStatus
        {
            Defualt = 1,
            Borrow = 2
        }

        public enum HolidayType
        {
            Weekend = 1,
            Legal = 2,
            Other = 3
        }

        public enum AbnormalType
        {
            AM = 1,
            PM = 2
        }

        public enum CertificateType
        {
            Defualt = 0,
            Success = 1, 
            Fail = 2
        }

        public enum CompanyArea
        {
            YuanDongG = 1,
            ZhongDian = 2,
            XinMei32 = 2,
            YuanDongM = 3,
            YingLong = 4,
            XinMei38 = 8
        }

        public enum CustomerStaffStatus
        {
            Inactive = 0,
            Active = 1
        }

        public enum NoticeRelationStatus
        {
            Inactive = 0,
            Active = 1
        }
    }
}
