﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void UpdateAbnormal(AbnormalVO abnormal)
        {
            ctx.SubmitChanges();
        }

        public int InsertAbnormal(AbnormalVO item)
        {
            ctx.AbnormalTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Abnormal_ID;
        }

        public List<AbnormalVO> GetAbnormalByAccount(int accountID)
        {
            Table<AbnormalVO> table = ctx.AbnormalTable;

            var query =
                from t in table
                where t.Account_ID.Equals(accountID)
                select t;

            return query.ToList();
        }

        public List<AbnormalVO> GetAbnormalByTask(int taskID)
        {
            Table<AbnormalVO> table = ctx.AbnormalTable;
            Table<AbnormalTypeVO> type = ctx.AbnormalTypeTable;

            var query =
                from t in table
                join a in type on t.Abnormal_Type equals a.Type_ID
                where t.Task_ID.Equals(taskID)
                select new { t, a.Type_Name };

            //return query.ToList();

            List<AbnormalVO> objList = new List<AbnormalVO>();
            var list = query.ToList();
            foreach (var item in list)
            {
                AbnormalVO obj = item.t;
                obj.Type_Name = item.Type_Name;

                objList.Add(obj);
            }
            return objList;

        }

        public void UpdateAbnormalByTask(int taskID)
        {
            Table<AbnormalVO> table = ctx.AbnormalTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public bool IsExistAbnormal(int accountID, DateTime date, int type)
        {
            Table<AbnormalVO> table = ctx.AbnormalTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from t in table
                join tk in task on t.Task_ID equals tk.Task_ID
                where t.Account_ID.Equals(accountID)
                    && t.Abnormal_Date.Equals(date)
                    && t.Abnormal_Type.Equals(type)
                    && (tk.Status_ID.Equals((int)Config.TaskStatus.Active) || tk.Status_ID.Equals((int)Config.TaskStatus.Finish))
                select t;

            return query.Count() > 0;
        }

        public List<AbnormalVO> GetAbnormalByAccountFinish(int accountID, DateTime start, DateTime end)
        {
            Table<AbnormalVO> table = ctx.AbnormalTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                join a in account on t.Account_ID equals a.Account_ID
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish)
                    && t.Account_ID.Equals(accountID)
                    && t.Abnormal_Date.CompareTo(start) >= 0
                    && t.Abnormal_Date.CompareTo(end) < 0
                select t;

            return query.ToList();
        }

        public List<AbnormalVO> GetAbnormalByPositionFinish(int[] positionIDs, DateTime start, DateTime end)
        {
            Table<AbnormalVO> table = ctx.AbnormalTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                join a in account on t.Account_ID equals a.Account_ID
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish)
                    && positionIDs.Contains(a.Position_ID)
                    && t.Abnormal_Date.CompareTo(start) >= 0
                    && t.Abnormal_Date.CompareTo(end) < 0
                select t;

            return query.ToList();
        }


        public int GetSumAbnormalByAccount(int accountID, DateTime start, DateTime end)
        {
            Table<AbnormalVO> table = ctx.AbnormalTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                where t.Abnormal_Date.CompareTo(start) >= 0
                    && t.Abnormal_Date.CompareTo(end) <= 0
                    && t.Account_ID.Equals(accountID)
                    && (k.Status_ID.Equals((int)Config.TaskStatus.Active) || k.Status_ID.Equals((int)Config.TaskStatus.Finish))
                select t;

            return query.Count();
        }


        public List<AbnormalTypeVO> GetAbnormalType()
        {
            Table<AbnormalTypeVO> table = ctx.AbnormalTypeTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }


        public List<AttendanceViewModelVO> GetAttendanceViewModel(List<AttendanceViewModelVO> list)
        {

            var query = from t in list
                        group t by new { t.Company_Name, t.Company_ID, } into b
                        select new
                        {
                            Company_ID = b.Key.Company_ID,
                            Company_Name = b.Key.Company_Name,
                            Attendance_Number = b.Sum(i => i.Attendance_Number),
                        };

            List<AttendanceViewModelVO> modellist = new List<AttendanceViewModelVO>();

            foreach (var item in query)
            {
                AttendanceViewModelVO obj = new AttendanceViewModelVO();
                obj.Company_ID = item.Company_ID;
                obj.Company_Name = item.Company_Name;
                obj.Attendance_Number = item.Attendance_Number;
                modellist.Add(obj);
            }

            return modellist.ToList();
        }

    }
}
