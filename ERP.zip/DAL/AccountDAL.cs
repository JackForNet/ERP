﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public AccountVO GetAccountByID(int id)
        {
            Table<AccountVO> table = ctx.AccountTable;

            var query =
                from t in table
                where t.Account_ID.Equals(id) && (t.Status_ID.Equals((int)Config.AccountStatus.Active) || t.Status_ID.Equals((int)Config.AccountStatus.Disable))
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public AccountVO GetAccountByUserName(string UserName)
        {
            Table<AccountVO> table = ctx.AccountTable;
             Table<StaffVO> staff = ctx.StaffTable;
             var query =
                 from t in table
                 join s in staff on t.Account_ID equals s.Account_ID
                 where t.User_Name.Equals(UserName)
                 select new {t,s };

            if (query.Count() == 0)
                return null;

            List < AccountVO >accountlist = new List<AccountVO>();
            foreach (var item in query.ToList())
            {
                AccountVO account = new AccountVO();
                account = item.t;
                account.Staff = item.s;
                accountlist.Add(account);
            }

            return accountlist.First();
        }

        public int InsertAccount(AccountVO account)
        {
            ctx.AccountTable.InsertOnSubmit(account);
            ctx.SubmitChanges();
            return account.Account_ID;
        }

        public void UpdateAccount(AccountVO account)
        {
            Table<AccountVO> table = ctx.AccountTable;

            var query =
                from t in table
                where t.Account_ID.Equals(account.Account_ID)
                select t;

            AccountVO obj = query.First();
            obj = account;
            obj.Status_ID = account.Status_ID;
            ctx.SubmitChanges();
        }

        public void UpdatePassowrd(AccountVO account)
        {
            Table<AccountVO> table = ctx.AccountTable;

            var query =
                from t in table
                where t.Account_ID.Equals(account.Account_ID)
                select t;

            AccountVO obj = query.First();
            obj.Password = account.Password;
            ctx.SubmitChanges();
        }

        public void UpdateAccountPositionByStaffID(int staffID, int positionID)
        {
            Table<AccountVO> table = ctx.AccountTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join s in staff on t.Account_ID equals s.Account_ID
                where s.Staff_ID.Equals(staffID)
                select t;

            if (query.Count() == 0)
                return;

            AccountVO obj = query.First();
            obj.Position_ID = positionID;
            ctx.SubmitChanges();
        }

        public AccountVO GetAccount(string name)
        {
            Table<AccountVO> table = ctx.AccountTable;

            var query =
                from t in table
                where t.User_Name.Equals(name) && (t.Status_ID.Equals((int)Config.AccountStatus.Active) || t.Status_ID.Equals((int)Config.AccountStatus.Disable))
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public AccountVO GetAccount(int id)
        {
            Table<AccountVO> table = ctx.AccountTable;

            var query =
                from t in table
                where t.Account_ID.Equals(id) && (t.Status_ID.Equals((int)Config.AccountStatus.Active) || t.Status_ID.Equals((int)Config.AccountStatus.Disable))
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<AccountVO> GetAccount(string name, int page, int size, out int total)
        {
            Table<AccountVO> table = ctx.AccountTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            Table<DepartmentVO> dept = ctx.DepartmentTable;
            Table<PositionVO> pos = ctx.PositionTable;
            Table<AccountStatusVO> status = ctx.AccountStatusTable;
            int start = page * size;

            var query =
                from t in table
                join p in pos on t.Position_ID equals p.Position_ID
                join s in status on t.Status_ID equals s.Status_ID
                where !t.Status_ID.Equals((int)Config.AccountStatus.Delete)
                    && (!string.IsNullOrEmpty(name) ? t.User_Name.Equals(name) : true)
                select new { t, p.Position_Name, s.Status_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            List<AccountVO> objList = new List<AccountVO>();
            foreach (var item in pageQuery)
            {
                AccountVO obj = item.t;
                obj.Position_Name = item.Position_Name;
                obj.Status_Name = item.Status_Name;
                objList.Add(obj);
            }
            return objList;
            //return query.ToList();
        }

        public AccountVO GetAccount(string name, string password)
        {
            Table<AccountVO> table = ctx.AccountTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            Table<DepartmentVO> dept = ctx.DepartmentTable;
            Table<PositionVO> pos = ctx.PositionTable;

            var query =
                from t in table
                join s in staff on t.Account_ID equals s.Account_ID into result0
                from t_s in result0.DefaultIfEmpty()
                join p in pos on t.Position_ID equals p.Position_ID into result1
                from t_p in result1.DefaultIfEmpty()
                join d in dept on t_p.Department_ID equals d.Department_ID into result2
                from p_d in result2.DefaultIfEmpty()
                join c in company on p_d.Company_ID equals c.Company_ID into result3
                from d_c in result3.DefaultIfEmpty()
                where (t.Status_ID.Equals((int)Config.AccountStatus.Active) 
                        || (t.Status_ID.Equals((int)Config.AccountStatus.Delete) && t_s.Quit_Date.HasValue && t_s.Quit_Date.Value.CompareTo(DateTime.Now) > 0))
                    && t.User_Name.Equals(name)
                    && t.Password.Equals(password)
                select new
                {
                    t,
                    t_s,
                    Position_Name = t_p != null ? t_p.Position_Name : "",
                    Department_ID = p_d != null ? p_d.Department_ID : 0,
                    Company_ID = d_c != null ? d_c.Company_ID : 0
                };

            if (query.Count() == 0)
                return null;

            var item = query.First();
            AccountVO obj = item.t;
            obj.Staff = item.t_s;
            obj.Position_Name = item.Position_Name;
            obj.Department_ID = item.Department_ID;
            obj.Company_ID = item.Company_ID;
            return obj;
        }

        public List<AccountVO> GetAccountByPositionIDs(string positionIDs)
        {
            Table<AccountVO> table = ctx.AccountTable;
            string[] array = positionIDs.Split(',');

            var query =
                from t in table
                where array.Contains(t.Position_ID.ToString())
                select t;

            return query.ToList();
        }

        public List<AccountVO> GetAccountByPositionID(int positionID)
        {
            Table<AccountVO> table = ctx.AccountTable;

            var query =
                from t in table
                where t.Position_ID.Equals(positionID) && !t.Status_ID.Equals((int)Config.AccountStatus.Delete) 
                select t;

            return query.ToList();
        }

        public AccountVO GetAccountCompanyByID(int id)
        {
            Table<AccountVO> table = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join p in position on t.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where t.Account_ID.Equals(id) 
                select new { t, d.Company_ID };

            if (query.Count() == 0)
                return null;

            var item = query.First();
            AccountVO obj = item.t;
            obj.Company_ID = item.Company_ID;
            return obj;
        }
    }
}
