﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertCertificateAdd(AdminCertificateAddVO item)
        {
            ctx.AdminCertificateAddTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Add_ID;
        }

        public void UpdateCertificateAddByTask(int taskID)
        {
            Table<AdminCertificateAddVO> table = ctx.AdminCertificateAddTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public List<AdminCertificateAddVO> GetCertificateAddByTask(int taskID)
        {
            Table<AdminCertificateAddVO> table = ctx.AdminCertificateAddTable;

            var query =
                from t in table 
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

        }

        public List<AdminCertificateAddVO> GetCertificateAddByFinish()
        {
            Table<AdminCertificateAddVO> table = ctx.AdminCertificateAddTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.LeaveStatus.success) 
                select t;

            return query.ToList();
        }

        public List<AdminCertificateAddVO> GetAddListByCompany(Config.Workflow workFlow, int page, int size, out int total)
        {
            Table<AdminCertificateAddVO> table = ctx.AdminCertificateAddTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<DepartmentVO> depart = ctx.DepartmentTable;
            Table<PositionVO> pos = ctx.PositionTable;
            Table<AccountVO> account = ctx.AccountTable;
            int start = page * size;

            List<AdminCertificateAddVO> objList = new List<AdminCertificateAddVO>();

            var query =
                from t in table 
                join tk in task on t.Task_ID equals tk.Task_ID 
                join ac in account on t.Account_ID equals ac.Account_ID
                join ps in pos on ac.Position_ID equals ps.Position_ID
                join de in depart on ps.Department_ID equals de.Department_ID
                where t.Status_ID.Equals((int)Config.TaskStatus.Finish)
                    && !tk.WorkFlow_ID.Equals((int)workFlow) 
                orderby t.Create_Date descending
                select new { t, ps.Position_Name };

            //return query.ToList();

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var data in pageQuery)
            {
                AdminCertificateAddVO obj = data.t;
                obj.PositionName = data.Position_Name;

                objList.Add(obj);
            }

            return objList;
        }
    }
}
