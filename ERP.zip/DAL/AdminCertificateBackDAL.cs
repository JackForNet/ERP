﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertCertificateBack(AdminCertificateBackVO item)
        {
            ctx.AdminCertificateBackTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Back_ID;
        }

        public void UpdateCertificateBackByTask(int taskID)
        {
            Table<AdminCertificateBackVO> table = ctx.AdminCertificateBackTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public List<AdminCertificateBackVO> GetCertificateBackByTask(int taskID)
        {
            Table<AdminCertificateBackVO> table = ctx.AdminCertificateBackTable;

            var query =
                from t in table 
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

        }
    }
}
