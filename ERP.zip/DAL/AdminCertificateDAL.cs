﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<AdminCertificateVO> GetCertificate()
        {
            Table<AdminCertificateVO> table = ctx.AdminCertificateTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public List<AdminCertificateVO> GetCertificateByIDs(string ids)
        {
            Table<AdminCertificateVO> table = ctx.AdminCertificateTable;
            string[] array = ids.Split(',');

            var query =
                from t in table
                where array.Contains(t.Certificate_ID.ToString())
                select t;

            return query.ToList();
        }
    }
}
