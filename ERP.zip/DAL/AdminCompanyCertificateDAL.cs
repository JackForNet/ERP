﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {

        public List<AdminCompanyCertificateVO> GetAllCompanyCertificate()
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public List<AdminCompanyCertificateVO> GetCompanyCertificate()
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;

            var query =
                from t in table 
                where t.Status.Equals((int)Config.CertificateStatus.Defualt) 
                select t;

            return query.ToList();
        }

        public void UpdateCompanyCertificateByIDs(int companyID, string ids, Config.CertificateStatus status)
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;
            string[] array = ids.Split(',');

            var query =
                from t in table
                where array.Contains(t.Certificate_ID.ToString()) && t.Company_ID.Equals(companyID) 
                select t;

            foreach (var p in query)
            {
                p.Status = (int)status;
            }

            ctx.SubmitChanges();
        }

        public int CheckCompanyCertificate(int companyID, string ids, Config.CertificateStatus status)
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;
            string[] array = ids.Split(',');

            var query =
                from t in table
                where array.Contains(t.Certificate_ID.ToString()) && t.Company_ID.Equals(companyID)
                && t.Status.Equals((int)status) 
                select t;

            return query.Count();
        }

        public List<AdminCompanyCertificateVO> GetCompanyCertificate(int companyID, int page, int size, out int total)
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;
            Table<AdminCompanyVO> company = ctx.AdminCompanyTable;
            Table<AdminCertificateVO> certificate = ctx.AdminCertificateTable;
            int start = page * size;

            var query =
                from t in table
                join cy in company on t.Company_ID equals cy.Company_ID
                join ct in certificate on t.Certificate_ID equals ct.Certificate_ID
                where t.Company_ID.Equals(companyID) 
                select new { t, cy.Company_Name, ct.Certificate_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            List<AdminCompanyCertificateVO> objList = new List<AdminCompanyCertificateVO>();
            foreach (var item in pageQuery)
            {
                AdminCompanyCertificateVO obj = item.t;
                obj.Company_Name = item.Company_Name;
                obj.Certificate_Name = item.Certificate_Name;
                objList.Add(obj);
            }
            return objList;

        }

        public List<AdminCompanyCertificateVO> GetCompanyCertificateByCompanyID(int companyID)
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;

            var query =
                from t in table
                where t.Status.Equals((int)Config.CertificateStatus.Defualt)
                && t.Company_ID.Equals(companyID) 
                select t;

            return query.ToList();
        }

        public void InsertAdminCompanyCertificate(AdminCompanyCertificateVO item)
        {
            ctx.AdminCompanyCertificateTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void DeleteAdminCompanyCertificate(int companyID, int certificateID)
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID) && t.Certificate_ID.Equals(certificateID) 
                select t;

            if (query.Count() > 0)
            {
                AdminCompanyCertificateVO obj = query.First();
                ctx.AdminCompanyCertificateTable.DeleteOnSubmit(obj);
                ctx.SubmitChanges();
            }
        }

        public void DeleteAdminCompanyCertificateByCompany(int companyID)
        {
            Table<AdminCompanyCertificateVO> table = ctx.AdminCompanyCertificateTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID) 
                select t;

            if (query.Count() > 0)
            {
                ctx.AdminCompanyCertificateTable.DeleteAllOnSubmit(query.ToList());
                ctx.SubmitChanges();
            }
        }
    }
}
