﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<AdminCompanyVO> GetAdminCompany()
        {
            Table<AdminCompanyVO> table = ctx.AdminCompanyTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table 
                join c in company on t.Location_Company_ID equals c.Company_ID
                select new { t, c.Company_Name};

            List<AdminCompanyVO> objList = new List<AdminCompanyVO>();
            foreach(var item in query.ToList())
            {
                AdminCompanyVO obj = item.t;
                obj.Location_Company_Name = item.Company_Name;
                objList.Add(obj);
            }

            return objList;
        }

        public AdminCompanyVO GetAdminCompanyByID(int id)
        {
            Table<AdminCompanyVO> table = ctx.AdminCompanyTable;

            var query =
                from t in table 
                where t.Company_ID.Equals(id) 
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public int InsertAdminCompany(AdminCompanyVO item)
        {
            ctx.AdminCompanyTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Company_ID;
        }

        public void UpdateAdminCompany(AdminCompanyVO item)
        {
            ctx.SubmitChanges();
        }

        public int DeleteAdminCompany(AdminCompanyVO item)
        {
            ctx.AdminCompanyTable.DeleteOnSubmit(item);
            ctx.SubmitChanges();
            return item.Company_ID;
        }

        public void DeleteAdminCompanyByID(int companyID)
        {
            Table<AdminCompanyVO> table = ctx.AdminCompanyTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID) 
                select t;

            if (query.Count() > 0)
            {
                AdminCompanyVO obj = query.First();
                ctx.AdminCompanyTable.DeleteOnSubmit(obj);
                ctx.SubmitChanges();
            }
        }

    }
}
