﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertEquipmentAdd(AdminEquipmentVO item)
        {
            ctx.AdminEquipmentTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Equipment_ID;
        }

        public List<AdminEquipmentVO> GetEquipmentByTask(int taskID)
        {
            Table<AdminEquipmentVO> table = ctx.AdminEquipmentTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

        }

        public void UpdateEquipmentByTask(int taskID)
        {
            Table<AdminEquipmentVO> table = ctx.AdminEquipmentTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

    }
}
