﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertMonthShop(AdminMonthShopVO item)
        {
            ctx.AdminMonthShopTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Month_Shop_ID;
        }

        public List<AdminMonthShopVO> GetMonthShopByTask(int taskID)
        {
            Table<AdminMonthShopVO> table = ctx.AdminMonthShopTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

        }

        public List<AdminMonthShopVO> GetMonthShopByTasks(string taskIDs)
        {
            Table<AdminMonthShopVO> table = ctx.AdminMonthShopTable;
            Table<StaffVO> staff = ctx.StaffTable;
            string[] array = taskIDs.Split(',');

            var query =
                from t in table
                join s in staff on t.Staff_ID equals s.Staff_ID
                where array.Contains(t.Task_ID.ToString())
                orderby t.Status
                select new { t, s.Name };


            List<AdminMonthShopVO> list = new List<AdminMonthShopVO>();
            foreach (var item in query.ToList())
            {
                AdminMonthShopVO month = item.t;
                month.StaffName = item.Name;
                list.Add(month);
            }

            return list;
        }

        public void UpdateMonthShopByTask(int taskID)
        {
            Table<AdminMonthShopVO> table = ctx.AdminMonthShopTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public void UpdateMonthShopByID(int recordID, Config.ItemShopRecordStatus recordStatus)
        {
            Table<AdminMonthShopVO> table = ctx.AdminMonthShopTable;

            var query =
                from t in table
                where t.Month_Shop_ID.Equals(recordID)
                select t;

            foreach (var p in query)
            {
                p.Status = (int)recordStatus;
            }

            ctx.SubmitChanges();
        }

        public int GetMonthShopDefualtCounts(int taskID, Config.ItemShopRecordStatus recordStatus)
        {
            Table<AdminMonthShopVO> table = ctx.AdminMonthShopTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                    && t.Status.Equals((int)recordStatus) 
                select t;

            return query.Count();

        }
    }
}
