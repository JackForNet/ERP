﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertPayment(AdminPaymentVO item)
        {
            ctx.AdminPaymentTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Payment_ID;
        }

        public void UpdatePaymentByTask(int taskID)
        {
            Table<AdminPaymentVO> table = ctx.AdminPaymentTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public List<AdminPaymentVO> GetPaymentByTask(int taskID)
        {
            Table<AdminPaymentVO> table = ctx.AdminPaymentTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

        }

        public List<AdminPaymentVO> GetPaymentByFinish(int page, int size, out int total)
        {
            Table<AdminPaymentVO> table = ctx.AdminPaymentTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<StaffVO> staff = ctx.StaffTable;

            int start = page * size;

            List<AdminPaymentVO> objList = new List<AdminPaymentVO>();

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join s in staff on t.Account_ID equals s.Account_ID
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish)
                orderby t.Create_Date descending
                select new { t, s.Name, p.Position_Name, d.Department_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                AdminPaymentVO obj = item.t;
                obj.Name = item.Name;
                obj.Position = item.Position_Name;
                obj.Department = item.Department_Name;

                objList.Add(obj);
            }

            return objList;
        }

        public List<AdminPaymentVO> GetSelfPaymentByFinish(int accountID, int page, int size, out int total)
        {
            Table<AdminPaymentVO> table = ctx.AdminPaymentTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<StaffVO> staff = ctx.StaffTable;

            int start = page * size;

            List<AdminPaymentVO> objList = new List<AdminPaymentVO>();

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join s in staff on t.Account_ID equals s.Account_ID
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish) &&
                    t.Account_ID.Equals(accountID)
                select new { t, s.Name, p.Position_Name, d.Department_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                AdminPaymentVO obj = item.t;
                obj.Name = item.Name;
                obj.Position = item.Position_Name;
                obj.Department = item.Department_Name;

                objList.Add(obj);
            }

            return objList;
        }

        public void UpdatePaymentCompanyByTask(int taskID, int companyID)
        {
            Table<AdminPaymentVO> table = ctx.AdminPaymentTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Belong_Company_ID = companyID;
            }

            ctx.SubmitChanges();
        }

        public List<AdminPaymentVO> GetPayment(DateTime day)
        {

            Table<AdminPaymentVO> table = ctx.AdminPaymentTable;
             Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query = from t in table
                        join ta in task on t.Task_ID equals ta.Task_ID
                        join a in account on t.Account_ID equals a.Account_ID
                        join p in position on a.Position_ID equals p.Position_ID
                        join d in department on p.Department_ID equals d.Department_ID
                        join c in company on d.Company_ID equals c.Company_ID
                        where t.Create_Date.Date==day.Date
                              && t.Status_ID == 2
                              && ta.Status_ID==2
                        select new {t,d,c };


            List<AdminPaymentVO> list = new List<AdminPaymentVO>();
            foreach (var item in query)
            {
                AdminPaymentVO obj = new AdminPaymentVO();
                obj = item.t;
                obj.Department_ID = item.d.Department_ID;
                obj.Department_Name = item.d.Department_Name;
                obj.Company_ID = item.c.Company_ID;
                obj.Company_Name = item.c.Company_Name;
                list.Add(obj);
            }
            return list.ToList();

        }

    }
}
