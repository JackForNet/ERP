﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
       public List<AdminPaymentTypeVO> GetPaymentType()
       {
           Table<AdminPaymentTypeVO> table = ctx.AdminPaymentTypeTable;

           var query =
               from t in table
              where t.Status_ID.Equals(1)
               select t;

           return query.ToList();

       }

    }
}
