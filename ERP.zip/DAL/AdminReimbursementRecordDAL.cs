﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertAdminReimbursementrecord(AdminReimbursementRecordVO item)
        {
            ctx.AdminReimbursementRecordTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Record_ID;
        }

        public List<AdminReimbursementRecordVO> GetAdminReimbursementrecordList(int RID)
        {
            Table<AdminReimbursementRecordVO> table = ctx.AdminReimbursementRecordTable;

            var query = from t in table
                        where t.RID.Equals(RID)
                        select t;

            return query.ToList();

        }

        public double GetAdminReimbursementrecordTotal(int RID)
        {
            Table<AdminReimbursementRecordVO> table = ctx.AdminReimbursementRecordTable;

            var query = from t in table
                        where t.RID.Equals(RID)
                        select t.Price;
            return query.Sum();

        }
       
    }
}
