﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void UpdateAwardShopRecord(AwardShopRecordVO shop)
        {
            ctx.SubmitChanges();
        }

        public int InsertAwardShopRecord(AwardShopRecordVO item)
        {
            ctx.AwardShopRecordTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Shop_Record_ID;
        }

        public List<AwardShopRecordVO> GetAwardShopRecordByID(int shopID)
        {
            Table<AwardShopRecordVO> table = ctx.AwardShopRecordTable;

            var query =
                from t in table
                where t.Shop_ID.Equals(shopID) 
                select t;

            return query.ToList();
        }

        public AwardShopRecordVO GetAwardShopRecordByRecordID(int recordID)
        {
            Table<AwardShopRecordVO> table = ctx.AwardShopRecordTable;

            var query =
                from t in table
                where t.Shop_Record_ID.Equals(recordID)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public void UpdateAwardShopRecordByRecordID(int recordID, Config.ItemShopRecordStatus recordStatus)
        {
            Table<AwardShopRecordVO> table = ctx.AwardShopRecordTable;

            var query =
                from t in table
                where t.Shop_Record_ID.Equals(recordID)
                select t;

            foreach (var p in query)
            {
                p.Status = (int)recordStatus;
            }

            ctx.SubmitChanges();
        }

        public List<AwardShopRecordVO> GetAwardShopByTasks(string taskIDs)
        {
            Table<AwardShopRecordVO> table = ctx.AwardShopRecordTable;
            Table<AwardShopVO> itemShop = ctx.AwardShopTable;
            string[] array = taskIDs.Split(',');

            var query =
                from t in table 
                join s in itemShop on t.Shop_ID equals s.Shop_ID 
                where array.Contains(s.Task_ID.ToString())
                orderby t.Status 
                select new { t, s.Task_ID, s.Name };

            List<AwardShopRecordVO> objList = new List<AwardShopRecordVO>();
            foreach (var item in query)
            {
                AwardShopRecordVO obj = item.t;
                obj.TaskID = item.Task_ID;
                obj.StaffName = item.Name;
                objList.Add(obj);
            }
            return objList;
        }

        public int GetAwardShopDefualtCounts(int taskID, Config.ItemShopRecordStatus recordStatus)
        {
            Table<AwardShopRecordVO> table = ctx.AwardShopRecordTable;
            Table<AwardShopVO> itemShop = ctx.AwardShopTable;

            var query =
                from t in table
                join s in itemShop on t.Shop_ID equals s.Shop_ID
                where s.Task_ID.Equals(taskID)
                    && t.Status.Equals((int)recordStatus)
                select t;

            return query.Count();

        }

        public List<AwardShopRecordVO> GetAwardShopByCompanyTasks(Config.Workflow workflow, int companyID, int page, int size, out int total)
        {
            Table<AwardShopRecordVO> table = ctx.AwardShopRecordTable;
            Table<AwardShopVO> itemShop = ctx.AwardShopTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<DepartmentVO> depart = ctx.DepartmentTable;
            Table<PositionVO> pos = ctx.PositionTable;
            Table<AccountVO> account = ctx.AccountTable;
            int start = page * size; 

            var query =
                from t in table
                join s in itemShop on t.Shop_ID equals s.Shop_ID
                join tk in task on s.Task_ID equals tk.Task_ID
                join ac in account on s.Account_ID equals ac.Account_ID
                join ps in pos on ac.Position_ID equals ps.Position_ID
                join de in depart on ps.Department_ID equals de.Department_ID
                where de.Company_ID.Equals(companyID) && tk.Status_ID.Equals((int)Config.TaskStatus.Finish)
                    && tk.WorkFlow_ID.Equals((int)workflow) 
                orderby t.Create_Date descending 
                select new { t, s.Task_ID, s.Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            List<AwardShopRecordVO> objList = new List<AwardShopRecordVO>();
            foreach (var item in query)
            {
                AwardShopRecordVO obj = item.t;
                obj.TaskID = item.Task_ID;
                obj.StaffName = item.Name;
                objList.Add(obj);
            }
            return objList;
        }
    }
}
