﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Common;

using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<CompanyVO> GetCompany()
        {
            Table<CompanyVO> table = ctx.CompanyTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            return query.ToList();
        }

        public List<CompanyVO> GetCompanyBy()
        {
            Table<CompanyVO> table = ctx.CompanyTable;

            var query =
                from t in table
                where t.Company_ID != 1
                 && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            return query.ToList();
        }

        public List<CompanyAreaVO> GetCompanyArea(int companyID)
        {
            Table<CompanyAreaVO> table = ctx.CompanyAreaTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID)
                select t;

            return query.ToList();
        }

        public CompanyAreaVO GetCompanyAreaByID(int areaID)
        {
            Table<CompanyAreaVO> table = ctx.CompanyAreaTable;

            var query =
                from t in table
                where t.Area_ID.Equals(areaID)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<CompanyVO> GetSubCompany(int companyID)
        {
            Table<CompanyVO> table = ctx.CompanyTable;

            var query =
                from t in table
                where !t.Company_ID.Equals(companyID)
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            return query.ToList();
        }

        public List<CompanyAreaVO> GetAllCompanyArea()
        {
            Table<CompanyAreaVO> table = ctx.CompanyAreaTable;

            var query =
                from t in table
                select t;

            if (query.Count() == 0)
                return null;

            return query.ToList();
        }

        public CompanyVO GetCompanyByID(int companyID)
        {
            Table<CompanyVO> table = ctx.CompanyTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID)
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<CompanyAreaVO> GetCompanyArea()
        {
            Table<CompanyVO> table = ctx.CompanyTable;
            Table<CompanyAreaVO> companyarea = ctx.CompanyAreaTable;

            var query =
                (from t in table
                 join c in companyarea on t.Company_ID equals c.Company_ID
                 where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                 group new { c.DataBase_Name, t.Company_Name, t.Company_ID }
                 by new { t.Company_ID, c.DataBase_Name, t.Company_Name } into b
                 select new
                 {
                     Company_ID = b.Key.Company_ID,
                     DataBase_Name = b.Key.DataBase_Name,
                     Company_Name = b.Key.Company_Name
                 }).ToList();

            List<CompanyAreaVO> companyarealist = new List<CompanyAreaVO>();
            foreach (var item in query)
            {
                CompanyAreaVO obj = new CompanyAreaVO();
                obj.Company_ID = item.Company_ID;
                obj.Company_Name = item.Company_Name;
                obj.DataBase_Name = item.DataBase_Name;
                companyarealist.Add(obj);
            }

            return companyarealist;
        }

        //组织架构总监
        public List<PositionVO> GetCompanyFrameworkByCompanyID(int CompanyID)
        {
            Table<CompanyVO> table = ctx.CompanyTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<PositionVO> position = ctx.PositionTable;

            var query = from t in table
                        join d in department on t.Company_ID equals d.Company_ID
                        join p in position on d.Department_ID equals p.Department_ID
                        where t.Company_ID.Equals(CompanyID)
                        && p.Title_ID.Equals(4)
                        && d.Group_ID.Equals(2)
                         && p.Status_ID.Equals((int)Config.PositionStatus.Active)
                         && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                        select new { p.Position_Name, d.Department_ID, d.Department_Name, p.Position_ID };


            List<PositionVO> positionlist = new List<PositionVO>();
            foreach (var item in query)
            {
                PositionVO obj = new PositionVO();
                obj.Position_ID = item.Position_ID;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;
                obj.Department_ID = item.Department_ID;
                positionlist.Add(obj);
            }

            return positionlist;
        }

        //组织架构经理
        public List<PositionVO> GetCompanyFrameworkByDepartmentID(int DepartmentID)
        {
            Table<CompanyVO> table = ctx.CompanyTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<PositionVO> position = ctx.PositionTable;

            var query = from t in table
                        join d in department on t.Company_ID equals d.Company_ID
                        join p in position on d.Department_ID equals p.Department_ID
                        where d.Department_ID.Equals(DepartmentID)
                        && p.Title_ID.Equals(6)
                        && p.Status_ID.Equals(1)
                        && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                        select new { p.Position_Name, p.Position_ID };


            List<PositionVO> positionlist = new List<PositionVO>();
            foreach (var item in query)
            {
                PositionVO obj = new PositionVO();
                obj.Position_ID = item.Position_ID;
                obj.Position_Name = item.Position_Name;
                positionlist.Add(obj);
            }

            return positionlist;
        }



        //组织架构业务员
        public List<PositionVO> GetCompanyFrameworkByPositionID(int PositionID)
        {
            Table<PositionVO> table = ctx.PositionTable;

            var query = from t in table
                        where t.Superior_ID.Equals(PositionID)
                        && t.Title_ID.Equals(5)
                        && t.Status_ID.Equals(1)
                        select t;


            List<PositionVO> positionlist = new List<PositionVO>();
            foreach (var item in query)
            {
                PositionVO obj = new PositionVO();
                obj.Position_ID = item.Position_ID;
                obj.Position_Name = item.Position_Name;
                positionlist.Add(obj);
            }

            return positionlist;
        }


        public List<CompanyVO> GetCompanyMarket()
        {
            Table<CompanyVO> table = ctx.CompanyTable;

            var query =
                from t in table
                where t.Company_ID != 1
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            return query.ToList();
        }


    }
}
