﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;
using System.Data.Linq.SqlClient;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        #region Customer

        public List<CustomerVO> GetCustomerBySearch(string account, string name, int platformID, int page, int size, out int total)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            int start = page * size;

            List<CustomerVO> objList = new List<CustomerVO>();

            var query =
                from t in table
                join p in platform on t.Platform_ID equals p.Platform_ID
                join cs in cStaff on t.Account equals cs.Account
                join d in department on cs.Department_ID equals d.Department_ID
                join s in staff on cs.Staff_ID equals s.Staff_ID
                where (!string.IsNullOrEmpty(account) ? t.Account.Equals(account) : true)
                    && (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && (platformID > 0 ? t.Platform_ID.Equals(platformID) : true)
                    && cs.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                select new { t, p.Platform_Name, d.Department_Name, s.Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                CustomerVO obj = item.t;
                obj = item.t;
                obj.Platform_Name = item.Platform_Name;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Name;
                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerVO> GetCustomerListBySearch(string account, DateTime StartDate, DateTime EndDate, string name, int platformID, int page, int size, out int total)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            int start = page * size;

            List<CustomerVO> objList = new List<CustomerVO>();

            var query =
                from t in table
                join p in platform on t.Platform_ID equals p.Platform_ID into t_p
                from t1 in t_p.DefaultIfEmpty()
                join d in department on t.Department_ID equals d.Department_ID into t2_d
                from t3 in t2_d.DefaultIfEmpty()
                join c in company on t3.Company_ID equals c.Company_ID
                join s in staff on t.Staff_ID equals s.Staff_ID into t2_s
                from t4 in t2_s.DefaultIfEmpty()
                where (!string.IsNullOrEmpty(account) ? t.Account.Equals(account) : true)
                    && (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && (platformID > 0 ? t.Platform_ID.Equals(platformID) : true)
                    && t.Create_Date.Date.CompareTo(StartDate) >= 0
                    && t.Create_Date.Date.CompareTo(EndDate) <= 0
                select new { t, t1.Platform_Name, t3.Department_Name, t4.Name, c.Company_Name, t4.Staff_Number };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                CustomerVO obj = item.t;
                obj = item.t;
                obj.Staff_Number = CommonHelper.StaffNumberLength(item.Staff_Number);
                obj.Platform_Name = item.Platform_Name;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Name;
                obj.Company_Name = item.Company_Name;
                objList.Add(obj);
            }

            return objList;
        }



        public List<PresetCustomerVO> GetCustomerFilingBySearch(int[] platformID, int page, int size, out int total)
        {
            Table<PresetCustomerVO> table = ctx.PresetCustomerTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            int start = page * size;

            List<PresetCustomerVO> objList = new List<PresetCustomerVO>();

            var query =
                from t in table
                join p in platform on t.Platform_ID equals p.Platform_ID into t_p
                from t1 in t_p.DefaultIfEmpty()
                join d in department on t.Department_ID equals d.Department_ID into t2_d
                from t3 in t2_d.DefaultIfEmpty()
                join c in company on t3.Company_ID equals c.Company_ID
                join s in staff on t.Staff_ID equals s.Staff_ID into t2_s
                from t4 in t2_s.DefaultIfEmpty()
                where (platformID.Length > 0 ? platformID.Contains(t.Platform_ID) : false)
                && t.Status_ID.Equals((int)Config.TaskStatus.Active)
                select new { t, t1.Platform_Name, t3.Department_Name, t4.Name, c.Company_Name, t4.Staff_Number };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                PresetCustomerVO obj = item.t;
                obj = item.t;
                obj.Staff_Number = CommonHelper.StaffNumberLength(item.Staff_Number);
                obj.Platform_Name = item.Platform_Name;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Name;
                obj.Company_Name = item.Company_Name;
                objList.Add(obj);
            }

            return objList;
        }


        public List<CustomerStaffVO> GetCustomerstaffListBySearch(string account, DateTime StartDate, DateTime EndDate, string name, int platformID, int page, int size, out int total)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            int start = page * size;

            List<CustomerStaffVO> objList = new List<CustomerStaffVO>();

            var query =
                from t in table
                join cs in customer on t.Account equals cs.Account
                join p in platform on cs.Platform_ID equals p.Platform_ID into t_p
                from t1 in t_p.DefaultIfEmpty()
                join d in department on t.Department_ID equals d.Department_ID into t2_d
                from t3 in t2_d.DefaultIfEmpty()
                join c in company on t3.Company_ID equals c.Company_ID into t2_c
                from t5 in t2_c.DefaultIfEmpty()
                join s in staff on t.Staff_ID equals s.Staff_ID into t2_s
                from t4 in t2_s.DefaultIfEmpty()
                where (!string.IsNullOrEmpty(account) ? t.Account.Equals(account) : true)
                    && (!string.IsNullOrEmpty(name) ? SqlMethods.Like(cs.Name, "%" + name + "%") : true)
                    && (platformID > 0 ? cs.Platform_ID.Equals(platformID) : true)
                    && t.Create_Date.Date >= StartDate
                    && t.Create_Date.Date <= EndDate
                    && t.Active_Date != cs.Add_Date
                select new { t, cs, t1.Platform_Name, t3.Department_Name, t4.Name, t5.Company_Name, t.Status_ID, t4.Staff_Number };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                CustomerStaffVO obj = new CustomerStaffVO();
                obj = item.t;
                obj.Staff_Number = CommonHelper.StaffNumberLength(item.Staff_Number);
                obj.Platform_Name = item.Platform_Name;
                obj.Name = item.cs.Name;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Name;
                obj.Company_Name = item.Company_Name;
                obj.Add_Date = item.cs.Add_Date;
                //obj.Create_Date = item.cs.Create_Date;
                if (item.Status_ID == 1)
                    obj.Status_Name = "有效";
                else
                    obj.Status_Name = "无效";
                objList.Add(obj);
            }

            return objList;
        }





        public CustomerVO GetCustomerLeftJoin(string account)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join p in platform on t.Platform_ID equals p.Platform_ID into t_p
                from t1 in t_p.DefaultIfEmpty()
                join cs in cStaff on t.Account equals cs.Account into t_cs
                from t2 in t_cs.DefaultIfEmpty()
                join d in department on t2.Department_ID equals d.Department_ID into t2_d
                from t3 in t2_d.DefaultIfEmpty()
                join s in staff on t2.Staff_ID equals s.Staff_ID into t2_s
                from t4 in t2_s.DefaultIfEmpty()
                join ms in staff on t2.Manager_ID equals ms.Staff_ID into t2_ms
                from final in t2_ms.DefaultIfEmpty()
                where t.Account.Equals(account)
                    && t2.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                select new { t, t1.Platform_Name, t3.Department_Name, StraffName = t4.Name, ManagerName = final.Name };

            if (query.Count() == 0)
                return null;

            var item = query.FirstOrDefault();
            CustomerVO obj = new CustomerVO();
            obj = item.t;
            obj.Platform_Name = item.Platform_Name;
            obj.Department_Name = item.Department_Name;
            obj.Staff_Name = item.StraffName;
            obj.Manager_Name = item.ManagerName;

            return obj;

        }

        public CustomerVO GetCustomer(string account)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join p in platform on t.Platform_ID equals p.Platform_ID
                join cs in cStaff on t.Account equals cs.Account
                join d in department on cs.Department_ID equals d.Department_ID
                join s in staff on cs.Staff_ID equals s.Staff_ID
                join ms in staff on cs.Manager_ID equals ms.Staff_ID
                where t.Account.Equals(account)
                    && cs.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                select new { t, p.Platform_Name, d.Department_Name, StraffName = s.Name, ManagerName = ms.Name };

            if (query.Count() == 0)
                return null;

            var item = query.FirstOrDefault();
            CustomerVO obj = new CustomerVO();
            obj = item.t;
            obj.Platform_Name = item.Platform_Name;
            obj.Department_Name = item.Department_Name;
            obj.Staff_Name = item.StraffName;
            obj.Manager_Name = item.ManagerName;

            return obj;
        }

        public CustomerVO GetCustomerByAccount(string account)
        {
            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                where t.Account.Equals(account)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<CustomerVO> GetAllCustomers()
        {
            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public PresetCustomerVO GetPresetCustomer(string account)
        {
            Table<PresetCustomerVO> table = ctx.PresetCustomerTable;

            var query =
                from t in table
                where t.Account.Equals(account)
                select t;

            return query.First();
        }

        public bool IsExistCustomer(string account)
        {
            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                where t.Account.Equals(account)
                select t;

            return query.Count() > 0;
        }

        public void InsertCustomer(CustomerVO item)
        {
            ctx.CustomerTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void InsertPresetCustomer(PresetCustomerVO item)
        {
            ctx.PresetCustomerTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void InsertCustomers(List<CustomerVO> list)
        {
            if (list.Count == 0)
                return;
            ctx.CustomerTable.InsertAllOnSubmit(list);
            ctx.SubmitChanges();
        }

        public void UpdateCustomer(CustomerVO item)
        {

            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                where t.Account.Equals(item.Account)
                select t;

            if (query.Count() == 0)
                return;

            CustomerVO customer = query.First();
            customer.Account = item.Account;
            customer.Name = item.Name;
            customer.Platform_ID = item.Platform_ID;
            customer.Number = item.Number;
            customer.Staff_ID = item.Staff_ID;
            customer.Manager_ID = item.Manager_ID;
            customer.Department_ID = item.Department_ID;

            ctx.SubmitChanges();
        }

        public void UpdatePresetCustomer(PresetCustomerVO item)
        {
            ctx.SubmitChanges();
        }

        public List<CustomerVO> GetAllCustomersByManagerID(int ManagerID)
        {
            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                where t.Manager_ID.Equals(ManagerID)
                || t.Staff_ID.Equals(ManagerID)
                select t;

            return query.ToList();
        }

        public void UpdateCustomerByManagerID(CustomerVO item)
        {
            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                where t.Account.Equals(item.Account)
                select t;

            if (query.Count() == 0)
                return;

            List<CustomerVO> list = query.ToList();
            foreach (CustomerVO obj in list)
            {
                obj.Staff_ID = item.Staff_ID;
                obj.Manager_ID = item.Manager_ID;
                obj.Department_ID = item.Department_ID;
            }
            ctx.SubmitChanges();
        }

        #endregion


        #region Customer Record

        public Dictionary<int, int> GetCustomerRecord(int platform, DateTime start, DateTime end)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;

            var query =
                from t in table
                where t.Platform_ID.Equals(platform)
                    && t.Action_Date >= start
                    && t.Action_Date <= end
                group t by System.Data.Linq.SqlClient.SqlMethods.DateDiffDay(start, t.Action_Date) into g
                select new { g.Key, Total = g.Count() };

            return query.ToDictionary(i => i.Key, i => i.Total);
        }

        public void UpdateCustomerRecord(CustomerVO customer)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;

            var query =
                from t in table
                where t.Customer_Account.Equals(customer.Account)
                select t;

            if (query.Count() == 0)
                return;

            List<CustomerRecordVO> list = query.ToList();
            foreach (CustomerRecordVO item in list)
            {
                item.Staff_ID = customer.Staff_ID;
                item.Manager_ID = customer.Manager_ID;
                item.Department_ID = customer.Department_ID;
            }
            ctx.SubmitChanges();
        }

        public void UpdateCustomerRecord(CustomerStaffVO item)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;

            var query =
                from t in table
                where t.Customer_Account.Equals(item.Account)
                    && t.Action_Date > item.Active_Date
                select t;

            if (query.Count() == 0)
                return;

            List<CustomerRecordVO> list = query.ToList();
            foreach (CustomerRecordVO obj in list)
            {
                obj.Staff_ID = item.Staff_ID;
                obj.Manager_ID = item.Manager_ID;
                obj.Department_ID = item.Staff_ID;
            }
            ctx.SubmitChanges();
        }

        public void DeleteCustomerRecord(int platform, List<DateTime> removeList)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;

            var query =
                from t in table
                where t.Platform_ID.Equals(platform)
                    && removeList.Contains(t.Action_Date)
                select t;

            if (query.Count() == 0)
                return;

            List<CustomerRecordVO> list = query.ToList();

            ctx.CustomerRecordTable.DeleteAllOnSubmit(list);
            ctx.SubmitChanges();
        }

        public List<CustomerRecordVO> GetCustomerRecordBySearch(DateTime startActionDate, DateTime endActionDate, string account, string name, int platformID, int page, int size, out int total)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            int start = page * size;

            List<CustomerRecordVO> objList = new List<CustomerRecordVO>();

            var query =
                from t in table
                join cs in cStaff on t.Customer_Account equals cs.Account into t_cs
                from record in t_cs.DefaultIfEmpty()
                join d in department on record.Department_ID equals d.Department_ID into t_d
                from t1 in t_d.DefaultIfEmpty()
                join c in company on record.Company_ID equals c.Company_ID into t1_c
                from t2 in t1_c.DefaultIfEmpty()
                join s in staff on record.Staff_ID equals s.Staff_ID into t2_s
                from t3 in t2_s.DefaultIfEmpty()
                join ms in staff on record.Manager_ID equals ms.Staff_ID into t3_ms
                from t4 in t3_ms.DefaultIfEmpty()
                join p in platform on t.Platform_ID equals p.Platform_ID into t4_p
                from final in t4_p.DefaultIfEmpty()
                where (!string.IsNullOrEmpty(account) ? t.Customer_Account.Equals(account) : true)
                    && (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Customer_Name, "%" + name + "%") : true)
                    && (platformID > 0 ? t.Platform_ID.Equals(platformID) : true)
                    //&& (!actionDate.Equals(Config.SQL_Default_Date) ? t.Action_Date.Equals(actionDate) : true) 
                    && t.Action_Date.CompareTo(startActionDate) >= 0
                    && t.Action_Date.CompareTo(endActionDate) <= 0
                select new { t, final.Platform_Name, t2.Company_Name, t1.Department_Name, t3.Name, ManagerName = t4.Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                CustomerRecordVO obj = item.t;
                obj = item.t;
                obj.Platform_Name = item.Platform_Name;
                obj.Department_Name = item.Department_Name;
                obj.Company_Name = item.Company_Name;
                obj.Staff_Name = item.Name;
                obj.Manager_Name = item.ManagerName;
                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordVO> GetCustomerIsNotCheckin(int page, int size, out int total)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            int start = page * size;

            List<CustomerRecordVO> objList = new List<CustomerRecordVO>();

            var query =
                from t in table
                where !(customer.Select(x => x.Account)).Contains(t.Customer_Account)
                group t by new { Customer_Account = t.Customer_Account, Customer_Name = t.Customer_Name } into g
                select new { g.Key.Customer_Account, g.Key.Customer_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                CustomerRecordVO obj = new CustomerRecordVO();
                obj.Customer_Name = item.Customer_Name;
                obj.Customer_Account = item.Customer_Account;
                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordDailyVO> GetCustomerDataByDate(int companyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                //join c in customer on t.Customer_Account equals c.Account 
                //join s in cStaff on t.Customer_Account equals s.Account 
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && (companyID > 0 ? d.Company_ID.Equals(companyID) : true)
                group new { t.Department_ID, t.In_Out_Money, t.Gross_Money, t.Offset_Profit, t.Position_Profit, t.Get_Fee, t.End_Interest, t.Get_Delay }
                by t.Department_ID into b
                select new
                {
                    Department_ID = b.Key,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Offset_Profit = b.Sum(i => i.Offset_Profit),
                    Position_Profit = b.Sum(i => i.Position_Profit),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                    Get_Delay = b.Sum(i => i.Get_Delay),
                    End_Interest = b.Sum(i => i.End_Interest)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Department_ID;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Gross_Money = item.Gross_Money;
                obj.Offset_Profit = item.Offset_Profit;
                obj.Position_Profit = item.Position_Profit;
                obj.Sum_Profit = (item.Offset_Profit + item.Position_Profit) * -1;//盈亏
                obj.Get_Fee = item.Get_Fee;
                obj.Get_Delay = item.Get_Delay;
                obj.End_Interest = item.End_Interest;
                obj.Income = 0.908 * (obj.Sum_Profit + obj.Get_Fee * 0.75 + obj.Get_Delay);//累积收入

                objList.Add(obj);
            }

            return objList;
        }

        //部门总监数控日报
        public List<CustomerRecordDailyVO> GetCustomerDataByDepartmentID(int DepartmentID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                //join c in customer on t.Customer_Account equals c.Account 
                //join s in cStaff on t.Customer_Account equals s.Account 
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                group new { t.Department_ID, t.In_Out_Money, t.Gross_Money, t.Offset_Profit, t.Position_Profit, t.Get_Fee, t.End_Interest, t.Get_Delay }
                by t.Department_ID into b
                select new
                {
                    Department_ID = b.Key,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Offset_Profit = b.Sum(i => i.Offset_Profit),
                    Position_Profit = b.Sum(i => i.Position_Profit),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                    Get_Delay = b.Sum(i => i.Get_Delay),
                    End_Interest = b.Sum(i => i.End_Interest)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Department_ID;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Gross_Money = item.Gross_Money;
                obj.Offset_Profit = item.Offset_Profit;
                obj.Position_Profit = item.Position_Profit;
                obj.Sum_Profit = (item.Offset_Profit + item.Position_Profit) * -1;//盈亏
                obj.Get_Fee = item.Get_Fee;
                obj.Get_Delay = item.Get_Delay;
                obj.End_Interest = item.End_Interest;
                obj.Income = 0.908 * (obj.Sum_Profit + obj.Get_Fee * 0.75 + obj.Get_Delay);//累积收入

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordDailyVO> GetCustomerDataEndInterestByDepartmentID(int DepartmentID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                group new { t.Department_ID, t.End_Interest }
                by t.Department_ID into b
                select new
                {
                    Department_ID = b.Key,
                    End_Interest = b.Sum(i => i.End_Interest)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Department_ID;
                obj.End_Interest = item.End_Interest;

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordDailyVO> GetNewCustomerDataByDepartmentID(int DepartmentID, DateTime startDate, DateTime endDate, DateTime monthStart, DateTime monthEnd)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join c in customer on t.Customer_Account equals c.Account
                //join s in cStaff on t.Customer_Account equals s.Account 
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Add_Date.CompareTo(monthStart) >= 0
                    && c.Add_Date.CompareTo(monthEnd) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                group new { t.Department_ID, t.In_Out_Money }
                by t.Department_ID into b
                select new
                {
                    Department_ID = b.Key,
                    In_Out_Money = b.Sum(i => i.In_Out_Money)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Department_ID;
                obj.New_In_Out_Money = item.In_Out_Money;

                objList.Add(obj);
            }

            return objList;
        }

        //部门所有经理数控日报
        public CustomerRecordDailyVO GetCustomerDataByManager(int StaffID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerRecordVO> customerrecord = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<StaffVO> staff = ctx.StaffTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join cus in customerrecord on t.Account equals cus.Customer_Account
                join s in staff on t.Staff_ID equals s.Staff_ID
                join a in account on s.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where cus.Action_Date.CompareTo(startDate) >= 0
                    && cus.Action_Date.CompareTo(endDate) <= 0
                    && p.Title_ID.Equals(6)
                    && s.Staff_ID.Equals(StaffID)
                    && s.Status_ID != 4
                    || cus.Action_Date.CompareTo(startDate) >= 0
                    && cus.Action_Date.CompareTo(endDate) <= 0
                    && p.Title_ID.Equals(6)
                    && s.Staff_ID.Equals(StaffID)
                    && s.Status_ID == 4
                    && s.Quit_Date >= endDate
                group new { s.Staff_ID, cus.In_Out_Money, cus.Gross_Money, cus.Get_Fee, cus.Offset_Profit, cus.Position_Profit }
                by new { s.Staff_ID } into b
                select new
                {
                    //Position_Name=b.Key.Position_Name,
                    //Staff_Name = b.Key.Name,
                    Staff_ID = b.Key.Staff_ID,
                    //User_Name = b.Key.User_Name,
                    //Company_Name = b.Key.Company_Name,
                    //Department_Name = b.Key.Department_Name,
                    Offset_Profit = b.Sum(i => i.Offset_Profit),
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Position_Profit = b.Sum(i => i.Position_Profit),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                };
            if (query.Count() == 0)
                return new CustomerRecordDailyVO();
            var model = query.First();


            CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
            obj.Staff_ID = model.Staff_ID;
            obj.In_Out_Money = model.In_Out_Money;
            obj.Gross_Money = model.Gross_Money;
            obj.Position_Profit = model.Position_Profit;
            obj.Sum_Profit = (model.Offset_Profit + model.Position_Profit) * -1;//盈亏


            return obj;
        }




        public List<CustomerRecordDailyVO> GetNewCustomerDataByDate(int companyID, DateTime startDate, DateTime endDate, DateTime monthStart, DateTime monthEnd)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join c in customer on t.Customer_Account equals c.Account
                //join s in cStaff on t.Customer_Account equals s.Account 
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Add_Date.CompareTo(monthStart) >= 0
                    && c.Add_Date.CompareTo(monthEnd) <= 0
                    && (companyID > 0 ? d.Company_ID.Equals(companyID) : true)
                group new { t.Department_ID, t.In_Out_Money }
                by t.Department_ID into b
                select new
                {
                    Department_ID = b.Key,
                    In_Out_Money = b.Sum(i => i.In_Out_Money)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Department_ID;
                obj.New_In_Out_Money = item.In_Out_Money;

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordDailyVO> GetNewCustomerDataByDays(int staffID, DateTime startDate, DateTime endDate, DateTime monthStart, DateTime monthEnd)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join c in customer on t.Customer_Account equals c.Account
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Add_Date.CompareTo(monthStart) >= 0
                    && c.Add_Date.CompareTo(monthEnd) <= 0
                    && (staffID > 0 ? t.Staff_ID.Equals(staffID) : true)
                group new { c.Account, t.In_Out_Money }
                by c.Account into b
                select new
                {
                    Account = b.Key,
                    In_Out_Money = b.Sum(i => i.In_Out_Money)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Account = item.Account;
                obj.New_In_Out_Money = item.In_Out_Money;

                objList.Add(obj);
            }

            return objList;
        }

        //业务经理下属数控日志
        public List<CustomerRecordDailyVO> GetNewCustomerDataByStaffID(int staffID, DateTime startDate, DateTime endDate, DateTime monthStart, DateTime monthEnd)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join c in customer on t.Customer_Account equals c.Account
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Add_Date.CompareTo(monthStart) >= 0
                    && c.Add_Date.CompareTo(monthEnd) <= 0
                    && t.Staff_ID.Equals(staffID)
                group new { c.Account, t.In_Out_Money }
                by c.Staff_ID into b
                select new
                {
                    Staff_ID = b.Key,
                    In_Out_Money = b.Sum(i => i.In_Out_Money)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Staff_ID = item.Staff_ID;
                obj.New_In_Out_Money = item.In_Out_Money;

                objList.Add(obj);
            }

            return objList;
        }


        public List<CustomerRecordDailyVO> GetCustomerDataEndInterestByDate(int companyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                //join c in customer on t.Customer_Account equals c.Account 
                //join s in cStaff on t.Customer_Account equals s.Account
                join d in department on t.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && (companyID > 0 ? d.Company_ID.Equals(companyID) : true)
                //&& s.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                group new { t.Department_ID, t.End_Interest }
                by t.Department_ID into b
                select new
                {
                    Department_ID = b.Key,
                    End_Interest = b.Sum(i => i.End_Interest)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Department_ID;
                obj.End_Interest = item.End_Interest;

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordDailyVO> GetCustomerDataEndInterestByDays(int staffID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join c in customer on t.Customer_Account equals c.Account
                join d in department on c.Department_ID equals d.Department_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && (staffID > 0 ? t.Staff_ID.Equals(staffID) : true)
                group new { c.Account, t.End_Interest }
                by c.Account into b
                select new
                {
                    Account = b.Key,
                    End_Interest = b.Sum(i => i.End_Interest)
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Account = item.Account;
                obj.End_Interest = item.End_Interest;

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordRankVO> GetCustomerTradeRankByDate(int companyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordRankVO> objList = new List<CustomerRecordRankVO>();

            var query =
                from t in table
                join s in cStaff on t.Customer_Account equals s.Account
                join d in department on s.Department_ID equals d.Department_ID
                join st in staff on s.Staff_ID equals st.Staff_ID
                join a in account on st.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && d.Company_ID.Equals(companyID)
                    && s.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                    && !s.Staff_ID.Equals(s.Manager_ID)
                group new { s.Staff_ID, t.In_Out_Money }
                by new { s.Staff_ID, d.Department_Name, st.Name, p.Position_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Staff_ID = b.Key.Staff_ID,
                    Department_Name = b.Key.Department_Name,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Staff_Name = b.Key.Name,
                    Position_Name = b.Key.Position_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CustomerRecordRankVO obj = new CustomerRecordRankVO();
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Staff_Name = item.Staff_Name;
                obj.Rank = rank++;
                obj.Position_Name = item.Position_Name;
                obj.Staff_ID = item.Staff_ID;

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordRankVO> GetDepartmentCustomerTradeRankByDate(int DepartmentID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordRankVO> objList = new List<CustomerRecordRankVO>();

            var query =
                from t in table
                join s in cStaff on t.Customer_Account equals s.Account
                join d in department on s.Department_ID equals d.Department_ID
                join st in staff on s.Staff_ID equals st.Staff_ID
                join a in account on st.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                    && s.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                    && !s.Staff_ID.Equals(s.Manager_ID)
                group new { s.Staff_ID, t.In_Out_Money }
                by new { s.Staff_ID, d.Department_Name, st.Name, p.Position_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Staff_ID = b.Key.Staff_ID,
                    Department_Name = b.Key.Department_Name,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Staff_Name = b.Key.Name,
                    Position_Name = b.Key.Position_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CustomerRecordRankVO obj = new CustomerRecordRankVO();
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Staff_Name = item.Staff_Name;
                obj.Rank = rank++;
                obj.Position_Name = item.Position_Name;
                obj.Staff_ID = item.Staff_ID;

                objList.Add(obj);
            }

            return objList;
        }


        public List<CustomerRecordRankVO> GetCustomerManagerTradeRankByDate(int companyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordRankVO> objList = new List<CustomerRecordRankVO>();

            var query =
                from t in table
                join s in cStaff on t.Customer_Account equals s.Account
                join d in department on s.Department_ID equals d.Department_ID
                join st in staff on s.Manager_ID equals st.Staff_ID
                join a in account on st.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && d.Company_ID.Equals(companyID)
                    && s.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                group new { s.Manager_ID, t.In_Out_Money }
                by new { s.Manager_ID, d.Department_Name, st.Name, p.Position_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Staff_ID = b.Key.Manager_ID,
                    Department_Name = b.Key.Department_Name,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Staff_Name = b.Key.Name,
                    Position_Name = b.Key.Position_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CustomerRecordRankVO obj = new CustomerRecordRankVO();
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Staff_Name = item.Staff_Name;
                obj.Rank = rank++;
                obj.Position_Name = item.Position_Name;
                obj.Staff_ID = item.Staff_ID;

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordRankVO> GetDepartmentCustomerManagerTradeRankByDate(int DepartmentID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerRecordRankVO> objList = new List<CustomerRecordRankVO>();

            var query =
                from t in table
                join s in cStaff on t.Customer_Account equals s.Account
                join d in department on s.Department_ID equals d.Department_ID
                join st in staff on s.Manager_ID equals st.Staff_ID
                join a in account on st.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                    && s.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                group new { s.Manager_ID, t.In_Out_Money }
                by new { s.Manager_ID, d.Department_Name, st.Name, p.Position_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Staff_ID = b.Key.Manager_ID,
                    Department_Name = b.Key.Department_Name,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Staff_Name = b.Key.Name,
                    Position_Name = b.Key.Position_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CustomerRecordRankVO obj = new CustomerRecordRankVO();
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Staff_Name = item.Staff_Name;
                obj.Rank = rank++;
                obj.Position_Name = item.Position_Name;
                obj.Staff_ID = item.Staff_ID;

                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerRecordVO> GetAllCustomerRecordByManagerID(int ManagerID, DateTime? ActionDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;

            var query = from t in table
                        where t.Manager_ID.Equals(ManagerID)
                            && t.Action_Date >= ActionDate
                            || t.Staff_ID.Equals(ManagerID)
                            && t.Action_Date >= ActionDate
                        select t;
            return query.ToList();
        }

        public void UpdateCustomerRecord(CustomerRecordVO item)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;

            var query =
                from t in table
                where t.ID.Equals(item.ID)
                select t;

            if (query.Count() == 0)
                return;

            List<CustomerRecordVO> list = query.ToList();
            foreach (CustomerRecordVO obj in list)
            {
                obj.Staff_ID = item.Staff_ID;
                obj.Manager_ID = item.Manager_ID;
                obj.Department_ID = item.Department_ID;
            }
            ctx.SubmitChanges();
        }

        public List<CompanyInOutMoneyRankVO> GetCompanyInOutMoneyRankByDate(DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyInOutMoneyRankVO> objList = new List<CompanyInOutMoneyRankVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                group new { c.Company_ID, t.In_Out_Money }
                by new { c.Company_ID, c.Company_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Company_ID = b.Key.Company_ID,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Company_Name = b.Key.Company_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyInOutMoneyRankVO obj = new CompanyInOutMoneyRankVO();
                obj.Company_ID = item.Company_ID;
                obj.Company_Name = item.Company_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }

        //部门净入金
        public List<CompanyInOutMoneyRankVO> GetDepartmentInOutMoneyRankByDate(int CompanyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyInOutMoneyRankVO> objList = new List<CompanyInOutMoneyRankVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Company_ID.Equals(CompanyID)
                    && d.Group_ID == 2

                group new { d.Department_ID, t.In_Out_Money }
                by new { d.Department_ID, d.Department_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Department_ID = b.Key.Department_ID,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Department_Name = b.Key.Department_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyInOutMoneyRankVO obj = new CompanyInOutMoneyRankVO();
                obj.Department_ID = item.Department_ID;
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }



        public List<CompanyInOutMoneyRankVO> GetCompanyGrossMoneyRankByDate(DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyInOutMoneyRankVO> objList = new List<CompanyInOutMoneyRankVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                group new { c.Company_ID, t.Gross_Money }
                by new { c.Company_ID, c.Company_Name } into b
                orderby b.Sum(i => i.Gross_Money) descending
                select new
                {
                    Company_ID = b.Key.Company_ID,
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Company_Name = b.Key.Company_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyInOutMoneyRankVO obj = new CompanyInOutMoneyRankVO();
                obj.Company_ID = item.Company_ID;
                obj.Company_Name = item.Company_Name;
                obj.In_Out_Money = item.Gross_Money;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }

        //部门毛入金
        public List<CompanyInOutMoneyRankVO> GetDepartmentGrossMoneyRankByDate(int CompanyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyInOutMoneyRankVO> objList = new List<CompanyInOutMoneyRankVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Company_ID.Equals(CompanyID)
                    && d.Group_ID == 2
                group new { d.Department_ID, t.Gross_Money }
                by new { d.Department_ID, d.Department_Name } into b
                orderby b.Sum(i => i.Gross_Money) descending
                select new
                {
                    Department_ID = b.Key.Department_ID,
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Department_Name = b.Key.Department_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyInOutMoneyRankVO obj = new CompanyInOutMoneyRankVO();
                obj.Department_ID = item.Department_ID;
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.Gross_Money;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }


        #endregion


        #region Customer Staff

        public void InsertCustomerStaff(CustomerStaffVO item)
        {
            ctx.CustomerStaffTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void UpdateCustomerStaff(CustomerStaffVO item)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;

            var query =
                from t in table
                where t.Account.Equals(item.Account)
                    && t.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                select t;

            if (query.Count() == 0)
                return;

            CustomerStaffVO obj = query.FirstOrDefault();
            obj.Status_ID = (int)Config.CustomerStaffStatus.Inactive;
            ctx.SubmitChanges();
        }

        public void UpdateCustomerStaffByCustomer(CustomerVO customer)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;

            var query =
                from t in table
                where t.Account.Equals(customer.Account)
                select t;

            if (query.Count() == 0)
                return;

            foreach (CustomerStaffVO item in query.ToList())
            {
                item.Account = customer.Account;
                item.Account_Name = customer.Name;
                item.Staff_ID = customer.Staff_ID;
                item.Manager_ID = customer.Manager_ID;
                item.Department_ID = customer.Department_ID;
            }
            ctx.SubmitChanges();
        }

        public CustomerStaffVO GetCustomerStaff(string account)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;

            var query =
                from t in table
                where t.Account.Equals(account)
                    && t.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<CustomerStaffVO> GetCustomerStaffsByDate(int platformID)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;
            Table<CustomerVO> customer = ctx.CustomerTable;

            var query =
                from t in table
                join c in customer on t.Account equals c.Account
                where c.Platform_ID.Equals(platformID)
                //&& t.Active_Date.CompareTo(date) <= 0
                orderby t.Active_Date descending
                select new { t, c.Add_Date };

            if (query.Count() == 0)
                return null;

            List<CustomerStaffVO> newList = new List<CustomerStaffVO>();
            foreach (var item in query.ToList())
            {
                CustomerStaffVO newItem = item.t;
                newItem.Add_Date = item.Add_Date;
                newList.Add(newItem);
            }

            return newList;
        }

        public CustomerStaffVO GetCustomerStaffByDate(string account, DateTime date)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;

            var query =
                from t in table
                where t.Account.Equals(account)
                    && t.Active_Date.CompareTo(date) <= 0
                orderby t.Active_Date descending
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<CustomerRecordDailyVO> GetCustomerCounts()
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;

            var query =
                from t in table
                group t by new { t.Department_ID } into g
                select new
                {
                    Customer_Count = g.Count(),
                    Depart_ID = g.Key.Department_ID
                };

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Depart_ID;
                obj.Customer_Count = item.Customer_Count;
                objList.Add(obj);
            }

            return objList;
        }




        public List<CustomerRecordDailyVO> GetNewCustomerCounts(DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            //Table<CustomerVO> customer = ctx.CustomerTable;

            var query =
                from t in table
                //join c in customer on t.Account equals c.Account
                where t.Add_Date.CompareTo(startDate) >= 0
                    && t.Add_Date.CompareTo(endDate) <= 0
                group t by new { t.Department_ID } into g
                select new
                {
                    New_Customer_Count = g.Count(),
                    Department_ID = g.Key.Department_ID
                };

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Department_ID = item.Department_ID;
                obj.New_Customer_Count = item.New_Customer_Count;
                objList.Add(obj);
            }

            return objList;
        }

        //经理下属开户数
        public List<CustomerRecordDailyVO> GetNewCustomerCount(int StaffID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                where t.Add_Date.CompareTo(startDate) >= 0
                    && t.Add_Date.CompareTo(endDate) <= 0
                    && t.Staff_ID.Equals(StaffID)
                group t by new { t.Staff_ID } into g
                select new
                {
                    New_Customer_Count = g.Count(),
                    Staff_ID = g.Key.Staff_ID
                };

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Staff_ID = item.Staff_ID;
                obj.New_Customer_Count = item.New_Customer_Count;
                objList.Add(obj);
            }

            return objList;
        }



        public int GetCustomerCount(int StaffID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;

            var query =
                from t in table
                where t.Add_Date.CompareTo(startDate) >= 0
                    && t.Add_Date.CompareTo(endDate) <= 0
                    && t.Staff_ID.Equals(StaffID)
                select t;

            return query.Count();
        }


        public List<CustomerStaffVO> GetCustomersRankByDate(int companyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerStaffVO> objList = new List<CustomerStaffVO>();

            var query =
                from t in table
                join c in customer on t.Account equals c.Account
                join s in staff on t.Staff_ID equals s.Staff_ID
                join a in account on s.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on t.Department_ID equals d.Department_ID
                where c.Add_Date.CompareTo(startDate) >= 0
                    && c.Add_Date.CompareTo(endDate) <= 0
                    && d.Company_ID.Equals(companyID)
                    && t.Active_Date.Equals(c.Add_Date)
                    && !t.Staff_ID.Equals(t.Manager_ID)
                group t.Staff_ID
                by new { t.Staff_ID, d.Department_Name, s.Name, p.Position_Name } into b
                orderby b.Count() descending
                select new
                {
                    Staff_ID = b.Key.Staff_ID,
                    Staff_Name = b.Key.Name,
                    Customers = b.Count(),
                    Department_Name = b.Key.Department_Name,
                    Position_Name = b.Key.Position_Name
                };

            int i = 1;
            foreach (var item in query.ToList())
            {
                CustomerStaffVO obj = new CustomerStaffVO();

                obj.Staff_ID = item.Staff_ID;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Staff_Name;
                obj.Customers = item.Customers;
                obj.Position_Name = item.Position_Name;
                obj.Rank = i++;
                objList.Add(obj);
            }

            return objList;
        }


        public List<CustomerStaffVO> GetDepartmentCustomersRankByDate(int DepartmentID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerStaffVO> objList = new List<CustomerStaffVO>();

            var query =
                from t in table
                join c in customer on t.Account equals c.Account
                join s in staff on t.Staff_ID equals s.Staff_ID
                join a in account on s.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on t.Department_ID equals d.Department_ID
                where c.Add_Date.CompareTo(startDate) >= 0
                    && c.Add_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                    && t.Active_Date.Equals(c.Add_Date)
                    && !t.Staff_ID.Equals(t.Manager_ID)
                group t.Staff_ID
                by new { t.Staff_ID, d.Department_Name, s.Name, p.Position_Name } into b
                orderby b.Count() descending
                select new
                {
                    Staff_ID = b.Key.Staff_ID,
                    Staff_Name = b.Key.Name,
                    Customers = b.Count(),
                    Department_Name = b.Key.Department_Name,
                    Position_Name = b.Key.Position_Name
                };

            int i = 1;
            foreach (var item in query.ToList())
            {
                CustomerStaffVO obj = new CustomerStaffVO();

                obj.Staff_ID = item.Staff_ID;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Staff_Name;
                obj.Customers = item.Customers;
                obj.Position_Name = item.Position_Name;
                obj.Rank = i++;
                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerStaffVO> GetCustomersManagerRankByDate(int companyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerStaffVO> objList = new List<CustomerStaffVO>();

            var query =
                from t in table
                join c in customer on t.Account equals c.Account
                join s in staff on t.Manager_ID equals s.Staff_ID
                join a in account on s.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on t.Department_ID equals d.Department_ID
                where c.Add_Date.CompareTo(startDate) >= 0
                    && c.Add_Date.CompareTo(endDate) <= 0
                    && d.Company_ID.Equals(companyID)
                    && t.Active_Date.Equals(c.Add_Date)
                group t.Manager_ID
                by new { t.Manager_ID, d.Department_Name, s.Name, p.Position_Name } into b
                orderby b.Count() descending
                select new
                {
                    Staff_ID = b.Key.Manager_ID,
                    Staff_Name = b.Key.Name,
                    Customers = b.Count(),
                    Department_Name = b.Key.Department_Name,
                    Position_Name = b.Key.Position_Name
                };

            int i = 1;
            foreach (var item in query.ToList())
            {
                CustomerStaffVO obj = new CustomerStaffVO();

                obj.Staff_ID = item.Staff_ID;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Staff_Name;
                obj.Customers = item.Customers;
                obj.Position_Name = item.Position_Name;
                obj.Rank = i++;
                objList.Add(obj);
            }

            return objList;
        }

        public List<CustomerStaffVO> GetDepartmentCustomersManagerRankByDate(int DepartmentID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<CustomerVO> customer = ctx.CustomerTable;
            Table<StaffVO> staff = ctx.StaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            List<CustomerStaffVO> objList = new List<CustomerStaffVO>();

            var query =
                from t in table
                join c in customer on t.Account equals c.Account
                join s in staff on t.Manager_ID equals s.Staff_ID
                join a in account on s.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on t.Department_ID equals d.Department_ID
                where c.Add_Date.CompareTo(startDate) >= 0
                    && c.Add_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                    && t.Active_Date.Equals(c.Add_Date)
                group t.Manager_ID
                by new { t.Manager_ID, d.Department_Name, s.Name, p.Position_Name } into b
                orderby b.Count() descending
                select new
                {
                    Staff_ID = b.Key.Manager_ID,
                    Staff_Name = b.Key.Name,
                    Customers = b.Count(),
                    Department_Name = b.Key.Department_Name,
                    Position_Name = b.Key.Position_Name
                };

            int i = 1;
            foreach (var item in query.ToList())
            {
                CustomerStaffVO obj = new CustomerStaffVO();

                obj.Staff_ID = item.Staff_ID;
                obj.Department_Name = item.Department_Name;
                obj.Staff_Name = item.Staff_Name;
                obj.Customers = item.Customers;
                obj.Position_Name = item.Position_Name;
                obj.Rank = i++;
                objList.Add(obj);
            }

            return objList;
        }


        public List<CustomerStaffVO> GetCustomerStaffByManagerID(int ManagerID)
        {
            Table<CustomerStaffVO> table = ctx.CustomerStaffTable;

            var query =
                from t in table
                where t.Manager_ID.Equals(ManagerID)
                    && t.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                    || t.Staff_ID.Equals(ManagerID)
                    && t.Status_ID.Equals((int)Config.CustomerStaffStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.ToList();
        }

        #endregion


        #region Customer Platform

        public List<CustomerPlatformVO> GetCustomerPlatform()
        {
            Table<CustomerPlatformVO> table = ctx.CustomerPlatformTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            return query.ToList();
        }

        #endregion


        //经理业务员数控日报
        public List<CustomerRecordDailyVO> GetCustomerDataByDays(int staffID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerRecordVO> customerrecord = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join cus in customerrecord on t.Account equals cus.Customer_Account
                join d in department on t.Department_ID equals d.Department_ID

                join c in company on d.Company_ID equals c.Company_ID
                where cus.Action_Date.CompareTo(startDate) >= 0
                    && cus.Action_Date.CompareTo(endDate) <= 0
                    && cus.Staff_ID.Equals(staffID)
                group new { c.Company_Name, d.Department_Name, t.Name, t.Account, cus.In_Out_Money, cus.Gross_Money, cus.Get_Fee }
                by new { t.Account, c.Company_Name, d.Department_Name, t.Name } into b
                select new
                {
                    Account = b.Key.Account,
                    Company_Name = b.Key.Company_Name,
                    Name = b.Key.Name,
                    Department_Name = b.Key.Department_Name,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Account = item.Account;
                obj.Name = item.Name;
                obj.Company_Name = item.Company_Name;
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Gross_Money = item.Gross_Money;
                obj.Get_Fee = item.Get_Fee;

                objList.Add(obj);
            }

            return objList;
        }


        //部门业务员数控日报
        public List<CustomerRecordDailyVO> GetCustomerDataByStaffNumber(int DepartmentID, int StaffNumber, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerRecordVO> customerrecord = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            Table<StaffVO> staff = ctx.StaffTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join cus in customerrecord on t.Account equals cus.Customer_Account
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                join s in staff on t.Staff_ID equals s.Staff_ID
                where cus.Action_Date.CompareTo(startDate) >= 0
                    && cus.Action_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                    && (StaffNumber > 0 ? s.Staff_Number.Equals(StaffNumber) : true)
                group new { c.Company_Name, d.Department_Name, t.Name, t.Account, cus.In_Out_Money, cus.Gross_Money, cus.Get_Fee }
                by new { t.Account, c.Company_Name, d.Department_Name, t.Name, s } into b
                select new
                {
                    Staff_Name = b.Key.s.Name,
                    Staff_Number = b.Key.s.Staff_Number,
                    Account = b.Key.Account,
                    Company_Name = b.Key.Company_Name,
                    Name = b.Key.Name,
                    Department_Name = b.Key.Department_Name,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Account = item.Account;
                obj.Staff_Number = CommonHelper.StaffNumberLength(item.Staff_Number);
                obj.Staff_Name = item.Staff_Name;
                obj.Name = item.Name;
                obj.Company_Name = item.Company_Name;
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Gross_Money = item.Gross_Money;
                obj.Get_Fee = item.Get_Fee;

                objList.Add(obj);
            }

            return objList;
        }



        //经理数控日报
        public List<CustomerRecordDailyVO> GetCustomerDataBymanagerID(int staffID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerRecordVO> customerrecord = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join cus in customerrecord on t.Account equals cus.Customer_Account
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where cus.Action_Date.CompareTo(startDate) >= 0
                    && cus.Action_Date.CompareTo(endDate) <= 0
                    && t.Staff_ID.Equals(staffID)
                group new { t.Name, t.Account, cus.In_Out_Money, cus.Gross_Money, cus.Get_Fee, cus.Offset_Profit, cus.Position_Profit }
                by new { t.Name, t.Account } into b
                select new
                {
                    Account = b.Key.Account,
                    //Company_Name = b.Key.Company_Name,
                    Name = b.Key.Name,
                    //Department_Name = b.Key.Department_Name,
                    Offset_Profit = b.Sum(i => i.Offset_Profit),
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Position_Profit = b.Sum(i => i.Position_Profit),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Account = item.Account;
                obj.Name = item.Name;
                //obj.Company_Name = item.Company_Name;
                //obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Gross_Money = item.Gross_Money;
                obj.Position_Profit = item.Position_Profit;
                obj.Sum_Profit = (item.Offset_Profit + item.Position_Profit) * -1;//盈亏
                obj.Get_Fee = item.Get_Fee;

                objList.Add(obj);
            }

            return objList;
        }



        //经理下属数控日报
        public List<CustomerRecordDailyVO> GetCustomerDataBystaffID(int[] statusIDs, int PositionID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerRecordVO> customerrecord = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<StaffVO> staff = ctx.StaffTable;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join cus in customerrecord on t.Account equals cus.Customer_Account
                join s in staff on t.Staff_ID equals s.Staff_ID
                join a in account on s.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where cus.Action_Date.CompareTo(startDate) >= 0
                    && cus.Action_Date.CompareTo(endDate) <= 0
                    && p.Superior_ID.Equals(PositionID)
                    && (statusIDs.Length > 0 ? statusIDs.Contains(s.Status_ID) : false)
                group new { c.Company_Name, d.Department_Name, s.Name, cus.In_Out_Money, cus.Gross_Money, cus.Get_Fee, cus.Offset_Profit, cus.Position_Profit }
                by new { c.Company_Name, d.Department_Name, s.Name, s.Staff_ID, a.User_Name, s.Status_ID } into b
                select new
                {
                    Staff_Name = b.Key.Name,
                    Staff_ID = b.Key.Staff_ID,
                    Status_ID = b.Key.Status_ID,
                    User_Name = b.Key.User_Name,
                    Company_Name = b.Key.Company_Name,
                    Department_Name = b.Key.Department_Name,
                    Offset_Profit = b.Sum(i => i.Offset_Profit),
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Position_Profit = b.Sum(i => i.Position_Profit),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                };

            foreach (var item in query.ToList())
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Staff_Name = item.Staff_Name;
                obj.Staff_ID = item.Staff_ID;
                obj.Status_ID = item.Status_ID;
                obj.User_Name = item.User_Name;
                obj.Company_Name = item.Company_Name;
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Gross_Money = item.Gross_Money;
                obj.Position_Profit = item.Position_Profit;
                obj.Sum_Profit = (item.Offset_Profit + item.Position_Profit) * -1;//盈亏
                obj.Get_Fee = item.Get_Fee;

                objList.Add(obj);
            }

            return objList;
        }



        //各运营中心月开户数
        public List<CompanyAccountRank> GetCompanyAccountRankByDate(DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyAccountRank> objList = new List<CompanyAccountRank>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Add_Date.CompareTo(startDate) >= 0
                    && t.Add_Date.CompareTo(endDate) < 0
                    && c.Status_ID.Equals((int)Config.PositionStatus.Active)
                group c.Company_ID
                by new { c.Company_ID, c.Company_Name } into b
                select new
                {
                    total = b.Count(),
                    Company_ID = b.Key.Company_ID,
                    Company_Name = b.Key.Company_Name
                };


            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyAccountRank obj = new CompanyAccountRank();
                obj.Company_ID = item.Company_ID;
                obj.Company_Name = item.Company_Name;
                obj.total = item.total;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }


        //各部门月开户数
        public List<CompanyAccountRank> GetDepartmentAccountRankByDate(int CompanyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyAccountRank> objList = new List<CompanyAccountRank>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Add_Date.CompareTo(startDate) >= 0
                    && t.Add_Date.CompareTo(endDate) < 0
                    && c.Company_ID.Equals(CompanyID)
                group c.Company_ID
                by new { d.Department_ID, d.Department_Name } into b
                select new
                {
                    total = b.Count(),
                    Department_ID = b.Key.Department_ID,
                    Department_Name = b.Key.Department_Name
                };


            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyAccountRank obj = new CompanyAccountRank();
                obj.Department_ID = item.Department_ID;
                obj.Department_Name = item.Department_Name;
                obj.total = item.total;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }

        //各单位坐席入金比例
        public List<CompanyInOutMoneyRankVO> GetCompanyAverageInOutMoneyRankByDate(DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyInOutMoneyRankVO> objList = new List<CompanyInOutMoneyRankVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                     && c.Status_ID.Equals(Config.PaymentType.instantly)
                     && !c.Company_ID.Equals(Config.Headquarters)
                group new { c.Company_ID, t.In_Out_Money }
                by new { c.Company_ID, c.Company_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Company_ID = b.Key.Company_ID,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Company_Name = b.Key.Company_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyInOutMoneyRankVO obj = new CompanyInOutMoneyRankVO();
                obj.Company_ID = item.Company_ID;
                obj.Company_Name = item.Company_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }


        //各部门坐席位均入金比例
        public List<CompanyInOutMoneyRankVO> GetDepartmentAverageInOutMoneyRankByDate(int CompanyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerRecordVO> table = ctx.CustomerRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CompanyInOutMoneyRankVO> objList = new List<CompanyInOutMoneyRankVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Action_Date.CompareTo(startDate) >= 0
                    && t.Action_Date.CompareTo(endDate) <= 0
                    && c.Company_ID.Equals(CompanyID)
                    && d.Group_ID.Equals(2)
                group new { d.Department_ID, t.In_Out_Money }
                by new { d.Department_ID, d.Department_Name } into b
                orderby b.Sum(i => i.In_Out_Money) descending
                select new
                {
                    Department_ID = b.Key.Department_ID,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Department_Name = b.Key.Department_Name
                };

            int rank = 1;
            foreach (var item in query.ToList())
            {
                CompanyInOutMoneyRankVO obj = new CompanyInOutMoneyRankVO();
                obj.Department_ID = item.Department_ID;
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Rank = rank++;

                objList.Add(obj);
            }

            return objList;
        }



        public List<CustomerVO> GetCompanyAverageTheAmountOfAccountsRankByDate(int CompanyID, DateTime startDate, DateTime endDate)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<CustomerVO> objList = new List<CustomerVO>();

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Add_Date.Date.CompareTo(startDate) >= 0
                    && t.Add_Date.Date.CompareTo(endDate) < 0
                    && c.Company_ID.Equals(CompanyID)
                select new
                {
                    Account = t.Account,
                    Company_ID = c.Company_ID,
                    Company_Name = c.Company_Name

                };

            foreach (var item in query)
            {
                CustomerVO obj = new CustomerVO();
                obj.Account = item.Account;
                obj.Company_ID = item.Company_ID;
                obj.Company_Name = item.Company_Name;
                objList.Add(obj);
            }
            return objList;
        }

        //周开户量
        public int GetWeekAccountsRankByCompanyID(int CompanyID, DateTime date)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Add_Date.Date.CompareTo(date.Date) == 0
                && d.Company_ID.Equals(CompanyID)
                select t;

            int Number = query.Count();

            return Number;
        }
        public int GetWeekAccountsRankByplatformID(int platformID, DateTime date)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerPlatformVO> platform = ctx.CustomerPlatformTable;

            var query =
                from t in table
                join p in platform on t.Platform_ID equals p.Platform_ID
                where t.Add_Date.Date.CompareTo(date.Date) == 0
                && p.Platform_ID.Equals(platformID)
                select t;

            int Number = query.Count();

            return Number;
        }

        public List<CustomerRecordDailyVO> GetCustomerDataByStaffNumber(int DepartmentID, int StaffNumber, DateTime startDate, DateTime endDate, int page, int size, out int total)
        {
            Table<CustomerVO> table = ctx.CustomerTable;
            Table<CustomerRecordVO> customerrecord = ctx.CustomerRecordTable;
            Table<CustomerStaffVO> cStaff = ctx.CustomerStaffTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            Table<StaffVO> staff = ctx.StaffTable;
            int start = page * size;

            List<CustomerRecordDailyVO> objList = new List<CustomerRecordDailyVO>();

            var query =
                from t in table
                join cus in customerrecord on t.Account equals cus.Customer_Account
                join d in department on t.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                join s in staff on t.Staff_ID equals s.Staff_ID
                where cus.Action_Date.CompareTo(startDate) >= 0
                    && cus.Action_Date.CompareTo(endDate) <= 0
                    && d.Department_ID.Equals(DepartmentID)
                    && (StaffNumber > 0 ? s.Staff_Number.Equals(StaffNumber) : true)
                group new { c.Company_Name, d.Department_Name, t.Name, t.Account, cus.In_Out_Money, cus.Gross_Money, cus.Get_Fee }
                by new { t.Account, c.Company_Name, d.Department_Name, t.Name, s } into b
                select new
                {
                    Staff_Name = b.Key.s.Name,
                    Staff_Number = b.Key.s.Staff_Number,
                    Account = b.Key.Account,
                    Company_Name = b.Key.Company_Name,
                    Name = b.Key.Name,
                    Department_Name = b.Key.Department_Name,
                    In_Out_Money = b.Sum(i => i.In_Out_Money),
                    Gross_Money = b.Sum(i => i.Gross_Money),
                    Get_Fee = b.Sum(i => i.Get_Fee),
                };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                CustomerRecordDailyVO obj = new CustomerRecordDailyVO();
                obj.Account = item.Account;
                obj.Staff_Number = CommonHelper.StaffNumberLength(item.Staff_Number);
                obj.Staff_Name = item.Staff_Name;
                obj.Name = item.Name;
                obj.Company_Name = item.Company_Name;
                obj.Department_Name = item.Department_Name;
                obj.In_Out_Money = item.In_Out_Money;
                obj.Gross_Money = item.Gross_Money;
                obj.Get_Fee = item.Get_Fee;

                objList.Add(obj);
            }

            return objList;
        }


        public List<CustomerPlatformVO> GetPresetCustomer(int companyID)
        {
             Table<CustomerPlatformVO> table = ctx.CustomerPlatformTable;
            Table<CompanyPlatformVO> companyplatform = ctx.CompanyPlatformTable;


            var query = from t in table
                        join p in companyplatform on t.Platform_ID equals p.Platform_ID
                        where p.Company_ID.Equals(companyID)
                        select t;
               

            return query.ToList();
        }


    }
}
