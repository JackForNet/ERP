﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertCycleBonusRecord(CycleBonusRecordVO item)
        {
            ctx.AdminCycleBonusRecordTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.PID;
        }

        public List<CycleBonusRecordVO> GetCycleBonusByPaymentID(int PaymentID)
        {
            Table<CycleBonusRecordVO> table = ctx.AdminCycleBonusRecordTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join d in department on t.Department_ID equals d.Department_ID
                join s in staff on t.Staff_ID equals s.Staff_ID
                where t.Payment_ID.Equals(PaymentID)
                select new { t.Achievement,t.Reward,t.Rank,d.Department_Name,s.Name  };


            List<CycleBonusRecordVO> list = new List<CycleBonusRecordVO>();
            if (query.Count() > 0)
            {
                foreach (var item in query.ToList())
                {
                    CycleBonusRecordVO obj = new CycleBonusRecordVO();
                    obj.Achievement = item.Achievement;
                    obj.Reward = item.Reward;
                    obj.Rank = item.Rank;
                    obj.Department_Name = item.Department_Name;
                    obj.User_Name = item.Name;

                    list.Add(obj);
                }
            }


            return list.ToList();

        }
    }
}
