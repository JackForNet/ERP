﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        //private static string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings["DBConnString"].ConnectionString);

        NorthwindDataContext ctx = new NorthwindDataContext(Config.DataBase_Conn);
    }
}
