﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<DepartmentVO> GetDepartment(int companyID)
        {
            Table<DepartmentVO> table = ctx.DepartmentTable;
            
            var query =
                from t in table
                where t.Company_ID.Equals(companyID)
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                orderby t.Department_Name 
                select t;

            return query.ToList();
        }

        public List<DepartmentVO> GetDepartment1(int companyID)
        {
            Table<DepartmentVO> table = ctx.DepartmentTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID)
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                && t.Group_ID.Equals(2)
                orderby t.Department_Name
                select t;

            return query.ToList();
        }


        public List<DepartmentVO> GetDepartmentOperate(int companyID)
        {
            Table<DepartmentVO> table = ctx.DepartmentTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID)
                &&t.Department_Name=="职能部"
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                || t.Company_ID.Equals(companyID)
                && t.Department_Name == "总经办"
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                orderby t.Department_Name
                select t;

            return query.ToList();
        }


        
        public List<DepartmentVO> GetDepartmentStaffCount(int companyID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where d.Company_ID.Equals(companyID)
                    && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && d.Status_ID.Equals((int)Config.PositionStatus.Active)
                group t by new {d.Department_ID,d.Department_Name} into tmp
                select new { tmp.Key, Total = tmp.Count()};

            var list = query.ToList();

            List<DepartmentVO> deptList = new List<DepartmentVO>();
            foreach (var item in list)
            {
                DepartmentVO dept = new DepartmentVO();
                dept.Department_ID = item.Key.Department_ID;
                dept.Department_Name = item.Key.Department_Name;
                dept.Staff_Count = item.Total;
                deptList.Add(dept);
            }

            return deptList;
        }

        public DepartmentVO GetDepartmentByID(int id)
        {
            Table<DepartmentVO> table = ctx.DepartmentTable;

            var query =
                from t in table
                where t.Department_ID.Equals(id)
                && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();

        }

        public List<DepartmentVO> GetAllDepartment()
        {
            Table<DepartmentVO> table = ctx.DepartmentTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select t;

            return query.ToList();
        }

        public List<DepartmentVO> GetAllDepartmentCompany()
        {
            Table<DepartmentVO> table = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table
                join c in company on t.Company_ID equals c.Company_ID
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select new { t, c.Company_Name};

            List<DepartmentVO> objList = new List<DepartmentVO>();
            foreach (var item in query.ToList())
            {
                DepartmentVO obj = new DepartmentVO();
                obj = item.t;
                obj.CompanyName = item.Company_Name;
                objList.Add(obj);
            }

            return objList;
        }

        public int InsertDepartment(DepartmentVO item)
        {
            ctx.DepartmentTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Department_ID;
        }

        public void UpdateDepartment(DepartmentVO item)
        {
            ctx.SubmitChanges();
        }

        public int DeleteDepartment(DepartmentVO item)
        {
            item.Status_ID = 0;
            ctx.SubmitChanges();
            return item.Department_ID;
        }

    }
}
