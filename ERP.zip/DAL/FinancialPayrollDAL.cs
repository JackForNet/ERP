﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void InsertFinancialPayorll(FinancialPayorllVO item)
        {
            ctx.FinancialPayorllTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void DeleteFinancialPayorll()
        {
            Table<FinancialPayorllVO> model = ctx.FinancialPayorllTable;
            var query =from r in model 
                         select r;
            ctx.FinancialPayorllTable.DeleteAllOnSubmit(query);
            ctx.SubmitChanges();
        }

        public void TruncateTable(string table_name)
        {
            ctx.ExecuteCommand("TRUNCATE TABLE " + table_name);
        }
    }
}
