﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void UpdateCancelLeaveByTask(int taskID)
        {
            Table<HRCancelLeaveVO> table = ctx.HRCancelLeaveTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public int InsertCancelLeave(HRCancelLeaveVO item)
        {
            ctx.HRCancelLeaveTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Cancel_ID;
        }

        public List<HRCancelLeaveVO> GetCancelLeaveByTask(int taskID)
        {
            Table<HRCancelLeaveVO> table = ctx.HRCancelLeaveTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

            //List<LeaveVO> objList = new List<LeaveVO>();
            //foreach (var item in query.ToList())
            //{
            //    LeaveVO obj = item.t;
            //    obj.Type_Name = item.Type_Name;

            //    objList.Add(obj);
            //}
            //return objList;

        }

        public List<HRCancelLeaveVO> GetCancelLeaveByAccount(int accountID, DateTime date)
        {
            return GetCancelLeaveByAccount(accountID, date, date);
        }

        public List<HRCancelLeaveVO> GetCancelLeaveByAccount(int accountID, DateTime start, DateTime end)
        {
            Table<HRCancelLeaveVO> table = ctx.HRCancelLeaveTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from t in table
                join tk in task on t.Task_ID equals tk.Task_ID
                where t.Account_ID.Equals(accountID)
                    && t.Leave_Date.CompareTo(start) >= 0
                    && t.Leave_Date.CompareTo(end) <= 0
                    && (tk.Status_ID.Equals((int)Config.TaskStatus.Active) || tk.Status_ID.Equals((int)Config.TaskStatus.Finish))
                select t;

            return query.ToList();
        }

        public List<HRCancelLeaveVO> GetFinishCancelLeaveByAccount(int accountID, DateTime date)
        {
            return GetFinishCancelLeaveByAccount(accountID, date, date);
        }

        public List<HRCancelLeaveVO> GetFinishCancelLeaveByAccount(int accountID, DateTime start, DateTime end)
        {
            Table<HRCancelLeaveVO> table = ctx.HRCancelLeaveTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from t in table
                join tk in task on t.Task_ID equals tk.Task_ID
                where t.Account_ID.Equals(accountID)
                    && t.Leave_Date.CompareTo(start) >= 0
                    && t.Leave_Date.CompareTo(end) <= 0
                    && tk.Status_ID.Equals((int)Config.TaskStatus.Finish) 
                select t;

            return query.ToList();
        }
    }
}
