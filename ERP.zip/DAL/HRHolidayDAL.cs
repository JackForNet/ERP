﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<HRHolidayVO> GetHoliday(DateTime start, DateTime end)
        {
            Table<HRHolidayVO> table = ctx.HRHolidayTable;

            var query =
                from t in table
                where t.Holiday_Date.CompareTo(start) >= 0
                    && t.Holiday_Date.CompareTo(end) <= 0
                select t;

            return query.ToList();
        }

        public HRHolidayVO GetHoliday(int id)
        {
            Table<HRHolidayVO> table = ctx.HRHolidayTable;

            var query =
                from t in table
                where t.Holiday_ID.Equals(id)
                select t;

            if (query.Count() == 0)
                return null;

            return query.FirstOrDefault();
        }

        public bool IsExistHoliday(DateTime date)
        {
            Table<HRHolidayVO> table = ctx.HRHolidayTable;

            var query =
                from t in table
                where t.Holiday_Date.Equals(date)
                select t;

            return query.Count() > 0;
        }

        public void InsertHoliday(HRHolidayVO item)
        {
            if (item == null)
                return;
            ctx.HRHolidayTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }
        public void InsertHoliday(List<HRHolidayVO> list)
        {
            if (list.Count == 0)
                return;
            ctx.HRHolidayTable.InsertAllOnSubmit(list);
            ctx.SubmitChanges();
        }

        public void UpdateHolidayType(HRHolidayVO item)
        {
            Table<HRHolidayVO> table = ctx.HRHolidayTable;

            var query =
                from t in table
                where t.Holiday_Date.Equals(item.Holiday_Date)
                select t;

            if (query.Count() == 0)
                return;

            HRHolidayVO obj = query.FirstOrDefault();
            obj.Holiday_Type_ID = item.Holiday_Type_ID;
            obj.Holiday_Type_Name = item.Holiday_Type_Name;
            ctx.SubmitChanges();
        }

        public void UpdateHolidayDate(HRHolidayVO item)
        {
            Table<HRHolidayVO> table = ctx.HRHolidayTable;

            var query =
                from t in table
                where t.Holiday_ID.Equals(item.Holiday_ID)
                select t;

            if (query.Count() == 0)
                return;

            HRHolidayVO obj = query.FirstOrDefault();
            obj.Holiday_Date = item.Holiday_Date;
            ctx.SubmitChanges();
        }

        public void DeleteHoliday(int id)
        {
            Table<HRHolidayVO> table = ctx.HRHolidayTable;

            var query =
                from t in table
                where t.Holiday_ID.Equals(id)
                select t;

            HRHolidayVO item = query.FirstOrDefault();

            ctx.HRHolidayTable.DeleteOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void DeleteHoliday(DateTime start, DateTime end)
        {
            Table<HRHolidayVO> table = ctx.HRHolidayTable;

            var query =
                from t in table
                where t.Holiday_Date.CompareTo(start) >= 0
                    && t.Holiday_Date.CompareTo(end) <= 0
                select t;

            List<HRHolidayVO> list = query.ToList();
            if (list.Count == 0)
                return;

            ctx.HRHolidayTable.DeleteAllOnSubmit(list);
            ctx.SubmitChanges();
        }
    }
}
