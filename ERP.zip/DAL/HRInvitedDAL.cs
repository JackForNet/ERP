﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<HRInvitedVO> GetAllHRInvited()
        {
            Table<HRInvitedVO> table = ctx.HRInvitedTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }



        public string GetHRInvitedByInvitedID(int InvitedID)
        {
            Table<HRInvitedVO> table = ctx.HRInvitedTable;
            var query =
                from t in table
                where t.Invited_ID == InvitedID
                select t.Be_Invited;

            return query.FirstOrDefault();
        }
    }
}
