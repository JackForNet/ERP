﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertPositive(HRPositiveVO item)
        {
            ctx.HRPositiveTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Positive_ID;
        }

        public List<HRPositiveVO> GetPositiveByTask(int taskID)
        {
            Table<HRPositiveVO> table = ctx.HRPositiveTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();
        }

        public void UpdatePositiveByTask(int taskID)
        {
            Table<HRPositiveVO> table = ctx.HRPositiveTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public bool IsExistPositive(int accountID)
        {
            Table<HRPositiveVO> table = ctx.HRPositiveTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from t in table
                join tk in task on t.Task_ID equals tk.Task_ID
                where t.Account_ID.Equals(accountID)
                    && (tk.Status_ID.Equals((int)Config.TaskStatus.Active) || tk.Status_ID.Equals((int)Config.TaskStatus.Finish))
                select t;

            return query.Count() > 0;
        }

        public List<EvaluationResultsVO> GetEvaluationResults()
        {
            Table<EvaluationResultsVO> table = ctx.EvaluationResultsTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }
    }
}
