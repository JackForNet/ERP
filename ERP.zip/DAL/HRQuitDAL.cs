﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {

        public void UpdateQuitByTask(int taskID)
        {
            Table<HRQuitVO> table = ctx.HRQuitTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public int InsertQuit(HRQuitVO item)
        {
            ctx.HRQuitTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Quit_ID;
        }

        public List<HRQuitVO> GetQuitByTask(int taskID)
        {
            Table<HRQuitVO> table = ctx.HRQuitTable;
            Table<QuitTypeVO> type = ctx.QuitTypeTable;

            var query =
                from t in table
                join a in type on t.Quit_Type equals a.Type_ID
                where t.Task_ID.Equals(taskID)
                select new { t, a.Type_Name };

            //return query.ToList();

            List<HRQuitVO> objList = new List<HRQuitVO>();
            foreach (var item in query.ToList())
            {
                HRQuitVO obj = item.t;
                obj.Type_Name = item.Type_Name;

                objList.Add(obj);
            }
            return objList;

        }

        public int CheckStaffHasQuit(int accountID)
        {
            Table<HRQuitVO> table = ctx.HRQuitTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from t in table
                join tk in task on t.Task_ID equals tk.Task_ID
                where t.Account_ID.Equals(accountID)
                && (tk.Status_ID.Equals((int)Config.TaskStatus.Active) || tk.Status_ID.Equals((int)Config.TaskStatus.Finish))
                select t;

            return query.Count();

        }
    }
}
