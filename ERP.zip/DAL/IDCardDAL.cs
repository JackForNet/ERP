﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertIDCard(IDCardVO card)
        {
            ctx.IDCardTable.InsertOnSubmit(card);
            ctx.SubmitChanges();
            return card.PID;
        }

        public void UpdateIDCard(IDCardVO card)
        {
            Table<IDCardVO> table = ctx.IDCardTable;

            var query =
                from t in table
                where t.PID.Equals(card.PID)
                select t;

            IDCardVO obj = query.First();
            obj = card;
            ctx.SubmitChanges();
        }

        public int GetIDCard(IDCardVO card)
        {
            Table<IDCardVO> table = ctx.IDCardTable;

            var query =
                from t in table
                where t.Card_Number.Equals(card.Card_Number)
                    //&& t.Start_Date.Equals(card.Start_Date)
                    //&& t.End_Date.Equals(card.End_Date)
                select t;

            if (query.Count() > 0)
            {
                return query.First().PID;
            }
            else
                return 0;
        }
    }
}
