﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void UpdateItemApply(ItemApplyVO apply)
        {
            ctx.SubmitChanges();
        }

        public void UpdateItemApplyByTask(int taskID)
        {
            Table<ItemApplyVO> table = ctx.ItemApplyTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public int InsertItemApply(ItemApplyVO item)
        {
            ctx.ItemApplyTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Apply_ID;
        }

        public List<ItemApplyVO> GetApplyByTask(int taskID)
        {
            Table<ItemApplyVO> table = ctx.ItemApplyTable;
            Table<ItemVO> item = ctx.ItemTable;

            var query =
                from t in table
                join a in item on t.Item_ID equals a.Item_ID
                where t.Task_ID.Equals(taskID)
                select new { t, a.Item_Name };

            //return query.ToList();

            List<ItemApplyVO> objList = new List<ItemApplyVO>();
            foreach (var apply in query.ToList())
            {
                ItemApplyVO obj = apply.t;
                obj.Item_Name = apply.Item_Name;

                objList.Add(obj);
            }
            return objList;

        }

        public List<ItemApplyVO> GetApplyListByCompany(int companyID, int page, int size, out int total)
        {
            Table<ItemApplyVO> table = ctx.ItemApplyTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<ItemVO> item = ctx.ItemTable;
            Table<DepartmentVO> depart = ctx.DepartmentTable;
            Table<PositionVO> pos = ctx.PositionTable;
            Table<AccountVO> account = ctx.AccountTable;
            int start = page * size;

            List<ItemApplyVO> objList = new List<ItemApplyVO>();

            var query =
                from t in table 
                join tk in task on t.Task_ID equals tk.Task_ID 
                join a in item on t.Item_ID equals a.Item_ID 
                join ac in account on t.Account_ID equals ac.Account_ID 
                join ps in pos on ac.Position_ID equals ps.Position_ID 
                join de in depart on ps.Department_ID equals de.Department_ID
                where de.Company_ID.Equals(companyID) && (tk.Status_ID.Equals((int)Config.TaskStatus.Active) || tk.Status_ID.Equals((int)Config.TaskStatus.Finish)) 
                orderby t.Create_Date descending 
                select new { t, a.Item_Name };

            //return query.ToList();

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var data in pageQuery)
            {
                ItemApplyVO obj = data.t;
                obj.Item_Name = data.Item_Name;

                objList.Add(obj);
            }

            return objList;
        }

        public int GetSumCountByAccount(int itemID, int accountID, Config.TaskStatus status, DateTime start, DateTime end)
        {
            Table<ItemApplyVO> table = ctx.ItemApplyTable;

            var query =
                from t in table
                where t.Create_Date.CompareTo(start) >= 0
                    && t.Create_Date.CompareTo(end) <= 0
                    && t.Account_ID.Equals(accountID)
                    && t.Status_ID.Equals(status)
                    && t.Item_ID.Equals(itemID)
                    && t.Is_Grant.Equals((int)Config.ItemApply.On)
                select t;

            if (query.Count() == 0)
                return 0;

            return query.Sum(t => t.Number);
        }


        public void UpdateApplyGrantByTask(int taskID)
        {
            Table<ItemApplyVO> table = ctx.ItemApplyTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
                p.Is_Grant = (int)Config.ItemApply.On;
            }

            ctx.SubmitChanges();
        }
    }
}
