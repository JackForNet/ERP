﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Data.Linq.SqlClient;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Common;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<ItemVO> GetApplyItem(int companyID)
        {
            Table<ItemVO> table = ctx.ItemTable;

            var query =
                from t in table
                where t.Is_Apply.Equals((int)Config.ItemApply.On) && t.Company_ID.Equals(companyID)
                select t;

            return query.ToList();
        }

        public List<ItemTypeVO> GetItemType()
        {
            Table<ItemTypeVO> table = ctx.ItemTypeTable;

            var query =
                from t in table 
                orderby t.Type_Name descending 
                select t;

            return query.ToList();
        }

        public List<ItemVO> GetItemByType(int companyId, int typeID)
        {
            Table<ItemVO> table = ctx.ItemTable;

            var query =
                from t in table 
                where t.Type_ID.Equals(typeID) && t.Company_ID.Equals(companyId)
                select t;

            return query.ToList();
        }

        public List<ItemVO> GetItem(string itemName, int companyId, int typeID, int page, int size, out int total)
        {
            Table<ItemVO> table = ctx.ItemTable;
            Table<ItemTypeVO> type = ctx.ItemTypeTable;
            int start = page * size;

            var query =
                from t in table
                join ty in type on t.Type_ID equals ty.Type_ID
                where t.Type_ID.Equals(typeID) && t.Company_ID.Equals(companyId)
                && (!string.IsNullOrEmpty(itemName) ? SqlMethods.Like(t.Item_Name, "%" + itemName + "%") : true) 
                orderby t.Item_Name descending 
                select new { t, ty.Type_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            List<ItemVO> objList = new List<ItemVO>();
            foreach (var item in pageQuery)
            {
                ItemVO obj = item.t;
                obj.Apply = item.t.Is_Apply.Equals(1) ? "是" : "否";
                obj.Recycle = item.t.Is_Recycle.Equals(1) ? "是" : "否";
                obj.Type_Name = item.Type_Name;
                objList.Add(obj);
            }
            return objList;
            //return query.ToList();
        }

        public int InsertItem(ItemVO item)
        {
            ctx.ItemTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Item_ID;
        }

        public void UpdateItem(ItemVO item)
        {
            Table<ItemVO> table = ctx.ItemTable;

            var query =
                from t in table
                where t.Item_ID.Equals(item.Item_ID)
                select t;

            ItemVO obj = query.First();
            obj = item;
            ctx.SubmitChanges();
        }

        public ItemVO GetItemByID(int id)
        {
            Table<ItemVO> table = ctx.ItemTable;

            var query =
                from t in table
                where t.Item_ID.Equals(id) 
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();

        }

        public List<ItemVO> GetItems()
        {
            Table<ItemVO> table = ctx.ItemTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public List<ItemVO> GetItemByIDs(string ids)
        {
            Table<ItemVO> table = ctx.ItemTable;
            string[] array = ids.Split(',');

            var query =
                from t in table
                where array.Contains(t.Item_ID.ToString())
                select t;

            return query.ToList();
        }

        public List<ItemVO> GetItemsByCompany(int companyID)
        {
            Table<ItemVO> table = ctx.ItemTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID) 
                select t;

            return query.ToList();
        }

        public void DeleteItems(int[] itemIDs)
        {
            Table<ItemVO> table = ctx.ItemTable;

            var query =
                from t in table
                where itemIDs.Contains(t.Item_ID) 
                select t;

            foreach (var p in query)
            {
                ctx.ItemTable.DeleteOnSubmit(p);
            }
            ctx.SubmitChanges();
        }
    }
}
