﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void UpdateItemShop(ItemShopVO shop)
        {
            ctx.SubmitChanges();
        }

        public int InsertItemShop(ItemShopVO item)
        {
            ctx.ItemShopTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Shop_ID;
        }

        public void UpdateItemShopByTask(int taskID)
        {
            Table<ItemShopVO> table = ctx.ItemShopTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public List<ItemShopVO> GetItemShopByTask(int taskID)
        {
            Table<ItemShopVO> table = ctx.ItemShopTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

        }
    }
}
