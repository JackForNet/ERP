﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<ItemStorageVO> GetStorageByItem(int itemID)
        {
            Table<ItemStorageVO> table = ctx.ItemStorageTable;

            var query =
                from t in table
                where t.Item_ID.Equals(itemID)
                select t;

            return query.ToList();
        }

        public List<ItemStorageVO> GetStorage()
        {
            Table<ItemStorageVO> table = ctx.ItemStorageTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public List<ItemStorageVO> GetStorageByType(string itemIDs, int page, int size, out int total)
        {
            Table<ItemStorageVO> table = ctx.ItemStorageTable;
            Table<ItemVO> it = ctx.ItemTable;
            Table<ItemTypeVO> type = ctx.ItemTypeTable;
            string[] array = itemIDs.Split(',');
            int start = page * size;

            var query =
                from t in table
                join i in it on t.Item_ID equals i.Item_ID 
                join ty in type on i.Type_ID equals ty.Type_ID
                where array.Contains(t.Item_ID.ToString()) 
                select new { t, i.Item_Name, ty.Type_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            List<ItemStorageVO> objList = new List<ItemStorageVO>();
            foreach (var item in pageQuery)
            {
                ItemStorageVO obj = item.t;
                obj.Operation_Type = item.t.Quantity > 0 ? "入库" : "出库";
                obj.Quantity = Math.Abs(item.t.Quantity);
                obj.Item_Name = item.Item_Name;
                obj.Type_Name = item.Type_Name;
                objList.Add(obj);
            }
            return objList;
            //return query.ToList();
        }

        public int InsertItemStorage(ItemStorageVO item)
        {
            ctx.ItemStorageTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Record_ID;
        }

        public void UpdateStorageByItem(int[] itemIDs, int itemID)
        {
            Table<ItemStorageVO> table = ctx.ItemStorageTable;

            var query =
                from t in table
                where itemIDs.Contains(t.Item_ID)
                select t;

            foreach (var p in query)
            {
                p.Item_ID = itemID;
            }
            ctx.SubmitChanges();
        }

        public int GetNowStorageByItem(int itemID)
        {
            Table<ItemStorageVO> table = ctx.ItemStorageTable;

            var query =
                from t in table
                where t.Item_ID.Equals(itemID)
                select t;

            return query.ToList().Select(o => o.Quantity).Sum();
        }
    }
}
