﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void UpdateLeave(LeaveVO leave)
        {
            ctx.SubmitChanges();
        }

        public void UpdateLeaveByTask(int taskID)
        {
            Table<LeaveVO> table = ctx.LeaveTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public int InsertLeave(LeaveVO item)
        {
            ctx.LeaveTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Leave_ID;
        }

        public List<LeaveVO> GetLeaveByAccount(int accountID, DateTime date)
        {
            return GetLeaveByAccount(accountID, date, date);
        }
        public List<LeaveVO> GetLeaveByAccount(int accountID, DateTime start, DateTime end)
        {
            Table<LeaveVO> table = ctx.LeaveTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from t in table
                join tk in task on t.Task_ID equals tk.Task_ID 
                where t.Account_ID.Equals(accountID)
                    && t.Leave_Date.CompareTo(start) >= 0
                    && t.Leave_Date.CompareTo(end) <= 0
                    && (tk.Status_ID.Equals((int)Config.TaskStatus.Active) || tk.Status_ID.Equals((int)Config.TaskStatus.Finish)) 
                select t;

            return query.ToList();
        }

        public List<LeaveVO> GetLeaveByTask(int taskID)
        {
            Table<LeaveVO> table = ctx.LeaveTable;
            Table<LeaveTypeVO> type = ctx.LeaveTypeTable;

            var query =
                from t in table
                join a in type on t.Leave_Type equals a.Type_ID
                where t.Task_ID.Equals(taskID)
                select new { t, a.Type_Name };

            //return query.ToList();

            List<LeaveVO> objList = new List<LeaveVO>();
            foreach (var item in query.ToList())
            {
                LeaveVO obj = item.t;
                obj.Type_Name = item.Type_Name;
                
                objList.Add(obj);
            }
            return objList;

        }

        public List<LeaveVO> GetLeaveByFinish(int[] positionIDs, DateTime start, DateTime end)
        {
            Table<LeaveVO> table = ctx.LeaveTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID 
                join a in account on t.Account_ID equals a.Account_ID 
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish)
                    && t.IsActive.Equals((int)Config.LeaveStatus.Apply) 
                    && positionIDs.Contains(a.Position_ID)
                    && t.Leave_Date.CompareTo(start) >= 0
                    && t.Leave_Date.CompareTo(end) < 0
                select t;

            return query.ToList();
        }

        public List<LeaveVO> GetLeaveByAccountFinish(int accountID, DateTime start, DateTime end)
        {
            Table<LeaveVO> table = ctx.LeaveTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                join a in account on t.Account_ID equals a.Account_ID
                join s in staff on a.Account_ID equals s.Account_ID
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish) 
                    && t.IsActive.Equals((int)Config.LeaveStatus.Apply) 
                    && t.Account_ID.Equals(accountID)
                    && !s.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && t.Leave_Date.CompareTo(start) >= 0
                    && t.Leave_Date.CompareTo(end) < 0
                select t;

            return query.ToList();
        }

        public List<LeaveVO> GetLeaveByCompanyFinish(int companyID, Config.LeaveType leaveType, int page, int size, out int total)
        {
            Table<LeaveVO> table = ctx.LeaveTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<StaffVO> staff = ctx.StaffTable;
            int start = page * size;

            List<LeaveVO> objList = new List<LeaveVO>();

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join s in staff on t.Account_ID equals s.Account_ID
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish)
                    && t.Certificate.Equals((int)Config.CertificateType.Defualt)
                    && t.Leave_Type.Equals((int)leaveType)
                    && d.Company_ID.Equals(companyID)
                    && !s.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select new { t, s.Name, p.Position_Name, d.Department_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                LeaveVO obj = item.t;
                obj.Name = item.Name;
                obj.Position = item.Position_Name;
                obj.Department = item.Department_Name;

                objList.Add(obj);
            }

            return objList;
        }

        public List<LeaveTypeVO> GetLeaveType()
        {
            Table<LeaveTypeVO> table = ctx.LeaveTypeTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public void UpdateLeaveCertificateByTask(int taskID, Config.CertificateType certificate)
        {
            Table<LeaveVO> table = ctx.LeaveTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Certificate = (int)certificate;
                if (certificate.Equals(Config.CertificateType.Fail))
                {
                    p.Leave_Type = (int)Config.LeaveType.Absence;
                }
            }

            ctx.SubmitChanges();
        }

        public List<LeaveVO> GetLeavesByAccount(int accountID, DateTime startDate, Config.LeaveStatus isActive, Config.LeaveStatus status)
        {
            return GetLeavesByAccount(accountID, startDate, startDate, isActive, status);
        }

        public List<LeaveVO> GetLeavesByAccount(int accountID, DateTime startDate, DateTime endDate, Config.LeaveStatus isActive, Config.LeaveStatus status)
        {
            Table<LeaveVO> table = ctx.LeaveTable;

            var query =
                from t in table
                where t.Leave_Date.CompareTo(startDate) >= 0 
                    && t.Leave_Date.CompareTo(endDate) <= 0 
                    && t.Account_ID.Equals(accountID)
                    && t.IsActive.Equals((int)isActive)
                    && t.Status_ID.Equals((int)status) 
                select t;

            return query.ToList();
        }

        public void UpdateLeaveByCancel(int taskID)
        {
            Table<LeaveVO> table = ctx.LeaveTable;
            Table<HRCancelLeaveVO> cancel = ctx.HRCancelLeaveTable;

            var query =
                from t in table 
                join c in cancel on t.Leave_ID equals c.Leave_ID 
                where c.Task_ID.Equals(taskID) 
                select t;

            foreach (var p in query)
            {
                p.IsActive = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }

        public List<LeaveVO> GetLeaveByAccountsFinish(int[] staffIDs, DateTime start, DateTime end)
        {
            Table<LeaveVO> table = ctx.LeaveTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join k in task on t.Task_ID equals k.Task_ID
                join a in account on t.Account_ID equals a.Account_ID
                join s in staff on a.Account_ID equals s.Account_ID
                where k.Status_ID.Equals((int)Config.TaskStatus.Finish)
                    && t.IsActive.Equals((int)Config.LeaveStatus.Apply)
                    && staffIDs.Contains(s.Staff_ID) 
                    && !s.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && t.Leave_Date.CompareTo(start) >= 0
                    && t.Leave_Date.CompareTo(end) < 0 
                select t;

            return query.ToList();
        }
    }
}
