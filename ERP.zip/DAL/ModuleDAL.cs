﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public ModuleVO GetModule(string url)
        {
            Table<ModuleVO> table = ctx.ModuleTable;

            var query =
                from t in table
                where t.Module_Url.Equals(url)
                select t;

            return query.Count() > 0 ? query.First() : null;
        }

        public List<ModuleVO> GetModule()
        {
            Table<ModuleVO> table = ctx.ModuleTable;
            Table<ModuleGroupVO> moduleGroup = ctx.ModuleGroupTable;

            var query =
                from t in table
                join p in moduleGroup on t.Group_ID equals p.Group_ID
                select new { t, p };

            List<ModuleVO> list = new List<ModuleVO>();
            foreach (var item in query.ToList())
            {
                ModuleVO module = item.t;
                module.Group = item.p;
                list.Add(module);
            }
            return list;
        }

        //public List<ModuleVO> GetModule(int positionID)
        //{
        //    Table<ModuleVO> module = ctx.ModuleTable;
        //    Table<PositionPurviewVO> table = ctx.PositionPurviewTable;

        //    var query =
        //        from t in module
        //        join p in table on t.Module_ID equals p.Module_ID
        //        where p.Position_ID.Equals(positionID) && p.Purview_ID.Equals((int)Config.Purview.View)
        //        select t;

        //    return query.ToList();
        //}

        public List<ModuleVO> GetModule(int Group_ID)
         {
             Table<ModuleVO> module = ctx.ModuleTable;
             var model = (from c in module
                         where c.Group_ID.Equals(Group_ID)
                          select c).OrderByDescending(n => n.Sort);

             return model.ToList();
         }

    }
}
