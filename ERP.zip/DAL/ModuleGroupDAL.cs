﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<ModuleGroupVO> GetModuleGroup(int templateID)
        {
            Table<ModuleGroupVO> ModuleGroup = ctx.ModuleGroupTable;
            Table<ModuleVO> Module = ctx.ModuleTable;
            Table<TemplatePurviewVO> Purview = ctx.TemplatePurviewTable;

            var query =
                (from g in ModuleGroup
                 join m in Module on g.Group_ID equals m.Group_ID
                 join p in Purview on m.Module_ID equals p.Module_ID
                 where p.Template_ID.Equals(templateID) && p.Purview_ID.Equals((int)Config.Purview.View)
                 group g by new { Group_ID = g.Group_ID, Group_Name = g.Group_Name, Sort = g.Sort } into a
                 select new { a.Key.Group_ID, a.Key.Group_Name, a.Key.Sort }).OrderByDescending(n=>n.Sort);

            List<ModuleGroupVO> list = new List<ModuleGroupVO>();
            foreach (var item in query)
            {
                ModuleGroupVO obj = new ModuleGroupVO();
                obj.Group_ID = item.Group_ID;
                obj.Group_Name = item.Group_Name;
                obj.Sort = item.Sort;
                list.Add(obj);
            }

            return list;
        }
        
    }
}
