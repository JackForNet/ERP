﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<ModulePurviewVO> GetModulePurview()
        {
            Table<ModulePurviewVO> table = ctx.ModulePurviewTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public void InsertModulePurview(ModulePurviewVO item)
        {
            ctx.ModulePurviewTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void DeleteModulePurview(int moduleID, int purviewID)
        {
            Table<ModulePurviewVO> table = ctx.ModulePurviewTable;

            var query =
                from t in table
                where t.Module_ID.Equals(moduleID) && t.Purview_ID.Equals(purviewID)
                select t;

            if (query.Count() > 0)
            {
                ModulePurviewVO obj = query.First();
                ctx.ModulePurviewTable.DeleteOnSubmit(obj);
                ctx.SubmitChanges();
            }
        }
    }
}
