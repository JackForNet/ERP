﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public class NorthwindDataContext : DataContext
    {
        public Table<CompanyVO> CompanyTable;
        public Table<CompanyAreaVO> CompanyAreaTable;
        public Table<CompanyPlatformVO> CompanyPlatformTable;

        public Table<AccountVO> AccountTable;
        public Table<AccountStatusVO> AccountStatusTable;

        public Table<DepartmentVO> DepartmentTable;

        public Table<ModuleVO> ModuleTable;
        public Table<ModulePurviewVO> ModulePurviewTable;
        public Table<ModuleGroupVO> ModuleGroupTable;

        public Table<PositionVO> PositionTable;
        public Table<PositionTitleVO> PositionTitleTable;
        public Table<PositionPurviewVO> PositionPurviewTable;
        public Table<PositionItemVO> PositionItemTable;
        public Table<PositionStatusVO> PositionStatusTable;

        public Table<PurviewVO> PurviewTable;

        public Table<TaskVO> TaskTable;
        public Table<TaskStatusVO> TaskStatusTable;
        public Table<TaskLogVO> TaskLogTable;

        public Table<WorkFlowProcessVO> WorkFlowProcessTable;
        public Table<WorkFlowVO> WorkFlowTable;

        public Table<LeaveVO> LeaveTable;
        public Table<LeaveTypeVO> LeaveTypeTable;

		public Table<RoomVO> RoomTable;
        public Table<RoomStatusVO> RoomStatusTable;
        public Table<RoomReservationVO> RoomReservationTable;

		public Table<StaffVO> StaffTable;
        public Table<StaffStatusVO> StaffStatusTable;
        public Table<QuitTypeVO> QuitTypeTable;
        public Table<StaffSalaryRecordVO> StaffSalaryRecordTable;
        public Table<FinancialPayorllVO> FinancialPayorllTable;

        public Table<AbnormalVO> AbnormalTable;
        public Table<AbnormalTypeVO> AbnormalTypeTable;
        public Table<StaffWorkTimeVO> StaffWorkTimeTable;
        

        public Table<ItemVO> ItemTable;
        public Table<ItemTypeVO> ItemTypeTable;
        public Table<ItemStorageVO> ItemStorageTable;

        public Table<ItemApplyVO> ItemApplyTable;
        public Table<ItemShopVO> ItemShopTable;
        public Table<ItemShopRecordVO> ItemShopRecordTable;

        public Table<IDCardVO> IDCardTable;

        public Table<WorkExperienceVO> WorkExperienceTable;

        public Table<AdminCompanyVO> AdminCompanyTable;
        public Table<AdminCertificateVO> AdminCertificateTable;
        public Table<AdminCompanyCertificateVO> AdminCompanyCertificateTable;
        public Table<AdminCertificateAddVO> AdminCertificateAddTable;
        public Table<AdminCertificateBackVO> AdminCertificateBackTable;
        public Table<AdminPaymentVO> AdminPaymentTable;
        public Table<AdminPaymentTypeVO> AdminPaymentTypeTable;
        public Table<CycleBonusRecordVO> AdminCycleBonusRecordTable;
        public Table<AdminEquipmentVO> AdminEquipmentTable;
        public Table<AdminMonthShopVO> AdminMonthShopTable;
        
        public Table<HRQuitVO> HRQuitTable;
        public Table<HRHolidayVO> HRHolidayTable;
        public Table<HRPositiveVO> HRPositiveTable;
        public Table<HRCancelLeaveVO> HRCancelLeaveTable;
        public Table<HRStaffLogVO> HRStaffLogTable;

        public Table<TemplateVO> TemplateTable;
        public Table<TemplatePurviewVO> TemplatePurviewTable;

        public Table<EvaluationResultsVO> EvaluationResultsTable;
        public Table<WagesRecordVO> WagesRecordTable;

        public Table<CustomerVO> CustomerTable;
        public Table<CustomerStaffVO> CustomerStaffTable;
        public Table<CustomerRecordVO> CustomerRecordTable;
        public Table<CustomerPlatformVO> CustomerPlatformTable;
        public Table<PresetCustomerVO> PresetCustomerTable;
        

        public Table<NoticeVO> NoticeTable;
        public Table<NoticeRelationVO> NoticeRelationTable;

        public Table<AwardShopVO> AwardShopTable;
        public Table<AwardShopRecordVO> AwardShopRecordTable;

        public Table<AdminLoanVO> AdminLoanTable;
        public Table<AdminReimbursementVO> AdminReimbursementTable;
        public Table<AdminReimbursementRecordVO> AdminReimbursementRecordTable;
        public Table<HRInvitedVO> HRInvitedTable;
        public NorthwindDataContext(IDbConnection connection) : base(connection) { }

        public NorthwindDataContext(string connection) : base(connection) { }
    }
}
