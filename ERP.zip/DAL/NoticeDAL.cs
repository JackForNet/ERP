﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertNotice(NoticeVO notice)
        {
            ctx.NoticeTable.InsertOnSubmit(notice);
            ctx.SubmitChanges();
            return notice.Notice_ID;
        }

        public void UpdateNotice(NoticeVO notice)
        {
            Table<NoticeVO> table = ctx.NoticeTable;

            var query =
                from t in table
                where t.Notice_ID.Equals(notice.Notice_ID)
                select t;

            NoticeVO obj = query.First();
            obj = notice;
            ctx.SubmitChanges();
        }

        public List<NoticeVO> GetNoticeByTask(int taskID)
        {
            Table<NoticeVO> table = ctx.NoticeTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            return query.ToList();

        }

        public NoticeVO GetNoticeByID(int noticeID)
        {
            Table<NoticeVO> table = ctx.NoticeTable;

            var query =
                from t in table
                where t.Notice_ID.Equals(noticeID)
                select t;


            if (query.Count() == 0)
                return null;

            return query.First();

        }
    }
}
