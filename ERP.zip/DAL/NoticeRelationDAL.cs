﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertNoticeRelation(NoticeRelationVO noticeRelation)
        {
            ctx.NoticeRelationTable.InsertOnSubmit(noticeRelation);
            ctx.SubmitChanges();
            return noticeRelation.Relation_ID;
        }

        public void UpdateNoticeRelation(int taskID, Config.NoticeRelationStatus status)
        {
            Table<NoticeRelationVO> table = ctx.NoticeRelationTable;
            Table<NoticeVO> notice = ctx.NoticeTable;

            var query =
                from t in table 
                join n in notice on t.Notice_ID equals n.Notice_ID
                where n.Task_ID.Equals(taskID) 
                select t;

            foreach (var p in query)
            {
                p.Status = (int)status;
            }

            ctx.SubmitChanges();
        }

        public List<NoticeRelationVO> GetRelationsByNotice(int noticeID)
        {
            Table<NoticeRelationVO> table = ctx.NoticeRelationTable;

            var query =
                from t in table
                where t.Notice_ID.Equals(noticeID)
                select t;

            return query.ToList();
        }

        public NoticeVO GetTop1NoticeByDepartment(int departmentID, Config.NoticeRelationStatus status)
        {
            Table<NoticeVO> table = ctx.NoticeTable;
            Table<NoticeRelationVO> relation = ctx.NoticeRelationTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                (from t in table
                 join tk in task on t.Task_ID equals tk.Task_ID
                 join rl in relation on t.Notice_ID equals rl.Notice_ID
                 where rl.Department_ID.Equals(departmentID) && rl.Status.Equals((int)status) 
                 orderby t.Create_Date descending 
                 select t).Take(1);

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<NoticeVO> GetNoticesByDepartment(int departmentID, Config.NoticeRelationStatus status, int page, int size, out int total)
        {
            Table<NoticeVO> table = ctx.NoticeTable;
            Table<NoticeRelationVO> relation = ctx.NoticeRelationTable;
            Table<TaskVO> task = ctx.TaskTable;
            int start = page * size;

            var query =
                 from t in table
                 join tk in task on t.Task_ID equals tk.Task_ID
                 join rl in relation on t.Notice_ID equals rl.Notice_ID
                 where rl.Department_ID.Equals(departmentID) && rl.Status.Equals((int)status)
                 orderby t.Create_Date descending
                 select t;

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            //List<NoticeVO> list = new List<NoticeVO>();
            //foreach (var item in pageQuery)
            //{
            //    NoticeVO obj = item;

            //    list.Add(obj);
            //}

            return pageQuery.ToList() ;
        }

        public List<NoticeVO> GetNoticeDetailsByDepartment(int departmentID, Config.NoticeRelationStatus status)
        {
            Table<NoticeVO> table = ctx.NoticeTable;
            Table<NoticeRelationVO> relation = ctx.NoticeRelationTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                 from t in table
                 join tk in task on t.Task_ID equals tk.Task_ID
                 join rl in relation on t.Notice_ID equals rl.Notice_ID
                 where rl.Department_ID.Equals(departmentID) && rl.Status.Equals((int)status)
                 orderby t.Create_Date descending
                 select t;


            return query.ToList();
        }

        public List<NoticeVO> GetNoticeDetailsByDepartment(int departmentID, Config.NoticeRelationStatus status, int start, int size)
        {
            Table<NoticeVO> table = ctx.NoticeTable;
            Table<NoticeRelationVO> relation = ctx.NoticeRelationTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                 from t in table
                 join tk in task on t.Task_ID equals tk.Task_ID
                 join rl in relation on t.Notice_ID equals rl.Notice_ID
                 where rl.Department_ID.Equals(departmentID) && rl.Status.Equals((int)status)
                 orderby t.Create_Date descending
                 select t;

            var pageQuery = query.Skip(start).Take(size);
            return pageQuery.ToList();
        }
    }
}
