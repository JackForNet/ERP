﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public PositionVO GetPositionByID(int id)
        {
            Table<PositionVO> table = ctx.PositionTable;
            Table<DepartmentVO> dept = ctx.DepartmentTable;

            var query =
                from t in table
                join d in dept on t.Department_ID equals d.Department_ID
                where t.Position_ID.Equals(id)
                    && t.Status_ID.Equals((int)Config.PositionStatus.Active)
                select new { t, d.Department_Name };

            if (query.Count() == 0)
                return null;

            var item = query.FirstOrDefault();

            PositionVO obj = item.t;
            obj.Department_Name = item.Department_Name;

            return obj;
        }

        public int InsertPosition(PositionVO item)
        {
            ctx.PositionTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Position_ID;
        }

        public List<PositionVO> GetPosition(int departmentID, int positionID)
        {
            Table<PositionVO> table = ctx.PositionTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                    && t.Department_ID.Equals(departmentID)
                    && !t.Position_ID.Equals(positionID) 
                select t;

            return query.ToList();
        }

        public List<PositionVO> GetPositionByPID(int positionID)
        {
            Table<PositionVO> table = ctx.PositionTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                    && !t.Position_ID.Equals(positionID)
                select t;

            return query.ToList();
        }


        public List<PositionVO> GetPosition(int departmentID)
        {
            Table<PositionVO> table = ctx.PositionTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                    && t.Department_ID.Equals(departmentID) 
                select t;

            return query.ToList();
        }

        public List<PositionVO> GetPositionIsNotMy(int departmentID, int positionID)
        {
            Table<PositionVO> table = ctx.PositionTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                    && t.Department_ID.Equals(departmentID) && !t.Position_ID.Equals(positionID) 
                select t;

            return query.ToList();
        }

        public void UpdatePosition(PositionVO position)
        {
            ctx.SubmitChanges();
        }


        public List<PositionVO> GetPositionByList(int departmentID)
        {
            Table<PositionVO> table = ctx.PositionTable;
            Table<DepartmentVO> dept = ctx.DepartmentTable;
            Table<PositionStatusVO> status = ctx.PositionStatusTable;
            
            var query =
                from t in table 
                join d in dept on t.Department_ID equals d.Department_ID 
                join s in status on t.Status_ID equals s.Status_ID
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                    && t.Department_ID.Equals(departmentID) 
                select new { t, d.Department_Name, s.Status_Name };

            List<PositionVO> objList = new List<PositionVO>();
            foreach (var item in query)
            {
                PositionVO obj = item.t;
                obj.Department_Name = item.Department_Name;
                obj.Status_Name = item.Status_Name;
                objList.Add(obj);
            }
            return objList;

        }

        public List<PositionVO> GetPositionBySuperior(int superiorID)
        {
            Table<PositionVO> table = ctx.PositionTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                    && t.Superior_ID.Equals(superiorID)
                select t;

            return query.ToList();
        }

        public List<PositionVO> GetPositionByTitle(int departmentID, int titleID)
        {
            Table<PositionVO> table = ctx.PositionTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.PositionStatus.Active)
                    && t.Department_ID.Equals(departmentID)
                    && t.Title_ID.Equals(titleID)
                select t;

            return query.ToList();
        }



        #region Position Title

        public List<PositionTitleVO> GetPositionTitle()
        {
            Table<PositionTitleVO> table = ctx.PositionTitleTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        #endregion

    }
}
