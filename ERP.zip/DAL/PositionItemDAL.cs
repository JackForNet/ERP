﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<PositionItemVO> GetPositionItem(int positionID)
        {
            Table<PositionItemVO> table = ctx.PositionItemTable;

            var query =
                from t in table
                where t.Position_ID.Equals(positionID)
                select t;

            return query.ToList();
        }

        public void InsertPositionItem(PositionItemVO item)
        {
            ctx.PositionItemTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void DeletePositionItem(int positionID, int itemID)
        {
            Table<PositionItemVO> table = ctx.PositionItemTable;

            var query =
                from t in table
                where t.Position_ID.Equals(positionID) && t.Item_ID.Equals(itemID)
                select t;

            if (query.Count() > 0)
            {
                PositionItemVO obj = query.First();
                ctx.PositionItemTable.DeleteOnSubmit(obj);
                ctx.SubmitChanges();
            }
        }

        public void DeletePositionItems(int[] itemIDs)
        {
            Table<PositionItemVO> table = ctx.PositionItemTable;

            var query =
                from t in table
                where itemIDs.Contains(t.Item_ID)
                select t;

            foreach (var p in query)
            {
                ctx.PositionItemTable.DeleteOnSubmit(p);
            }
            ctx.SubmitChanges();
        }
    }
}
