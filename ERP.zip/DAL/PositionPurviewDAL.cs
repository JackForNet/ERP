﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public PositionPurviewVO GetPositionPurview(int positionID, int moduleID, int purviewID)
        {
            Table<PositionPurviewVO> table = ctx.PositionPurviewTable;

            var query =
                from t in table
                where t.Position_ID.Equals(positionID) && t.Module_ID.Equals(moduleID) && t.Purview_ID.Equals(purviewID)
                select t;

            return query.Count() > 0 ? query.First() : null;
        }

        public List<PositionPurviewVO> GetPositionPurview(string positionIDs)
        {
            Table<PositionPurviewVO> table = ctx.PositionPurviewTable;
            string[] array = positionIDs.Split(',');

            var query =
                from t in table
                where array.Contains(t.Position_ID.ToString())
                select t;

            return query.ToList();
        }

        public List<PositionPurviewVO> GetPositionPurview(int positionID)
        {
            Table<PositionPurviewVO> table = ctx.PositionPurviewTable;

            var query =
                from t in table
                where t.Position_ID.Equals(positionID) 
                select t;

            return query.ToList();
        }

        public void InsertPositionPurview(PositionPurviewVO item)
        {
            ctx.PositionPurviewTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void DeletePositionPurview(int positionID, int moduleID, int purviewID)
        {
            Table<PositionPurviewVO> table = ctx.PositionPurviewTable;
            
            var query =
                from t in table
                where t.Position_ID.Equals(positionID) && t.Module_ID.Equals(moduleID) && t.Purview_ID.Equals(purviewID)
                select t;

            if (query.Count() > 0)
            {
                PositionPurviewVO obj = query.First();
                ctx.PositionPurviewTable.DeleteOnSubmit(obj);
                ctx.SubmitChanges();
            }
        }
    }
}
