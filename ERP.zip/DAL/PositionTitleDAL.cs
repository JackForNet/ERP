﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<PositionTitleVO> GetTitle(int companyID){
            Table<PositionTitleVO> table = ctx.PositionTitleTable;

            var query =
                from t in table
                where t.Company_ID.Equals(0) || t.Company_ID.Equals(companyID) 
                select t;

            return query.ToList();
        }
    }
}
