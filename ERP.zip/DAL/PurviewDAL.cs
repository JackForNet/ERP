﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<PurviewVO> GetPurview()
        {
            Table<PurviewVO> table = ctx.PurviewTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }
    }
}
