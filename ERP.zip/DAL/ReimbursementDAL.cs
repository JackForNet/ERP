﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertAdminReimbursement(AdminReimbursementVO item)
        {
            ctx.AdminReimbursementTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.RID;
        }
        public List<AdminReimbursementVO> GetAdminReimbursementByTask(int taskID) 
        {
            Table<AdminReimbursementVO> table = ctx.AdminReimbursementTable;

            var query = from t in table
                        where t.Task_ID.Equals(taskID)
                        select t;

            return query.ToList();

        }

        public int GetAdminReimbursementByRID(int taskID)
        {
            Table<AdminReimbursementVO> table = ctx.AdminReimbursementTable;

            var query = from t in table
                        where t.Task_ID.Equals(taskID)
                        select t.RID;

            return int.Parse(query.FirstOrDefault().ToString());
        }

        public void UpdateAdminReimbursementByTask(int taskID)
        {
            Table<AdminReimbursementVO> table = ctx.AdminReimbursementTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.LeaveStatus.success;
            }

            ctx.SubmitChanges();
        }
    }
}
