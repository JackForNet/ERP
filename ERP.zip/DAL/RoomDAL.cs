﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;

using ZhongLuan.ERP.Common;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void InsertRoom(RoomVO item)
        {
            ctx.RoomTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void UpdateRoom(RoomVO item)
        {
            Table<RoomVO> table = ctx.RoomTable;

            var query =
                from t in table
                where t.Room_ID.Equals(item.Room_ID)
                select t;

            RoomVO obj = query.First();
            obj = item;
            ctx.SubmitChanges();
        }

        public List<RoomVO> GetRoomByCompanyID(int companyID)
        {
            Table<RoomVO> table = ctx.RoomTable;
            Table<RoomStatusVO> status = ctx.RoomStatusTable;

            var query =
                from t in table
                join s in status on t.Status_ID equals s.Status_ID
                where !t.Status_ID.Equals((int)Config.RoomStatus.Delete)
                    && t.Company_ID.Equals(companyID) 
                select new { t, s.Status_Name };

            List<RoomVO> objList = new List<RoomVO>();
            foreach (var item in query)
            {
                RoomVO obj = item.t;
                obj.Status_Name = item.Status_Name;
                objList.Add(obj);
            }
            return objList;
        }

        public RoomVO GetRoom(int roomID)
        {
            Table<RoomVO> table = ctx.RoomTable;

            var query =
                from t in table
                where t.Room_ID.Equals(roomID)
                select t;

            return query.First();
        }

        public List<RoomVO> GetActiveRoom(int companyID)
        {
            Table<RoomVO> table = ctx.RoomTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.RoomStatus.Active)
                && t.Company_ID.Equals(companyID) 
                select t;

            return query.ToList();
        }

        public List<RoomStatusVO> GetRoomStatus()
        {
            Table<RoomStatusVO> table = ctx.RoomStatusTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }




        public void InsertRoomReservation(RoomReservationVO item)
        {
            ctx.RoomReservationTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public List<RoomReservationVO> GetRoomReservationByTask(int taskID)
        {
            Table<RoomReservationVO> table = ctx.RoomReservationTable;
            Table<RoomVO> room = ctx.RoomTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join r in room on t.Room_ID equals r.Room_ID 
                join a in account on t.Account_ID equals a.Account_ID 
                join p in position on a.Position_ID equals p.Position_ID 
                join d in department on p.Department_ID equals d.Department_ID 
                join s in staff on t.Account_ID equals s.Account_ID 
                where t.Task_ID.Equals(taskID)
                select new { t, r.Room_Name, s.Name, p.Position_Name, d.Department_Name };

            //return query.ToList();

            List<RoomReservationVO> objList = new List<RoomReservationVO>();
            foreach (var reservation in query.ToList())
            {
                RoomReservationVO obj = reservation.t;
                obj.Room_Name = reservation.Room_Name;
                obj.Name = reservation.Name;
                obj.Position = reservation.Position_Name;
                obj.Department = reservation.Department_Name;
                objList.Add(obj);
            }
            return objList;

        }

        public List<RoomReservationVO> GetRoomReservation(int roomID, DateTime start, DateTime end)
        {
            Table<RoomReservationVO> table = ctx.RoomReservationTable;
            Table<TaskVO> task = ctx.TaskTable;

            var query =
                from r in table
                join t in task on r.Task_ID equals t.Task_ID
                where r.Room_ID.Equals(roomID)
                    && r.Start_Date.CompareTo(start) >= 0
                    && r.End_Date.CompareTo(end) <= 0
                    && t.Status_ID.Equals((int)Config.TaskStatus.Finish)
                select r;

            return query.ToList();
        }
    }
}
