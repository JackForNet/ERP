﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;
using System.Data.Linq.SqlClient;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public StaffVO GetStaffByID(int staffID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where t.Staff_ID.Equals(staffID)
                select new { t, p.Position_Name, d.Department_Name };

            StaffVO obj = null;

            if (query.Count() > 0)
            {
                foreach (var item in query)
                {
                    obj = item.t;
                    obj.Position_Name = item.Position_Name;
                    obj.Department_Name = item.Department_Name;
                }
            }

            return obj;
        }

        public StaffVO GetStaffByAccountID(int accountID)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Account_ID.Equals(accountID)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public List<StaffVO> GetStaffDMByDepartID(int departID, string name, DateTime date)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where p.Department_ID.Equals(departID)
                    && (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && (CommonHelper.CheckPositionAttendance().Contains(p.Title_ID) || (CommonHelper.CheckPositionDirectorAttendance().Contains(p.Title_ID) && d.Company_ID.Equals(Config.Headquarters)))
                    && (t.Quit_Date.HasValue ? t.Quit_Date.Value.CompareTo(date) >= 0 : true)
                    && t.Entry_Date < date.AddMonths(1)
                select new { t, p.Position_Name };

            var list = query.ToList();

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in list)
            {
                StaffVO obj = item.t;
                obj.Position_Name = item.Position_Name;
                objList.Add(obj);
            }

            return objList;

        }

        public List<StaffVO> GetStaffByPositionIDs(int[] positionIDs, string name, DateTime date)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where positionIDs.Contains(a.Position_ID)
                    && (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && (t.Quit_Date.HasValue ? t.Quit_Date.Value.CompareTo(date) >= 0 : true)
                    && t.Entry_Date < date.AddMonths(1) && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select new { t, p.Position_Name };

            var list = query.ToList();

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in list)
            {
                StaffVO obj = item.t;
                obj.Position_Name = item.Position_Name;
                objList.Add(obj);
            }

            return objList;
        }

        public List<StaffVO> GetStaffByPosition(int positionID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                where a.Position_ID.Equals(positionID)
                    && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select t;
            foreach (StaffVO item in query)
            {
                item.NumberID = CommonHelper.StaffNumberLength(item.Staff_Number);
            }

            return query.ToList();
        }

        public List<StaffVO> GetAllStaffByPosition(int positionID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                where a.Position_ID.Equals(positionID)
                && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select t;
            foreach (StaffVO item in query)
            {
                item.NumberID = CommonHelper.StaffNumberLength(item.Staff_Number);
            }

            return query.ToList();
        }

        public List<StaffVO> GetStaffByName(int companyID, int departmentID, string name)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && d.Company_ID.Equals(companyID)
                    && (departmentID > 0 ? d.Department_ID.Equals(departmentID) : true)
                    && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select t;

            return query.ToList();
        }

        public List<StaffVO> GetStaffBySearch(string gender, int Invited, DateTime entryDate, DateTime endDate, string name, int companyID, int departmentID, int positionID, int[] statusIDs, int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<StaffStatusVO> status = ctx.StaffStatusTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            int start = page * size;

            List<StaffVO> objList = new List<StaffVO>();

            var query =
                from t in table
                join s in status on t.Status_ID equals s.Status_ID
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && (!gender.Equals("全部") ? t.Gender.Equals(gender) : true)
                    //&& (!entryDate.Equals(Convert.ToDateTime(Config.Default_Mini_Time)) ? t.Entry_Date.Equals(entryDate) : true)
                    && t.Entry_Date.CompareTo(entryDate) >= 0
                    && t.Entry_Date.CompareTo(endDate) <= 0
                    && (statusIDs.Length > 0 ? statusIDs.Contains(t.Status_ID) : false)
                    && (Invited > 0 ? t.Invited_ID.Equals(Invited) : true)
                    && (companyID > 0 ? d.Company_ID.Equals(companyID) : true)
                    && (departmentID > 0 ? d.Department_ID.Equals(departmentID) : true)
                    && (positionID > 0 ? p.Position_ID.Equals(positionID) : true)
                orderby t.Staff_Number
                select new { t, s.Status_Name, p.Position_Name, d.Department_Name, c.Company_Name, a.User_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                StaffVO obj = item.t;
                obj.NumberID = CommonHelper.StaffNumberLength(item.t.Staff_Number);
                obj.User_Name = item.User_Name;
                obj.Status_Name = item.Status_Name;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;
                obj.Company_Name = item.Company_Name;
                objList.Add(obj);
            }

            return objList;
        }



        public List<StaffVO> GetStaffBySearchByStaffID(int staff_Number, int companyID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<StaffStatusVO> status = ctx.StaffStatusTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            List<StaffVO> objList = new List<StaffVO>();

            var query =
                from t in table
                join s in status on t.Status_ID equals s.Status_ID
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Staff_Number.Equals(staff_Number)
                    && (companyID > 0 ? d.Company_ID.Equals(companyID) : true)
                select new { t, s.Status_Name, p.Position_Name, d.Department_Name, c.Company_Name, a.User_Name };



            foreach (var item in query)
            {
                StaffVO obj = item.t;
                obj.NumberID = CommonHelper.StaffNumberLength(item.t.Staff_Number);
                obj.User_Name = item.User_Name;
                obj.Status_Name = item.Status_Name;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;
                obj.Company_Name = item.Company_Name;
                objList.Add(obj);
            }

            return objList;
        }



        public List<StaffVO> GetRedundancyStaffBySearch(bool isQuit, DateTime quitDate, Config.StaffStatus staffStatus, string name, int companyID, int departmentID, int positionID, int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<StaffStatusVO> status = ctx.StaffStatusTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<QuitTypeVO> type = ctx.QuitTypeTable;
            int start = page * size;

            List<StaffVO> objList = new List<StaffVO>();

            var query =
                from t in table
                join s in status on t.Status_ID equals s.Status_ID
                //join ty in type on t.Quit_Type_ID equals ty.Type_ID 
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join ty in type on t.Quit_Type_ID equals ty.Type_ID into result0
                from t_ty in result0.DefaultIfEmpty()
                where (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && (!quitDate.Equals(Convert.ToDateTime(Config.Default_Mini_Time)) ? t.Quit_Date.Equals(quitDate) : true)
                    && t.Status_ID.Equals((int)staffStatus)
                    && (companyID > 0 ? d.Company_ID.Equals(companyID) : true)
                    && (departmentID > 0 ? d.Department_ID.Equals(departmentID) : true)
                    && (positionID > 0 ? p.Position_ID.Equals(positionID) : true)
                orderby isQuit ? t.Quit_Date : t.Entry_Date descending
                select new { t, s.Status_Name, p.Position_Name, d.Department_Name, Type_Name = t_ty != null ? t_ty.Type_Name : "" };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                StaffVO obj = item.t;
                obj.Status_Name = item.Status_Name;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;
                obj.Type_Name = item.Type_Name;
                objList.Add(obj);
            }

            return objList;
        }

        public void InsertStaff(StaffVO staff)
        {
            ctx.StaffTable.InsertOnSubmit(staff);
            ctx.SubmitChanges();
        }

        public void UpdateStaff(StaffVO staff)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staff.Staff_ID)
                select t;

            StaffVO item = query.First();
            item = staff;

            ctx.SubmitChanges();
        }

        public void UpdateStaffBankCard(int staffID, string bankCard)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staffID)
                select t;

            StaffVO item = query.First();
            item.BankCard = bankCard;
            ctx.SubmitChanges();
        }

        public void UpdateQuitStaff(StaffVO staff)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staff.Staff_ID)
                select t;

            StaffVO obj = query.First();
            obj.Quit_Date = staff.Quit_Date;
            obj.Quit_Reason = staff.Quit_Reason;
            obj.Quit_Type_ID = staff.Quit_Type_ID;
            obj.Status_ID = staff.Status_ID;
            ctx.SubmitChanges();
        }

        public void UpdateStaffInfo(StaffVO staff)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staff.Staff_ID)
                select t;

            StaffVO obj = query.First();
            obj.BankCard = staff.BankCard;
            obj.Mobile = staff.Mobile;
            obj.Live_Address = staff.Live_Address;
            obj.Current_Salary = staff.Current_Salary;
            obj.Entry_Date = staff.Entry_Date;
            obj.Archives_Number = staff.Archives_Number;
            obj.Sign_Date = staff.Sign_Date;

            obj.Electronic_Badge = staff.Electronic_Badge;
            obj.Photo_Numbers = staff.Photo_Numbers;
            obj.Risk_Commitment = staff.Risk_Commitment;
            obj.Profiles = staff.Profiles;
            obj.Three_Risk = staff.Three_Risk;
            obj.Five_Risk = staff.Five_Risk;
            obj.Accumulation_Fund = staff.Accumulation_Fund;
            obj.Memo = staff.Memo;


            ctx.SubmitChanges();
        }

        public void UpdateStaffProbation(int staffID, int salary, DateTime date)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staffID)
                select t;

            StaffVO item = query.First();
            item.Current_Salary = salary;
            item.Probation_Date = date;
            item.Status_ID = (int)Config.StaffStatus.Active;
            ctx.SubmitChanges();
        }



        public IDCardVO GetIDCardByID(int id)
        {
            Table<IDCardVO> table = ctx.IDCardTable;

            var query =
                from t in table
                where t.PID.Equals(id)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public int InsertExperience(WorkExperienceVO item)
        {
            ctx.WorkExperienceTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.WEID;
        }

        public List<WorkExperienceVO> GetExperienceList(int staffID)
        {
            Table<WorkExperienceVO> table = ctx.WorkExperienceTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staffID)
                select t;


            return query.ToList();
        }

        public List<StaffVO> GetStaffListByTask(int taskID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<IDCardVO> card = ctx.IDCardTable;

            var query =
                from t in table
                join c in card on t.Card_ID equals c.PID
                where t.Task_ID.Equals(taskID)
                select new { t, c.Card_Number, c.Address };

            //return query.ToList();

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in query.ToList())
            {
                StaffVO obj = item.t;
                obj.Card_Name = item.Card_Number;
                obj.Address = item.Address;

                objList.Add(obj);
            }
            return objList;

        }

        public StaffVO GetStaffByTask(int taskID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<PositionVO> position = ctx.PositionTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where t.Task_ID.Equals(taskID)
                select new { t, d.Department_Name, p.Position_Name };

            if (query.Count() == 0)
                return null;

            var item = query.First();

            StaffVO staff = item.t;
            staff.Department_Name = item.Department_Name;
            staff.Position_Name = item.Position_Name;

            return staff;
        }

        public void UpdateStaffByTask(int taskID)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            foreach (var p in query)
            {
                p.Status_ID = (int)Config.StaffStatus.OnJob;
            }

            ctx.SubmitChanges();
        }

        public List<QuitTypeVO> GetQuitType()
        {
            Table<QuitTypeVO> table = ctx.QuitTypeTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public void UpdateStaffByNumber(StaffVO staff)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staff.Staff_ID)
                select t;

            foreach (var p in query)
            {
                p.Badge_Number = staff.Badge_Number;
                p.User_ID = staff.User_ID;
                p.Area_ID = staff.Area_ID;
            }

            ctx.SubmitChanges();
        }

        public void UpdateStaffUserID(int staffID, int userID)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(staffID)
                select t;

            foreach (var p in query)
            {
                p.User_ID = userID;
            }

            ctx.SubmitChanges();
        }

        public List<StaffStatusVO> GetStaffStatus()
        {
            Table<StaffStatusVO> table = ctx.StaffStatusTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public List<StaffVO> GetStaffsByPosition(int positionID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                where a.Position_ID.Equals(positionID) && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select t;

            return query.ToList();
        }

        public List<StaffVO> GetStaffByUserIDs(int[] userIDs, int areaID, int[] user2IDs, int area2ID, int companyID, int[] titleIDs, int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            int start = page * size;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where d.Company_ID.Equals(companyID)
                    && (user2IDs.Count() == 0 ? (userIDs.Contains(t.User_ID) && t.Area_ID.Equals(areaID)) : ((user2IDs.Contains(t.User_ID) && t.Area_ID.Equals(area2ID)) || (userIDs.Contains(t.User_ID) && t.Area_ID.Equals(areaID))))
                    && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && titleIDs.Contains(p.Title_ID)
                select new { t, p.Position_Name, d.Department_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in pageQuery)
            {
                StaffVO obj = item.t;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;

                objList.Add(obj);
            }
            return objList;
        }

        public StaffVO GetStaffByUserID(int userID, int areaID)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.User_ID.Equals(userID) && t.Area_ID.Equals(areaID)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }


        public List<StaffVO> GetStaffsByUserIDs(int[] userIDs, int areaID, int[] user2IDs, int area2ID, int companyID, int[] titleIDs)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where d.Company_ID.Equals(companyID)
                    && (user2IDs.Count() == 0 ? (userIDs.Contains(t.User_ID) && t.Area_ID.Equals(areaID)) : ((user2IDs.Contains(t.User_ID) && t.Area_ID.Equals(area2ID)) || (userIDs.Contains(t.User_ID) && t.Area_ID.Equals(areaID))))
                    && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && titleIDs.Contains(p.Title_ID)
                select new { t, p.Position_Name, d.Department_Name };

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in query.ToList())
            {
                StaffVO obj = item.t;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;

                objList.Add(obj);
            }
            return objList;
        }

        public List<StaffVO> GetStaffByNameStatus(int companyID, int departmentID, string name, Config.StaffStatus status)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                    && d.Company_ID.Equals(companyID)
                    && (departmentID > 0 ? d.Department_ID.Equals(departmentID) : true)
                    && t.Status_ID.Equals((int)status)
                select t;

            return query.ToList();
        }

        public List<StaffVO> GetStaffsByDepartment(int departmentID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where p.Department_ID.Equals(departmentID) && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select t;

            return query.ToList();
        }

        public List<StaffVO> GetStaffsByAccountsTask(int[] accountIDs)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where accountIDs.Contains(t.Account_ID)
                select new { t, p.Title_ID };

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in query.ToList())
            {
                StaffVO obj = item.t;
                obj.Title_ID = item.Title_ID;

                objList.Add(obj);
            }
            return objList;
        }

        public List<StaffVO> GetStaffByName(string name)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where t.Name.Equals(name)
                    && !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select new { t, d.Department_ID };

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in query.ToList())
            {
                StaffVO obj = item.t;
                obj.Department_ID = item.Department_ID;

                objList.Add(obj);
            }
            return objList;
        }

        public List<StaffVO> GetAllStaffs()
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                //where !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select new { t, d.Department_ID, c.Company_ID };

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in query.ToList())
            {
                StaffVO obj = item.t;
                obj.Department_ID = item.Department_ID;
                obj.Company_ID = item.Company_ID;

                objList.Add(obj);
            }
            return objList;
        }

        public List<StaffVO> GetStaffByIDNumber(string number)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where a.User_Name.Equals(number)
                    && t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                select new { t, d.Department_ID, c.Company_Name, p.Position_Name, d.Department_Name };

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in query.ToList())
            {
                StaffVO obj = item.t;
                obj.Company_Name = item.Company_Name;
                obj.Department_Name = item.Department_Name;
                obj.Position_Name = item.Position_Name;
                obj.Department_ID = item.Department_ID;
                objList.Add(obj);
            }
            return objList;
        }

        public List<StaffVO> GetStaffNullBankCardBySearch(int companyID, int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<StaffStatusVO> status = ctx.StaffStatusTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            int start = page * size;

            List<StaffVO> objList = new List<StaffVO>();

            var query =
                from t in table
                join s in status on t.Status_ID equals s.Status_ID
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where !t.Status_ID.Equals((int)Config.StaffStatus.Quit)
                && (t.BankCard == null || t.BankCard.Equals(""))
                && d.Company_ID.Equals(companyID)
                select new { t, s.Status_Name, p.Position_Name, d.Department_Name, c.Company_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                StaffVO obj = item.t;
                obj.Status_Name = item.Status_Name;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;
                obj.Company_Name = item.Company_Name;
                objList.Add(obj);
            }

            return objList;
        }

        public StaffVO GetStaffInfoByStaffID(int staffID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where t.Staff_ID.Equals(staffID)
                select new { t, a.Position_ID, p.Department_ID, d.Company_ID };

            if (query.Count() == 0)
                return null;

            var item = query.First();
            StaffVO staff = item.t;
            staff.Position_ID = item.Position_ID;
            staff.Department_ID = item.Department_ID;
            staff.Company_ID = item.Company_ID;

            return staff;
        }


        public List<StaffVO> GetAllStaffRoster(string gender, int Invited, DateTime entryDate, DateTime endDate, DateTime quitDate, DateTime quitendDate, string name, string NOID, int companyID, int departmentID, int positionID, int[] statusIDs, int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<StaffStatusVO> status = ctx.StaffStatusTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            Table<StaffSalaryRecordVO> staffsalaryrecord = ctx.StaffSalaryRecordTable;
            int start = page * size;

            List<StaffVO> objList = new List<StaffVO>();
            var query =
               from t in table
               join s in status on t.Status_ID equals s.Status_ID
               join a in account on t.Account_ID equals a.Account_ID
               join p in position on a.Position_ID equals p.Position_ID
               join d in department on p.Department_ID equals d.Department_ID
               join c in company on d.Company_ID equals c.Company_ID
               where (!string.IsNullOrEmpty(name) ? SqlMethods.Like(t.Name, "%" + name + "%") : true)
                   && (!NOID.Equals("") ? a.User_Name.Equals(NOID) : true)
                   && (!gender.Equals("全部") ? t.Gender.Equals(gender) : true)
                   && t.Entry_Date.CompareTo(entryDate) >= 0
                   && t.Entry_Date.CompareTo(endDate) <= 0
                   && (statusIDs.Length > 0 ? statusIDs.Contains(t.Status_ID) : false)
                   && (Invited > 0 ? t.Invited_ID.Equals(Invited) : true)
                   && (companyID > 0 ? d.Company_ID.Equals(companyID) : true)
                   && (departmentID > 0 ? d.Department_ID.Equals(departmentID) : true)
                   && (positionID > 0 ? p.Position_ID.Equals(positionID) : true)
                   && (quitDate.CompareTo(DateTime.Parse(Config.Staff_Mini_Time)) != 0 ? t.Quit_Date >= quitDate : true)
                   && (quitendDate.CompareTo(DateTime.Parse(Config.Staff_Mini_Time)) != 0 ? t.Quit_Date <= quitendDate : true)
               orderby t.Staff_Number
               select new { t, s.Status_Name, p.Position_Name, d.Department_Name, c.Company_Name, a.User_Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);

            foreach (var item in pageQuery)
            {
                StaffVO obj = item.t;
                obj.NumberID = CommonHelper.StaffNumberLength(item.t.Staff_Number);
                obj.Status_Name = item.Status_Name;
                obj.Position_Name = item.Position_Name;
                obj.Department_Name = item.Department_Name;
                obj.Company_Name = item.Company_Name;
                obj.User_Name = item.User_Name;

                var model = (from c in staffsalaryrecord
                             where c.Staff_ID == item.t.Staff_ID
                             select c).OrderByDescending(n => n.Create_Date);
                if (model.FirstOrDefault() != null)
                {
                    obj.Salary_Date = model.FirstOrDefault().Create_Date;
                }

                objList.Add(obj);
            }

            return objList;
        }



        public List<StaffVO> GetAllStaff(int positionID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;

            var model = from c in table
                        join a in account on c.Account_ID equals a.Account_ID
                        where a.Position_ID.Equals(positionID)
                        select c;

            return model.ToList();
        }

        //在职人数
        public int GetJob_NumberByCompanyID(int CompanyID, DateTime QuitDate)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where c.Company_ID.Equals(CompanyID)
                     && t.Status_ID != 4
                     || t.Quit_Date.Value.Date >= QuitDate.Date
                     && c.Company_ID.Equals(CompanyID)
                     && t.Status_ID == 4
                select t;

            return query.Count();
        }
        //运营中心在职人数
        public int GetSeatNumberByCompanyID(int CompanyID, DateTime QuitDate)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where c.Company_ID.Equals(CompanyID)
                     && t.Status_ID != 4
                     && d.Group_ID == 2
                     || t.Quit_Date >= QuitDate
                     && c.Company_ID.Equals(CompanyID)
                     && t.Status_ID == 4
                     && d.Group_ID == 2
                select t;

            return query.Count();
        }

        //部门在职人数
        public int GetSeatNumberByDepartmentID(int DepartmentID, DateTime QuitDate)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                where d.Department_ID.Equals(DepartmentID)
                     && t.Status_ID != 4
                     || t.Quit_Date >= QuitDate
                     && d.Department_ID.Equals(DepartmentID)
                     && t.Status_ID == 4
                select t;

            return query.Count();
        }


        public StaffVO GetStaffByStaffID(int StaffID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                join d in department on p.Department_ID equals d.Department_ID
                join c in company on d.Company_ID equals c.Company_ID
                where t.Staff_ID.Equals(StaffID)
                select new { t, a, p, d, c };


            var item = query.First();

            StaffVO obj = new StaffVO();
            obj = item.t;
            obj.Company = item.c;
            obj.Department = item.d;
            obj.Position = item.p;
            obj.Account = item.a;

            return obj;
        }
        //部门所有经理
        public List<StaffVO> GetAllManagerByDepartmentID(int DepartmentID, DateTime endMonth)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;

            var model = from t in table
                        join a in account on t.Account_ID equals a.Account_ID
                        join p in position on a.Position_ID equals p.Position_ID
                        join d in department on p.Department_ID equals d.Department_ID
                        where d.Department_ID.Equals(DepartmentID)
                        && p.Title_ID.Equals(6)
                        && t.Status_ID != 4
                        || d.Department_ID.Equals(DepartmentID)
                        && p.Title_ID.Equals(6)
                        && t.Status_ID == 4
                        && t.Quit_Date >= endMonth
                        select t;

            return model.ToList();
        }



        public List<StaffVO> GetAllManagerByCompanyID(int CompanyID, int DepartmentID, DateTime endMonth, int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable;
            Table<CompanyVO> company = ctx.CompanyTable;
            int start = page * size;

            var query = from t in table
                        join a in account on t.Account_ID equals a.Account_ID
                        join p in position on a.Position_ID equals p.Position_ID
                        join d in department on p.Department_ID equals d.Department_ID
                        join c in company on d.Company_ID equals c.Company_ID
                        where (CompanyID > 0 ? c.Company_ID.Equals(CompanyID) : true) 
                        &&(DepartmentID>0? d.Department_ID.Equals(DepartmentID):true)
                        && d.Group_ID.Equals(2)
                        && p.Title_ID.Equals(6)
                        && t.Status_ID != 4
                        && c.Status_ID.Equals(Config.PositionStatus.Active)
                        || (CompanyID > 0 ? c.Company_ID.Equals(CompanyID) : true)
                        && (DepartmentID > 0 ? d.Department_ID.Equals(DepartmentID) : true)
                        && d.Group_ID.Equals(2)
                        && p.Title_ID.Equals(6)
                        && t.Status_ID == 4
                        && c.Status_ID.Equals(Config.PositionStatus.Active)
                        && t.Quit_Date >= endMonth
                        select t;

            total = query.Count();
            var pageQuery = query.Skip(start).Take(size);

            return pageQuery.ToList();
        }




        public List<StaffVO> GetAllfinancial(int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<FinancialPayorllVO> financial = ctx.FinancialPayorllTable;
            int start = page * size;

            var query = from t in table
                        join f in financial on t.Staff_Number equals f.Staff_Number
                        join a in account on t.Account_ID equals a.Account_ID
                        orderby t.Staff_Number
                        select new
                        {
                            t.Name,
                            t.BankCard,
                            f.Money,
                            a.User_Name
                        };

            total = query.Count();
            var pageQuery = query.Skip(start).Take(size);

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in pageQuery)
            {
                StaffVO obj = new StaffVO();
                obj.Name = item.Name;
                obj.BankCard = item.BankCard;
                if (item.User_Name.Length == 18)
                    obj.User_Type = "身份证";
                else
                    obj.User_Type = "台胞证";
                obj.User_Name = item.User_Name;
                obj.Money = item.Money;

                objList.Add(obj);
            }

            return objList;
        }

        public List<StaffVO> GetAllfinancial1(int page, int size, out int total)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<FinancialPayorllVO> financial = ctx.FinancialPayorllTable;
            int start = page * size;

            var query = from t in table
                        join f in financial on t.Staff_Number equals f.Staff_Number
                        join a in account on t.Account_ID equals a.Account_ID
                        orderby t.Staff_Number
                        select new
                        {
                            t.Name,
                            t.BankCard,
                            f.Money,
                            a.User_Name
                        };

            total = query.Count();
            var pageQuery = query.Skip(start).Take(size);

            List<StaffVO> objList = new List<StaffVO>();
            foreach (var item in pageQuery)
            {
                StaffVO obj = new StaffVO();
                obj.Name = item.Name;
                obj.BankCard = item.BankCard;
                if (item.User_Name.Length == 18)
                    obj.User_Type = "身份证";
                else
                    obj.User_Type = "台胞证";
                obj.User_Name = item.User_Name;
                obj.Money = item.Money;

                objList.Add(obj);
            }
            return objList;
        }


        public StaffVO GetStaffByPositionID(int PositionID)
        {
            Table<StaffVO> table = ctx.StaffTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;


            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join p in position on a.Position_ID equals p.Position_ID
                where p.Status_ID != 4
                && p.Position_ID.Equals(PositionID)
                select t;
            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public string GetStaffByStatusID(int StatusID)
        {
            Table<StaffStatusVO> table = ctx.StaffStatusTable;

            var query =
                from t in table
                where t.Status_ID.Equals(StatusID)
                select t.Status_Name;
           
            return query.First();
        }

        public int GetStaffByNumber()
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                select t.Staff_Number;
            var Number = query.Max();

            return Number;
        }

        public StaffVO GetStaffBySatffID(int satffID)
        {
            Table<StaffVO> table = ctx.StaffTable;

            var query =
                from t in table
                where t.Staff_ID.Equals(satffID)
                select t;

            return query.First();
        }

    }
}
