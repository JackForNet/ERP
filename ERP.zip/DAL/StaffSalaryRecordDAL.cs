﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertSalaryRecord(StaffSalaryRecordVO record)
        {
            ctx.StaffSalaryRecordTable.InsertOnSubmit(record);
            ctx.SubmitChanges();
            return record.PID;
        }
    }
}
