﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public int InsertStaffWorkTime(StaffWorkTimeVO StaffWorkTime)
        {
            ctx.StaffWorkTimeTable.InsertOnSubmit(StaffWorkTime);
            ctx.SubmitChanges();
            return StaffWorkTime.WID;
        }

        public List<StaffWorkTimeVO> GetStaffWorkTime()
        {
            Table<StaffWorkTimeVO> table = ctx.StaffWorkTimeTable;

            var query =
                from t in table
                where t.Status_ID.Equals((int)Config.WorkflowStatus.Active)
                select t;

            return query.ToList();

        }

        public StaffWorkTimeVO GetStaffWorkTimeByWID(int swt)
        {
            Table<StaffWorkTimeVO> table = ctx.StaffWorkTimeTable;

            var query =
                from t in table
                where t.WID.Equals(swt)
                select t;

            return query.First();

        }
    }
}
