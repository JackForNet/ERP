﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Common;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<TaskVO> GetTask()
        {
            Table<TaskVO> table = ctx.TaskTable;

            var query =
                from t in table
                select t;

            return query.ToList();
        }

        public List<TaskVO> GetTaskByWorkFlowToSpecial(int workFlowID, int Sequence, string accountIDs)
        {
            Table<TaskVO> table = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<WorkFlowVO> wf = ctx.WorkFlowTable;
            Table<TaskStatusVO> status = ctx.TaskStatusTable;
            string[] array = accountIDs.Split(',');

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join w in wf on t.WorkFlow_ID equals w.WorkFlow_ID
                join s in status on t.Status_ID equals s.Status_ID
                where (t.WorkFlow_ID.Equals(workFlowID) && t.Sequence.Equals(Sequence)
                && t.Status_ID.Equals(1)) || (t.WorkFlow_ID.Equals(workFlowID)
               && t.Sequence.Equals(Sequence)
               && array.Contains(t.Account_ID.ToString())
               && t.Status_ID.Equals(1))
                orderby t.Create_Date descending
                select new { t, a.User_Name, w.WorkFlow_Name, w.WorkFlow_Url, s.Status_Name };

            List<TaskVO> list = new List<TaskVO>();
            foreach (var item in query.ToList())
            {
                TaskVO task = item.t;
                task.User_Name = item.User_Name;
                task.WorkFlow_Name = item.WorkFlow_Name;
                task.Status_Name = item.Status_Name;
                task.WorkFlow_Url = item.WorkFlow_Url;
                list.Add(task);
            }

            return list;
        }

        public List<TaskVO> GetTaskByWorkFlowIsNotMy(int titleID, int positionID, int departmentID, int companyID)
        {
            Table<TaskVO> table = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable; 
            Table<WorkFlowVO> wf = ctx.WorkFlowTable;
            Table<WorkFlowProcessVO> process = ctx.WorkFlowProcessTable;
            Table<TaskStatusVO> status = ctx.TaskStatusTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join pos in position on a.Position_ID equals pos.Position_ID
                join d in department on pos.Department_ID equals d.Department_ID 
                join w in wf on t.WorkFlow_ID equals w.WorkFlow_ID
                join p in process on t.WorkFlow_ID equals p.WorkFlow_ID
                join s in status on t.Status_ID equals s.Status_ID
                join ss in staff on a.Account_ID equals ss.Account_ID
                where t.Sequence.Equals(p.Sequence - 1)
                    && t.Status_ID.Equals((int)Config.TaskStatus.Active)
                    && !s.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && ((pos.Department_ID.Equals(departmentID) && p.Position_Title_ID.Equals((int)Config.PositionTitle.DD))
                        || p.Position_Title_ID.Equals(titleID))
                    && !a.Position_ID.Equals(positionID)
                    && (companyID != 0 ? d.Company_ID.Equals(companyID) : true)
                orderby t.Create_Date 
                select new { t, ss.Name, w.WorkFlow_Name, p.Process_URL, s.Status_Name };

            List<TaskVO> list = new List<TaskVO>();
            foreach (var item in query.ToList())
            {
                TaskVO task = item.t;
                task.User_Name = item.Name;
                task.WorkFlow_Name = item.WorkFlow_Name;
                task.Status_Name = item.Status_Name;
                task.WorkFlow_Url = item.Process_URL;
                list.Add(task);
            }

            return list;
        }

        public List<TaskVO> GetTaskFromNotification(int titleID, int companyID)
        {
            Table<TaskVO> table = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<DepartmentVO> department = ctx.DepartmentTable; 
            Table<WorkFlowVO> wf = ctx.WorkFlowTable;
            Table<WorkFlowProcessVO> process = ctx.WorkFlowProcessTable;
            Table<TaskStatusVO> status = ctx.TaskStatusTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join pos in position on a.Position_ID equals pos.Position_ID
                join d in department on pos.Department_ID equals d.Department_ID 
                join w in wf on t.WorkFlow_ID equals w.WorkFlow_ID
                join p in process on t.WorkFlow_ID equals p.WorkFlow_ID
                join s in status on t.Status_ID equals s.Status_ID
                join ss in staff on a.Account_ID equals ss.Account_ID
                where p.Position_Title_ID.Equals(titleID)
                    && t.Sequence.Equals(p.Sequence - 1)
                    && t.Status_ID.Equals((int)Config.TaskStatus.Active)
                    && !s.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && (companyID != 0 ? d.Company_ID.Equals(companyID) : true)
                orderby t.Create_Date
                select new { t, ss.Name, w.WorkFlow_Name, p.Process_URL, s.Status_Name };

            List<TaskVO> list = new List<TaskVO>();
            foreach (var item in query.ToList())
            {
                TaskVO task = item.t;
                task.User_Name = item.Name;
                task.WorkFlow_Name = item.WorkFlow_Name;
                task.Status_Name = item.Status_Name;
                task.WorkFlow_Url = item.Process_URL;
                list.Add(task);
            }

            return list;
        }

        public List<TaskVO> GetTaskFromNotification(int titleID, int superiorID, int departmentID)
        {
            Table<TaskVO> table = ctx.TaskTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<PositionVO> position = ctx.PositionTable;
            Table<WorkFlowVO> wf = ctx.WorkFlowTable;
            Table<WorkFlowProcessVO> process = ctx.WorkFlowProcessTable;
            Table<TaskStatusVO> status = ctx.TaskStatusTable;
            Table<StaffVO> staff = ctx.StaffTable;

            var query =
                from t in table
                join a in account on t.Account_ID equals a.Account_ID
                join pos in position on a.Position_ID equals pos.Position_ID
                join w in wf on t.WorkFlow_ID equals w.WorkFlow_ID
                join p in process on t.WorkFlow_ID equals p.WorkFlow_ID 
                join s in status on t.Status_ID equals s.Status_ID 
                join ss in staff on a.Account_ID equals ss.Account_ID
                where p.Position_Title_ID.Equals(titleID)
                    && t.Sequence.Equals(p.Sequence - 1)
                    && t.Status_ID.Equals((int)Config.TaskStatus.Active)
                    && !s.Status_ID.Equals((int)Config.StaffStatus.Quit)
                    && (superiorID != 0 ? pos.Superior_ID.Equals(superiorID) : true)
                    && (departmentID != 0 ? pos.Department_ID.Equals(departmentID) : true)
                orderby t.Create_Date 
                select new { t, ss.Name, w.WorkFlow_Name, p.Process_URL, s.Status_Name };

            List<TaskVO> list = new List<TaskVO>();
            foreach (var item in query.ToList())
            {
                TaskVO task = item.t;
                task.User_Name = item.Name;
                task.WorkFlow_Name = item.WorkFlow_Name;
                task.Status_Name = item.Status_Name;
                task.WorkFlow_Url = item.Process_URL;
                list.Add(task);
            }

            return list;
        }

        public List<TaskVO> GetTaskByAccount(int accountID,string Number, int page, int size, out int total)
        {
            Table<TaskVO> table = ctx.TaskTable;
            Table<WorkFlowVO> wf = ctx.WorkFlowTable;
            Table<AccountVO> account = ctx.AccountTable;
            Table<TaskStatusVO> status = ctx.TaskStatusTable;
            Table<StaffVO> staff = ctx.StaffTable; 
            int start = page * size;

            var query =
                from t in table
                 join w in wf on t.WorkFlow_ID equals w.WorkFlow_ID 
                 join a in account on t.Account_ID equals a.Account_ID 
                 join s in status on t.Status_ID equals s.Status_ID 
                 join f in staff on t.Account_ID equals f.Account_ID 
                 where t.Account_ID.Equals(accountID)
                    && !t.Status_ID.Equals((int)Config.TaskStatus.Delete)
                    && (Number != "" ? t.Number.Equals(Number) : true)
                 orderby t.Create_Date descending
                 select new { t, w.WorkFlow_Name, w.WorkFlow_Url, a.User_Name, s.Status_Name, f.Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            List<TaskVO> list = new List<TaskVO>();
            foreach (var item in pageQuery)
            {
                TaskVO task = item.t;
                task.WorkFlow_Name = item.WorkFlow_Name;
                task.User_Name = item.Name;
                task.Status_Name = item.Status_Name;
                task.WorkFlow_Url = item.WorkFlow_Url;

                task.IsFirst = (item.t.Create_Date.Equals(item.t.Update_Date) && item.t.Status_ID.Equals((int)Config.TaskStatus.Active)) ? true : false;

                list.Add(task);
            }
            return list;
            //return query.ToList();
        }

        public List<TaskVO> GetTaskByAccount(int accountID)
        {
            Table<TaskVO> table = ctx.TaskTable;
            Table<WorkFlowVO> wf = ctx.WorkFlowTable;

            var query =
                (from t in table
                 join w in wf on t.WorkFlow_ID equals w.WorkFlow_ID
                 where t.Account_ID.Equals(accountID) && t.Status_ID.Equals((int)Config.TaskStatus.Active)
                 orderby t.Create_Date descending
                 select new { t, w.WorkFlow_Name, w.WorkFlow_Url }).Take(4);

            List<TaskVO> list = new List<TaskVO>();
            foreach (var item in query.ToList())
            {
                TaskVO task = item.t;
                task.WorkFlow_Name = item.WorkFlow_Name;
                task.WorkFlow_Url = item.WorkFlow_Url;
                list.Add(task);
            }

            return list;
        }

        public TaskVO GetTaskByID(int taskID)
        {
            Table<TaskVO> table = ctx.TaskTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public int InsertTask(TaskVO item)
        {
            ctx.TaskTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Task_ID;
        }

        public void UpdateTask(TaskVO task)
        {
            ctx.SubmitChanges();
        }

        public void DeleteTaskByID(int taskID)
        {
            Table<TaskVO> table = ctx.TaskTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                select t;

            if (query.Count() == 0)
                return;

            TaskVO obj = query.First();
            obj.Status_ID = (int)Config.TaskStatus.Delete;
            ctx.SubmitChanges();
        }
    }
}
