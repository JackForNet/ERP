﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public void InsertTaskLog(List<TaskLogVO> list)
        {
            ctx.TaskLogTable.InsertAllOnSubmit(list);
            ctx.SubmitChanges();
        }

        public int InsertTaskLog(TaskLogVO log)
        {
            ctx.TaskLogTable.InsertOnSubmit(log);
            ctx.SubmitChanges();
            return log.Log_ID;
        }

        public List<TaskLogVO> GetTop10LogByAccount(int accountID)
        {
            Table<TaskLogVO> table = ctx.TaskLogTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<WorkFlowVO> workFlow = ctx.WorkFlowTable;
            Table<WorkFlowProcessVO> process = ctx.WorkFlowProcessTable;
            Table<StaffVO> operat = ctx.StaffTable;
            Table<StaffVO> inform = ctx.StaffTable;

            var query =
                (from t in table 
                 join tk in task on t.Task_ID equals tk.Task_ID 
                 join wf in workFlow on tk.WorkFlow_ID equals wf.WorkFlow_ID 
                 join pro in process on t.Process_ID equals pro.Process_ID 
                 join op in operat on t.Operator_ID equals op.Account_ID
                 join im in inform on tk.Account_ID equals im.Account_ID 
                 where t.Inform_ID.Equals(accountID) 
                 orderby t.Create_Date descending
                 select new { t, wf.WorkFlow_Name, pro.Process_Name, OperatName = op.Name, InformName = im.Name }).Take(10);

            List<TaskLogVO> list = new List<TaskLogVO>();
            foreach (var item in query.ToList())
            {
                TaskLogVO log = item.t;
                log.WorkFlow_Name = item.WorkFlow_Name;
                log.Process_Name = item.Process_Name;
                log.Operat_Name = item.OperatName;
                log.Inform_Name = item.InformName;
                list.Add(log);
            }

            return list;
        }

        public List<TaskLogVO> GetLogsByAccount(int accountID, int page, int size, out int total)
        {
            Table<TaskLogVO> table = ctx.TaskLogTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<WorkFlowVO> workFlow = ctx.WorkFlowTable;
            Table<WorkFlowProcessVO> process = ctx.WorkFlowProcessTable;
            Table<StaffVO> operat = ctx.StaffTable;
            Table<StaffVO> create = ctx.StaffTable;
            int start = page * size;

            var query =
                 from t in table
                 join tk in task on t.Task_ID equals tk.Task_ID
                 join wf in workFlow on tk.WorkFlow_ID equals wf.WorkFlow_ID
                 join pro in process on t.Process_ID equals pro.Process_ID
                 join op in operat on t.Operator_ID equals op.Account_ID
                 join im in create on tk.Account_ID equals im.Account_ID
                 where t.Inform_ID.Equals(accountID)
                 orderby t.Create_Date descending
                 select new { t, wf.WorkFlow_Name, pro.Process_Name, OperatName = op.Name, InformName = im.Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            List<TaskLogVO> list = new List<TaskLogVO>();
            foreach (var item in pageQuery)
            {
                TaskLogVO obj = item.t;
                obj.WorkFlow_Name = item.WorkFlow_Name;
                obj.Process_Name = item.Process_Name;
                obj.Operat_Name = item.OperatName;
                obj.Inform_Name = item.InformName;

                list.Add(obj);
            }

            return list;
        }

        public List<int> GetAccountsByTask(int taskID)
        {
            Table<TaskLogVO> table = ctx.TaskLogTable;

            var query =
                from t in table
                where t.Task_ID.Equals(taskID)
                group t by t.Operator_ID into g
                select g;

            List<int> accountIDList = new List<int>();
            foreach(var item in query)
            {
                accountIDList.Add(item.Key);
            }

            return accountIDList;
        }

        public List<int> GetTaskLog2TaskByAccount(int accountID)
        {
            Table<TaskLogVO> table = ctx.TaskLogTable;
            Table<TaskVO> task = ctx.TaskTable;
            

            var query =
                from t in table
                join tk in task on t.Task_ID equals tk.Task_ID 
                where t.Operator_ID.Equals(accountID) && !tk.Account_ID.Equals(accountID)
                group t by t.Task_ID into g
                select g;

            List<int> taskIDList = new List<int>();
            foreach (var item in query)
            {
                taskIDList.Add(item.Key);
            }

            return taskIDList;
        }

        public List<TaskLogVO> GetLogsByAccountsTask(int accountID, int[] taskIDs, int page, int size, out int total)
        {
            Table<TaskLogVO> table = ctx.TaskLogTable;
            Table<TaskVO> task = ctx.TaskTable;
            Table<WorkFlowVO> workFlow = ctx.WorkFlowTable;
            Table<WorkFlowProcessVO> process = ctx.WorkFlowProcessTable;
            Table<StaffVO> operat = ctx.StaffTable;
            Table<StaffVO> create = ctx.StaffTable;
            int start = page * size;

            var query =
                 from t in table
                 join tk in task on t.Task_ID equals tk.Task_ID
                 join wf in workFlow on tk.WorkFlow_ID equals wf.WorkFlow_ID
                 join pro in process on t.Process_ID equals pro.Process_ID
                 join op in operat on t.Operator_ID equals op.Account_ID
                 join im in create on tk.Account_ID equals im.Account_ID
                 where t.Operator_ID.Equals(accountID) && t.Inform_ID.Equals(accountID) && taskIDs.Contains(t.Task_ID)  
                 orderby t.Create_Date descending
                 select new { t, wf.WorkFlow_Name, pro.Process_Name, pro.Process_URL, OperatName = op.Name, InformName = im.Name };

            total = query.Count();

            var pageQuery = query.Skip(start).Take(size);
            List<TaskLogVO> list = new List<TaskLogVO>();
            foreach (var item in pageQuery)
            {
                TaskLogVO obj = item.t;
                obj.WorkFlow_Name = item.WorkFlow_Name;
                obj.Process_Name = item.Process_Name;
                obj.Operat_Name = item.OperatName;
                obj.Inform_Name = item.InformName;
                obj.Process_URL = item.Process_URL;

                list.Add(obj);
            }

            return list;
        }
    }
}
