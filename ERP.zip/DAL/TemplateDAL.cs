﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public TemplateVO GetTemplateByID(int id)
        {
            Table<TemplateVO> table = ctx.TemplateTable;

            var query =
                from t in table
                where t.Template_ID.Equals(id) 
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();

        }

        public int InsertTemplate(TemplateVO item)
        {
            ctx.TemplateTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
            return item.Template_ID;
        }

        public List<TemplateVO> GetTemplates()
        {
            Table<TemplateVO> table = ctx.TemplateTable;

            var query =
                from t in table
                orderby t.Template_ID descending 
                select t;

            return query.ToList();
        }

        public void UpdateTemplate(TemplateVO template)
        {
            Table<TemplateVO> table = ctx.TemplateTable;

            var query =
                from t in table
                where t.Template_ID.Equals(template.Template_ID)
                select t;

            TemplateVO obj = query.First();
            obj = template;
            obj.Name = template.Name;
            obj.Memo = template.Memo;

            ctx.SubmitChanges();
        }

        public List<TemplateVO> GetTemplates(int companyID)
        {
            Table<TemplateVO> table = ctx.TemplateTable;

            var query =
                from t in table
                where t.Company_ID.Equals(companyID) || t.Company_ID.Equals(0) 
                orderby t.Template_ID descending
                select t;

            return query.ToList();
        }

    }
}
