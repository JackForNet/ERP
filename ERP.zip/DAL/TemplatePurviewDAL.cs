﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

using ZhongLuan.ERP.Entity;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public TemplatePurviewVO GetTemplatePurview(int TemplateID, int moduleID, int purviewID)
        {
            Table<TemplatePurviewVO> table = ctx.TemplatePurviewTable;

            var query =
                from t in table
                where t.Template_ID.Equals(TemplateID) && t.Module_ID.Equals(moduleID) && t.Purview_ID.Equals(purviewID)
                select t;

            return query.Count() > 0 ? query.First() : null;
        }

        public List<TemplatePurviewVO> GetTemplatePurview(string templateIDs)
        {
            Table<TemplatePurviewVO> table = ctx.TemplatePurviewTable;
            string[] array = templateIDs.Split(',');

            var query =
                from t in table
                where array.Contains(t.Template_ID.ToString())
                select t;

            return query.ToList();
        }

        public List<TemplatePurviewVO> GetTemplatePurview(int templateID)
        {
            Table<TemplatePurviewVO> table = ctx.TemplatePurviewTable;

            var query =
                from t in table
                where t.Template_ID.Equals(templateID)
                select t;

            return query.ToList();
        }

        public void InsertTemplatePurview(TemplatePurviewVO item)
        {
            ctx.TemplatePurviewTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void DeleteTemplatePurview(int templateID, int moduleID, int purviewID)
        {
            Table<TemplatePurviewVO> table = ctx.TemplatePurviewTable;

            var query =
                from t in table
                where t.Template_ID.Equals(templateID) && t.Module_ID.Equals(moduleID) && t.Purview_ID.Equals(purviewID)
                select t;

            if (query.Count() > 0)
            {
                TemplatePurviewVO obj = query.First();
                ctx.TemplatePurviewTable.DeleteOnSubmit(obj);
                ctx.SubmitChanges();
            }
        }
    }
}
