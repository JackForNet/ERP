﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Common;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<WorkFlowVO> GetWorkFlow()
        {
            Table<WorkFlowVO> table = ctx.WorkFlowTable;

            var query =
                from t in table
                where t.Status.Equals((int)Config.WorkflowStatus.Active)
                orderby t.WorkFlow_ID ascending
                select t;

            return query.ToList();
        }
    }
}
