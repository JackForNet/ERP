﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Common;
using ZhongLuan.ERP.Entity;

namespace ZhongLuan.ERP.DAL
{
    public partial class DataHandler
    {
        public List<WorkFlowProcessVO> GetWorkFlowProcess(int workFlowID)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.WorkFlow_ID.Equals(workFlowID)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                orderby t.Sequence ascending
                select t;

            return query.ToList();
        }

        public int GetWorkFlowProcessCounts(int workFlowID)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.WorkFlow_ID.Equals(workFlowID)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                select t;

            return query.Count();

        }

        public List<WorkFlowProcessVO> GetWorkFlowProcessByTitle(int title)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.Position_Title_ID.Equals(title)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                select t;

            return query.ToList();
        }

        public List<WorkFlowProcessVO> GetWorkFlowProcessByTitles(string titles)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;
            string[] array = titles.Split(',');
            var query =
                from t in table
                where array.Contains(t.Position_Title_ID.ToString())
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                select t;

            return query.ToList();
        }

        public WorkFlowProcessVO GetWorkFlowProcessByTask(int workFlowID, int positionTitleID)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.Position_Title_ID.Equals(positionTitleID)
                    && t.WorkFlow_ID.Equals(workFlowID)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public WorkFlowProcessVO GetWorkFlowProcessByID(int processID)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.Process_ID.Equals(processID)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public WorkFlowProcessVO GetWorkFlowProcessBySequence(int workFlowID, int sequence)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.WorkFlow_ID.Equals(workFlowID)
                    && t.Sequence.Equals(sequence)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.First();
        }

        public int GetWorkFlowProcessSequence(int workflowID)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.WorkFlow_ID.Equals(workflowID)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                orderby t.Sequence descending
                select t;

            if (query.Count() == 0)
                return 1;

            return query.First().Sequence + 1;
        }

        public void InsertWorkFlowProcess(WorkFlowProcessVO item)
        {
            ctx.WorkFlowProcessTable.InsertOnSubmit(item);
            ctx.SubmitChanges();
        }

        public void UpdateWorkFlowProcess()
        {
            ctx.SubmitChanges();
        }

        public void UpdateWorkFlowProcess(WorkFlowProcessVO item)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.Process_ID.Equals(item.Process_ID)
                select t;

            foreach (var p in query)
            {
                p.Process_Name = item.Process_Name;
                p.Sequence = item.Sequence;
                p.Process_URL = item.Process_URL;
                p.Position_Title_ID = item.Position_Title_ID;
            }

            ctx.SubmitChanges();
        }

        public void DeleteWorkFlowProcess(int processID)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.Process_ID.Equals(processID)
                select t;

            WorkFlowProcessVO obj = query.First();
            obj.Status = (int)Config.WorkflowProcessStatus.Inactive;
            ctx.SubmitChanges();
        }

        public List<WorkFlowProcessVO> GetWorkFlowProcessListByTask(int workFlowID, int positionTitleID)
        {
            Table<WorkFlowProcessVO> table = ctx.WorkFlowProcessTable;

            var query =
                from t in table
                where t.Position_Title_ID.Equals(positionTitleID)
                    && t.WorkFlow_ID.Equals(workFlowID)
                    && t.Status.Equals((int)Config.WorkflowProcessStatus.Active)
                select t;

            if (query.Count() == 0)
                return null;

            return query.ToList();
        }
    }
}
