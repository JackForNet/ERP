﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.DAL
{
    public class ZKDataHandler
    {
        //private static string conn = ConfigurationManager.ConnectionStrings["ZKTeco_2"].ConnectionString;

        public DataTable GetCheckInOutByTime(DateTime startDate, DateTime endDate, string userIDs, string DB_NAME)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            StringBuilder command = new StringBuilder();
            command.Append("SELECT * ");
            command.Append("FROM CHECKINOUT ");
            command.AppendFormat("WHERE CHECKTIME >= '{0}' ", startDate.ToString(Config.Date_Fomart));
            command.AppendFormat("AND CHECKTIME < '{0}' ", endDate.ToString(Config.Date_Fomart));
            command.AppendFormat("AND USERID IN ({0}) ", userIDs);
            //command.Append("GROUP BY Province ");
            //command.Append("ORDER BY Total DESC");
            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }

        public DataTable GetCheckInOutByUserID(DateTime startDate, DateTime endDate, int userID, string DB_NAME)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);
             
            StringBuilder command = new StringBuilder();
            command.Append("SELECT * ");
            command.Append("FROM CHECKINOUT ");
            command.AppendFormat("WHERE CHECKTIME >= '{0}' ", startDate.ToString(Config.Date_Fomart));
            command.AppendFormat("AND CHECKTIME < '{0}' ", endDate.ToString(Config.Date_Fomart));
            command.AppendFormat("AND USERID = {0} ", userID);
            command.AppendFormat("AND VERIFYCODE = 1 ");
            //command.Append("GROUP BY Province ");
            //command.Append("ORDER BY Total DESC");
            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }

        public int GetUserIDByNumber(string number, string DB_NAME)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            int user_id = 0;
            StringBuilder command = new StringBuilder();
            command.Append("SELECT USERID ");
            command.Append("FROM USERINFO ");
            command.AppendFormat("WHERE BADGENUMBER = '{0}' ", number);

            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                user_id = Convert.ToInt32(ds.Tables[0].Rows[0]["USERID"]);
            }
            return user_id;
        }

        public DataTable GetAllCheckInOutByUserID(DateTime startDate, DateTime endDate, int userID, string DB_NAME)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            StringBuilder command = new StringBuilder();
            command.Append("SELECT * ");
            command.Append("FROM CHECKINOUT ");
            command.AppendFormat("WHERE USERID = {0} ", userID);
            command.AppendFormat("AND CHECKTIME >= '{0}' ", startDate.ToString(Config.Date_Fomart));
            command.AppendFormat("AND CHECKTIME < '{0}' ", endDate.ToString(Config.Date_Fomart));
            command.AppendFormat("AND VERIFYCODE = 1 ");
            command.Append("ORDER BY CHECKTIME ");
            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }

        public DataTable Get3DaysNoCheck(string DB_NAME)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            StringBuilder command = new StringBuilder();
            command.Append("SELECT * FROM ");
            command.Append("(SELECT a.USERID, MAX(b.CHECKTIME) as LAST_CHECK ");
            command.Append("FROM USERINFO as a ");
            command.Append("LEFT JOIN CHECKINOUT as b on a.USERID = b.USERID ");
            command.Append("GROUP BY a.USERID ) as CHECK_TABLE ");
            command.Append("WHERE datediff(day, LAST_CHECK, GETDATE()) >= 3 ");
            command.Append("or LAST_CHECK is NULL ");

            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }

        public DataTable Get3DaysNoCheck(string DB_NAME, DateTime minDate)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            StringBuilder command = new StringBuilder();
            command.Append("SELECT * FROM ");
            command.Append("(SELECT a.USERID, MAX(b.CHECKTIME) as LAST_CHECK ");
            command.Append("FROM USERINFO as a ");
            command.Append("LEFT JOIN CHECKINOUT as b on a.USERID = b.USERID ");
            command.Append("GROUP BY a.USERID ) as CHECK_TABLE ");
            command.Append("WHERE LAST_CHECK < '" + minDate.ToString() + "' ");
            command.Append("or LAST_CHECK is NULL ");

            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }

        public DataTable GetYesterdayNoCheck(string DB_NAME, DateTime minDate)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            StringBuilder command = new StringBuilder();
            command.Append("SELECT * FROM USERINFO WHERE USERID NOT IN ");
            command.Append("(SELECT USERID FROM CHECKINOUT ");
            command.Append("WHERE CHECKTIME between '" + minDate.ToString() + "' and '" + minDate.AddDays(1).ToString() + "' ");
            command.Append("AND (CHECKTIME <= '" + minDate.ToString("yyyy-MM-dd") + " 09:30:59' ");
            command.Append("or CHECKTIME >= '" + minDate.ToString("yyyy-MM-dd") + " 18:30:00'))");

            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }


        public DataTable GetYesterdayNoCheck(string DB_NAME, DateTime minDate, DateTime endDate)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            StringBuilder command = new StringBuilder();
            command.Append("select COUNT(*) AS ABC from ");
            command.Append("(select USERID from [" + DB_NAME + "].[dbo].[CHECKINOUT] ");
            command.Append("where CHECKTIME >= '" + minDate.ToString("yyyy-MM-dd") + "' and CHECKTIME <= '" + endDate.ToString("yyyy-MM-dd") + "' AND VERIFYCODE =  1 ");
            command.Append(" group by USERID ) a ");
          
            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }

        public DataTable GetYesterdayNoCheckNew(string DB_NAME, DateTime minDate)
        {
            string conn = SecurityHelper.Decrypt(Config.DataBase_Key, ConfigurationManager.ConnectionStrings[DB_NAME].ConnectionString);

            StringBuilder command = new StringBuilder();
            command.Append("SELECT * FROM USERINFO WHERE USERID NOT IN ");
            command.Append("(SELECT USERID FROM ");
            command.Append(" (SELECT USERID, MAX(CHECKTIME) AS LAST_CHECK, MIN(CHECKTIME) AS FIRST_CHECK FROM CHECKINOUT ");
            command.Append("WHERE CHECKTIME between '" + minDate.ToString() + "' and '" + minDate.AddDays(1).ToString() + "' ");
            command.Append("GROUP BY USERID) AS CHECK_TABLE ");
            command.Append("WHERE FIRST_CHECK <= '" + minDate.ToString("yyyy-MM-dd") + " 09:30:59' ");
            command.Append("AND LAST_CHECK >= '" + minDate.ToString("yyyy-MM-dd") + " 18:30:00')");

            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, command.ToString());
            return ds.Tables[0];
        }


         

    }
}
