﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Abnormal")]
    public class AbnormalVO
    {
        [Column(Name = "Abnormal_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Abnormal_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Position")]
        public string Position { get; set; }

        [Column(Name = "Abnormal_Date")]
        public DateTime Abnormal_Date { get; set; }

        [Column(Name = "Abnormal_Type")]
        public int Abnormal_Type { get; set; }

        [Column(Name = "Abnormal_Reason")]
        public string Abnormal_Reason { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string Type_Name { get; set; }

        public string AbnormalDate { get; set; }

        public bool IsExamine { get; set; }

    }
}
