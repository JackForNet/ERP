﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Account")]
    public class AccountVO
    {
        [Column(Name = "Account_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Account_ID { get; set; }

        [Column(Name = "User_Name")]
        public string User_Name { get; set; }

        [Column(Name = "Password")]
        public string Password { get; set; }

        [Column(Name = "Position_ID")]
        public int Position_ID { get; set; }

        [Column(Name = "Type_ID")]
        public int Type_ID { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string Position_Name { get; set; }
        public string Status_Name { get; set; }
        public int Department_ID { get; set; }
        public int Company_ID { get; set; }

        public PositionVO Position { get; set; }
        public StaffVO Staff { get; set; }
        public List<TemplatePurviewVO> TemplatePurview { get; set; }
    }
}
