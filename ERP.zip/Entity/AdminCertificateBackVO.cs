﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Certificate_Back")]
    public class AdminCertificateBackVO
    {
        [Column(Name = "Back_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Back_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "Company")]
        public string Company { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Certificate_IDs")]
        public string Certificate_IDs { get; set; }

        [Column(Name = "Use_Date")]
        public DateTime Use_Date { get; set; }

        [Column(Name = "Back_Date")]
        public DateTime Back_Date { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public bool IsExamine { get; set; }

        public string Certificates { get; set; }
    }
}
