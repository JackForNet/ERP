﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Certificate")]
    public class AdminCertificateVO
    {
        [Column(Name = "Certificate_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Certificate_ID { get; set; }

        [Column(Name = "Certificate_Name")]
        public string Certificate_Name { get; set; }

        [Column(Name = "Certificate_Type")]
        public int Certificate_Type { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }
    }
}
