﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Company_Certificate")]
    public class AdminCompanyCertificateVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "Certificate_ID")]
        public int Certificate_ID { get; set; }

        [Column(Name = "Status")]
        public int Status { get; set; }

        public string Company_Name { get; set; }

        public string Certificate_Name { get; set; }

        public string Status_Name { get; set; }
    }
}
