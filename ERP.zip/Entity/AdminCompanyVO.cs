﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Company")]
    public class AdminCompanyVO
    {
        [Column(Name = "Company_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Company_ID { get; set; }

        [Column(Name = "Company_Name")]
        public string Company_Name { get; set; }

        [Column(Name = "Location_Company_ID")]
        public int Location_Company_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string Location_Company_Name { get; set; }
    }
}
