﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Equipment")]
    public class AdminEquipmentVO
    {
        [Column(Name = "Equipment_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Equipment_ID { get; set; }

        [Column(Name = "Item_IDs")]
        public string Item_IDs { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Operation_Date")]
        public DateTime Operation_Date { get; set; }

        [Column(Name = "Operation_Type")]
        public int Operation_Type { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public bool IsExamine { get; set; }

        public string Equipments { get; set; }
    }
}
