﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Loan")]
    public class AdminLoanVO
    {
        [Column(Name = "Loan_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Loan_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Loan_Name")]
        public string Loan_Name { get; set; }

        [Column(Name = "Amounts")]
        public double Amounts { get; set; }

        [Column(Name = "Bank_Deposit")]
        public string Bank_Deposit { get; set; }

        [Column(Name = "Bank_Account")]
        public string Bank_Account { get; set; }

        [Column(Name = "Reason")]
        public string Reason { get; set; }
        
        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Repayment_Date")]
        public DateTime Repayment_Date { get; set; }

        [Column(Name = "Real_Repayment_Date")]
        public DateTime? Real_Repayment_Date { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public bool IsExamine { get; set; }
        public bool IsApprove { get; set; }
        public string ExamineText { get; set; }

        public string Position { get; set; }

        public bool IsPrint { get; set; }

        public string DD_Name { get; set; }

        public string OM_Name { get; set; }

        public string MM_Name { get; set; }
    }
}
