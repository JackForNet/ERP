﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;


namespace ZhongLuan.ERP.Entity
{
      [Table(Name = "Admin_Payment_Type")]
   public class AdminPaymentTypeVO
    {
        [Column(Name = "Type_ID", IsPrimaryKey = true, IsDbGenerated = true)]
          public int Type_ID { get; set; }

        [Column(Name = "Type_Name")]
        public string Type_Name { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

    }
}
