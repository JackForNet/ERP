﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Payment")]
    public class AdminPaymentVO
    {
        [Column(Name = "Payment_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Payment_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Payee")]
        public string Payee { get; set; }

        [Column(Name = "Payment_Company")]
        public string Payment_Company { get; set; }

        [Column(Name = "Amounts")]
        public double Amounts { get; set; }

        [Column(Name = "Payment_Method")]
        public string Payment_Method { get; set; }

        [Column(Name = "Bank_Deposit")]
        public string Bank_Deposit { get; set; }

        [Column(Name = "Bank_Account")]
        public string Bank_Account { get; set; }

        [Column(Name = "Reason")]
        public string Reason { get; set; }

        [Column(Name = "Memo")]
        public string Memo { get; set; }

        [Column(Name = "Payment_Number")]
        public string Payment_Number { get; set; }

        [Column(Name = "Finance_Memo")]
        public string Finance_Memo { get; set; }

        [Column(Name = "Payment_Type")]
        public int Payment_Type { get; set; }

        [Column(Name = "Belong_Company_ID")]
        public int Belong_Company_ID { get; set; }

        [Column(Name = "Is_Invoice")]
        public int Is_Invoice { get; set; }

        [Column(Name = "Is_Bonus")]
        public int Is_Bonus { get; set; }
        
        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Type_ID")]
        public int Type_ID { get; set; }

        [Column(Name = "Type_Name")]
        public string Type_Name { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public int Department_ID { get; set; }
        public string Department_Name { get; set; }
        public int Company_ID { get; set; }
        public string Company_Name { get; set; }

        public string User_Name { get; set; }
        public double Achievement { get; set; }
        public double Reward { get; set; }
        public string Rank { get; set; }

        public string Department_Name1 { get; set; }
        public string User_Name1 { get; set; }
        public double Achievement1 { get; set; }
        public double Reward1 { get; set; }
        public string Rank1 { get; set; }

        public string Department_Name2 { get; set; }
        public string User_Name2 { get; set; }
        public double Achievement2 { get; set; }
        public double Reward2 { get; set; }
        public string Rank2 { get; set; }




        public bool IsExamine { get; set; }
        public bool IsApprove { get; set; }
        public string ExamineText { get; set; }

        public string Position { get; set; }

        public bool IsPrint { get; set; }

        public string DD_Name { get; set; }

        public string OM_Name { get; set; }

        public string MM_Name { get; set; }

    }
}
