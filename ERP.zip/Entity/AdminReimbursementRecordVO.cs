﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Admin_Reimbursement_Record")]
    public class AdminReimbursementRecordVO
    {
        [Column(Name = "Record_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Record_ID { get; set; }

        [Column(Name = "RID")]
        public int RID { get; set; }

        [Column(Name = "Subject")]
        public string Subject { get; set; }

        [Column(Name = "Price")]
        public double Price { get; set; }

        [Column(Name = "Memo")]
        public string Memo { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string StrStatus { get; set; }

        public int TaskID { get; set; }

        public string StaffName { get; set; }
    }
}
