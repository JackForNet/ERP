﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    public class AttendanceShowVO
    {
        public int No { get; set; }
        public int Staff_ID { get; set; }

        public string Department_Name { get; set; }

        public string Position_Name { get; set; }

        public string Staff_Number { get; set; }

        public string Name { get; set; }

        public string Day1 { get; set; }

        public string Day2 { get; set; }

        public string Day3 { get; set; }

        public string Day4 { get; set; }

        public string Day5 { get; set; }

        public string Day6 { get; set; }

        public string Day7 { get; set; }

        public string Day8 { get; set; }

        public string Day9 { get; set; }

        public string Day10 { get; set; }

        public string Day11 { get; set; }

        public string Day12 { get; set; }

        public string Day13 { get; set; }

        public string Day14 { get; set; }

        public string Day15 { get; set; }

        public string Day16 { get; set; }

        public string Day17 { get; set; }

        public string Day18 { get; set; }

        public string Day19 { get; set; }

        public string Day20 { get; set; }

        public string Day21 { get; set; }

        public string Day22 { get; set; }

        public string Day23 { get; set; }

        public string Day24 { get; set; }

        public string Day25 { get; set; }

        public string Day26 { get; set; }

        public string Day27 { get; set; }

        public string Day28 { get; set; }

        public string Day29 { get; set; }

        public string Day30 { get; set; }

        public string Day31 { get; set; }

        public int LateOrEarly { get; set; }

        public double CompassionateLeave { get; set; }

        public double SickLeave { get; set; }

        public int Absenteeism { get; set; }

        public int Train { get; set; }

        public int ShouldAttendance { get; set; }

        public double ActualAttendance { get; set; }

        public string Memo { get; set; }

        public string Sign { get; set; }
    }
}
