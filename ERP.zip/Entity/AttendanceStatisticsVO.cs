﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
   public class AttendanceStatisticsVO
    {
       public string Company_Name1 { get; set; }
       public int Total_Number1 { get; set; }
       public int Attendance_Number1 { get; set; }

       public string Company_Name2 { get; set; }
       public int Total_Number2 { get; set; }
       public int Attendance_Number2 { get; set; }

       public string Company_Name3 { get; set; }
       public int Total_Number3 { get; set; }
       public int Attendance_Number3 { get; set; }

       public string Company_Name4 { get; set; }
       public int Total_Number4 { get; set; }
       public int Attendance_Number4 { get; set; }

       public string Company_Name5 { get; set; }
       public int Total_Number5 { get; set; }
       public int Attendance_Number5 { get; set; }

       public string Company_Name6 { get; set; }
       public int Total_Number6 { get; set; }
       public int Attendance_Number6 { get; set; }

       public int Total_Summary { get; set; }
       public int Attendance_Summary { get; set; }


       public DateTime Date_Time { get; set; }
    }


   public class AttendanceViewModelVO
   {
       public int Company_ID { get; set; }
       public string Company_Name { get; set; }
       public int Attendance_Number { get; set; }

       
   }
}
