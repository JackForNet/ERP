﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Award_Shop_Record")]
    public class AwardShopRecordVO
    {
        [Column(Name = "Shop_Record_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Shop_Record_ID { get; set; }

        [Column(Name = "Shop_ID")]
        public int Shop_ID { get; set; }

        [Column(Name = "Award_ID")]
        public int Award_ID { get; set; }

        [Column(Name = "Award_Name")]
        public string Award_Name { get; set; }

        [Column(Name = "Unit_Price")]
        public double Unit_Price { get; set; }

        [Column(Name = "Number")]
        public int Number { get; set; }

        [Column(Name = "Total_Price")]
        public double Total_Price { get; set; }

        [Column(Name = "Memo")]
        public string Memo { get; set; }

        [Column(Name = "Status")]
        public int Status { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string StrStatus { get; set; }

        public int TaskID { get; set; }

        public string StaffName { get; set; }
    }
}
