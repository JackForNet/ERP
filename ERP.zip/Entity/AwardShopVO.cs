﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Award_Shop")]
    public class AwardShopVO
    {
        [Column(Name = "Shop_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Shop_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Position")]
        public string Position { get; set; }

        [Column(Name = "Customer_Name")]
        public string Customer_Name { get; set; }

        [Column(Name = "Customer_Number")]
        public string Customer_Number { get; set; }

        [Column(Name = "Customer_Address")]
        public string Customer_Address { get; set; }

        [Column(Name = "Customer_Mobile")]
        public string Customer_Mobile { get; set; }

        [Column(Name = "Award_Reason")]
        public string Award_Reason { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public bool IsExamine { get; set; }

        public bool IsApprove { get; set; }

        public string ExamineText { get; set; }

    }
}
