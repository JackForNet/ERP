﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
   public class CompanyAccountRank
    {
        public string Company_Name { get; set; }

        public int Company_ID { get; set; }

        public int total { get; set; } 

        public int Rank { get; set; }

        public int Department_ID { get; set; }
        public string Department_Name { get; set; }
    }
}
