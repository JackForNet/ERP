﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Company_Area")]
    public class CompanyAreaVO
    {
        [Column(Name = "Area_ID", IsPrimaryKey = true)]
        public int Area_ID { get; set; }

        [Column(Name = "Area_Name")]
        public string Area_Name { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "DataBase_Name")]
        public string DataBase_Name { get; set; }

        public int Max { get; set; }
        public string Company_Name { get; set; }

        public DateTime Attendance_Time { get; set; }
    }
}
