﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Company")]
    public class CompanyVO
    {
        [Column(Name = "Company_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Company_ID { get; set; }

        [Column(Name = "Company_Name")]
        public string Company_Name { get; set; }

        [Column(Name = "Abbr")]
        public string Abbr { get; set; }

        [Column(Name = "Address")]
        public string Address { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        public DepartmentVO Department { get; set; }

        public PositionVO Position { get; set; }

        
    }
}
