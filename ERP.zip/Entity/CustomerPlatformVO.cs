﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Customer_Platform")]
    public class CustomerPlatformVO
    {
        [Column(Name = "Platform_ID", IsPrimaryKey = true)]
        public int Platform_ID { get; set; }

        [Column(Name = "Platform_Name")]
        public string Platform_Name { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }
    }
}
