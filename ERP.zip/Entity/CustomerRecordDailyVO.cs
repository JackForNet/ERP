﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZhongLuan.ERP.Common;

namespace ZhongLuan.ERP.Entity
{
    public class CustomerRecordDailyVO : IComparable
    {
        public string Company_Name { get; set; }

        public string Position_Name { get; set; }

        public int Department_ID { get; set; }
        public string Department_Name { get; set; }
        public int Status_ID { get; set; }

        public string Status_Name { get; set; }

        public string User_Name { get; set; }
        public string Account { get; set; }

        public int Staff_ID { get; set; }

        public string Staff_Name { get; set; }

        public string Name { get; set; }


        public double In_Out_Money { get; set; }

        public double New_In_Out_Money { get; set; }

        public double Gross_Money { get; set; }

        public string Money_Rate { get; set; }

        public double Offset_Profit { get; set; }

        public double Position_Profit { get; set; }

        public double Sum_Profit { get; set; }

        public double End_Interest { get; set; }

        public double Get_Fee { get; set; }

        public double Get_Delay { get; set; }

        public double Income { get; set; }

        public int Customer_Count { get; set; }

        public int New_Customer_Count { get; set; }

        public string Consumption_Rate { get; set; }

        public string Staff_Number { get; set; }


        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }


        private int _SortNumber = 1;
        ///
        /// 是否使用增序方式排序.
        ///
        public bool IncreasingSort
        {
            get
            {
                if (_SortNumber > 0) return true;
                return false;
            }
            set
            {
                if (value) _SortNumber = 1;
                else
                {
                    _SortNumber = -1;
                }
            }
        }

        #region IComparable 成员

        public int CompareTo(object obj)
        {
            //按照递增的方式进行排序.
            CustomerRecordDailyVO c = obj as CustomerRecordDailyVO;

            if (CommonHelper.GetChineseNumber(c.Department_Name) > CommonHelper.GetChineseNumber(this.Department_Name))
                return -_SortNumber;
            else
                return _SortNumber;


            //int length = Math.Min(c.Department_Name.Length, this.Department_Name.Length);
            ////比较长度相同部分
            //for (int i = 0; i < length; i++)
            //{
            //    int indexc = GetSpellByOneChar(c.Department_Name[i]);
            //    int indext = GetSpellByOneChar(this.Department_Name[i]);
            //    if (indexc > indext) return -_SortNumber;
            //    if (indext > indexc)
            //    {
            //        return _SortNumber;
            //    }
            //}
            ////如果长度相同部分是一致的,那么字符串长的排在后面.
            //if (c.Department_Name.Length > this.Department_Name.Length) return -_SortNumber;
            //else
            //{
            //    return _SortNumber;
            //}
        }

        #endregion IComparable 成员

        public static int GetSpellByOneChar(char onechar)
        {
            string text = onechar.ToString();
            byte[] arrCN = Encoding.Default.GetBytes(text);
            if (arrCN.Length > 1)//分析汉字.
            {
                int area = (short)arrCN[0];
                int pos = (short)arrCN[1];
                int code = (area << 8) + pos;
                int[] areacode = { 45217, 45253, 45761, 46318, 46826, 47010, 47297, 47614, 48119, 48119, 49062, 49324, 49896, 50371, 50614, 50622, 50906, 51387, 51446, 52218, 52698, 52698, 52698, 52980, 53689, 54481 };
                for (int i = 0; i < 26; i++)
                {
                    int max = 55290;
                    if (i != 25) max = areacode[i + 1];
                    if (areacode[i] <= code && code < max)
                    {
                        return i + 200;
                    }
                }
                return 0;//其他字符
            }
            else
            {
                //将小写字母和大写字母归为一类.
                if (arrCN[0] > 94 && arrCN[0] < 123)
                {
                    return arrCN[0] - 32;
                }
                return arrCN[0];
            }
        }


    }
}
