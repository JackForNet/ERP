﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    public class CustomerRecordRankVO
    {
        public string Department_Name { get; set; }

        public int Department_ID { get; set; }

        public int Staff_ID { get; set; }

        public double In_Out_Money { get; set; }

        public int Rank { get; set; }

        public string Position_Name { get; set; }

        public string Staff_Name { get; set; }
    }
}
