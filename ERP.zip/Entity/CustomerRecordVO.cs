﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Customer_Record")]
    public class CustomerRecordVO
    {
        [Column(Name = "ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public decimal ID { get; set; }

        [Column(Name = "Customer_Account")]
        public string Customer_Account { get; set; }

        [Column(Name = "Customer_Name")]
        public string Customer_Name { get; set; }

        [Column(Name = "Platform_ID")]
        public int Platform_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Manager_ID")]
        public int Manager_ID { get; set; }

        [Column(Name = "Department_ID")]
        public int Department_ID { get; set; }

        [Column(Name = "Begin_Interest")]
        public double Begin_Interest { get; set; }

        [Column(Name = "End_Interest")]
        public double End_Interest { get; set; }

        [Column(Name = "In_Out_Money")]
        public double In_Out_Money { get; set; }

        [Column(Name = "Gross_Money")]
        public double Gross_Money { get; set; }

        [Column(Name = "Offset_Profit")]
        public double Offset_Profit { get; set; }

        [Column(Name = "Position_Profit")]
        public double Position_Profit { get; set; }

        [Column(Name = "Profit_Total")]
        public double Profit_Total { get; set; }

        [Column(Name = "Get_Fee")]
        public double Get_Fee { get; set; }

        [Column(Name = "Get_Delay")]
        public double Get_Delay { get; set; }

        [Column(Name = "Action_Date")]
        public DateTime Action_Date { get; set; }

        public string Platform_Name { get; set; }

        public string Company_Name { get; set; }

        public string Department_Name { get; set; }

        public string Staff_Name { get; set; }

        public string Manager_Name { get; set; }
    }
}
