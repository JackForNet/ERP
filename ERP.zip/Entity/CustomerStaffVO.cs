﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Customer_Staff")]
    public class CustomerStaffVO
    {
        [Column(Name = "ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int ID { get; set; }

        [Column(Name = "Account")]
        public string Account { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Manager_ID")]
        public int Manager_ID { get; set; }

        [Column(Name = "Department_ID")]
        public int Department_ID { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "Customer_Number")]
        public string Customer_Number { get; set; }

        [Column(Name = "Staff_Name")]
        public string Staff_Name { get; set; }

        [Column(Name = "Manager_Name")]
        public string Manager_Name { get; set; }

        [Column(Name = "Account_Name")]
        public string Account_Name { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Active_Date")]
        public DateTime Active_Date { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public int Rank { get; set; }
        public string Name { get; set; }
        public int Customers { get; set; }
        public string Department_Name { get; set; }
        public string Position_Name { get; set; }
        public string Company_Name { get; set; }
        public DateTime Add_Date { get; set; }
        public string Platform_Name { get; set; }
        public string Status_Name { get; set; }
        public string Staff_Number { get; set; }

    }
}
