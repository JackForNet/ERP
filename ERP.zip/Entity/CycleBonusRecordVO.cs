﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Cycle_Bonus_Record")]
    public class CycleBonusRecordVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Payment_ID")]
        public int Payment_ID { get; set; }

        [Column(Name = "Department_ID")]
        public int Department_ID { get; set; }

        [Column(Name = "Position_ID")]
        public int Position_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Achievement")]
        public double Achievement { get; set; }

        [Column(Name = "Reward")]
        public double Reward { get; set; }

        [Column(Name = "Rank")]
        public int Rank { get; set; }

        public string Department_Name { get; set; }

        public string User_Name { get; set; }

    }
}
