﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Department")]
    public class DepartmentVO
    {
        [Column(Name = "Department_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Department_ID { get; set; }

        [Column(Name = "Department_Name")]
        public string Department_Name { get; set; }

        [Column(Name = "Group_ID")]
        public int Group_ID { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        public int Staff_Count { get; set; }

        public string DepartmentType { get; set; }

        public string CompanyName { get; set; }
    }
}
