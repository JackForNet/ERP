﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Evaluation_Results")]
    public class EvaluationResultsVO
    {
        [Column(Name = "Evaluation_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Evaluation_ID { get; set; }

        [Column(Name = "Evaluation_Name")]
        public string Evaluation_Name { get; set; }
    }
}
