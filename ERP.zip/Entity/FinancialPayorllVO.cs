﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
      [Table(Name = "Financial_Payorll")]
   public class FinancialPayorllVO
    {
       [Column(Name = "FID", IsPrimaryKey = true, IsDbGenerated = true)]
       public int FID { get; set; }

       [Column(Name = "Staff_Number")]
       public int Staff_Number { get; set; }

       [Column(Name = "Money")]
       public double Money { get; set; }
    }
}
