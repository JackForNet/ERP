﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "HR_Cancel_Leave")]
    public class HRCancelLeaveVO
    {

        [Column(Name = "Cancel_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Cancel_ID { get; set; }

        [Column(Name = "Leave_ID")]
        public int Leave_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Position")]
        public string Position { get; set; }

        [Column(Name = "Cancel_Leave_Date")]
        public DateTime Leave_Date { get; set; }

        [Column(Name = "Cancel_Leave_Days")]
        public double Leave_Days { get; set; }

        [Column(Name = "Leave_Type")]
        public int? Leave_Type { get; set; }

        [Column(Name = "Cancel_Leave_Reason")]
        public string Leave_Reason { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string CancelLeaveDate { get; set; }
        public double CancelLeaveDays { get; set; }
        public bool IsExamine { get; set; }

    }
}
