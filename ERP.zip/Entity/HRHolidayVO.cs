﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "HR_Holiday")]
    public class HRHolidayVO
    {
        [Column(Name = "Holiday_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Holiday_ID { get; set; }

        [Column(Name = "Holiday_Date")]
        public DateTime Holiday_Date { get; set; }

        [Column(Name = "Holiday_Type_ID")]
        public int Holiday_Type_ID { get; set; }

        [Column(Name = "Holiday_Type_Name")]
        public string Holiday_Type_Name { get; set; }
    }
}
