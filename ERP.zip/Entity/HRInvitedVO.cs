﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "HR_Invited")]
    public class HRInvitedVO
    {
        [Column(Name = "Invited_ID", IsPrimaryKey = true)]
        public int Invited_ID { get; set; }

        [Column(Name = "Be_Invited")]
        public string Be_Invited { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

    }
}
