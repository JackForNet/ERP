﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "HR_Positive")]
    public class HRPositiveVO
    {
        [Column(Name = "Positive_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Positive_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Position")]
        public string Position { get; set; }

        [Column(Name = "Major")]
        public string Major { get; set; }

        [Column(Name = "Education")]
        public string Education { get; set; }

        [Column(Name = "Probation")]
        public string Probation { get; set; }

        [Column(Name = "Entry_Date")]
        public DateTime Entry_Date { get; set; }

        [Column(Name = "Probation_Salary")]
        public int Probation_Salary { get; set; }

        [Column(Name = "Official_Salary")]
        public int Official_Salary { get; set; }

        [Column(Name = "Evaluation_Results_ID")]
        public int Evaluation_Results_ID { get; set; }

        [Column(Name = "Evaluation_Results")]
        public string Evaluation_Results { get; set; }

        [Column(Name = "Positive_Date")]
        public DateTime? Positive_Date { get; set; }

        [Column(Name = "Advanced_Position_ID")]
        public int Advanced_Position_ID { get; set; }

        [Column(Name = "Advanced_Position")]
        public string Advanced_Position { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }
    }
}
