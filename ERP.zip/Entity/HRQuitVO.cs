﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "HR_Quit")]
    public class HRQuitVO
    {
        [Column(Name = "Quit_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Quit_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Position")]
        public string Position { get; set; }

        [Column(Name = "Entry_Date")]
        public DateTime Entry_Date { get; set; }

        [Column(Name = "Mobile")]
        public string Mobile { get; set; }

        [Column(Name = "Quit_Date")]
        public DateTime Quit_Date { get; set; }

        [Column(Name = "Quit_Type")]
        public int Quit_Type { get; set; }

        [Column(Name = "Reason")]
        public string Reason { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string Type_Name { get; set; }

        public bool IsExamine { get; set; }
    }
}
