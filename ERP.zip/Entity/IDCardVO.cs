﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "ID_Card")]
    public class IDCardVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Gender")]
        public string Gender { get; set; }

        [Column(Name = "Nation")]
        public string Nation { get; set; }

        [Column(Name = "Birthday")]
        public DateTime? Birthday { get; set; }

        [Column(Name = "Address")]
        public string Address { get; set; }

        [Column(Name = "Card_Number")]
        public string Card_Number { get; set; }

        [Column(Name = "Issuing_Office")]
        public string Issuing_Office { get; set; }

        [Column(Name = "Start_Date")]
        public DateTime? Start_Date { get; set; }

        [Column(Name = "End_Date")]
        public DateTime? End_Date { get; set; }

        [Column(Name = "Scan_Path")]
        public string Scan_Path { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }
    }
}
