﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Item_Storage")]
    public class ItemStorageVO
    {
        [Column(Name = "Record_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Record_ID { get; set; }

        [Column(Name = "Item_ID")]
        public int Item_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Quantity")]
        public int Quantity { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string Item_Name { get; set; }

        public string Type_Name { get; set; }

        public string Operation_Type { get; set; }
    }
}
