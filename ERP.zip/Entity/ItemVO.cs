﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Item")]
    public class ItemVO
    {
        [Column(Name = "Item_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Item_ID { get; set; }

        [Column(Name = "Item_Name")]
        public string Item_Name { get; set; }

        [Column(Name = "Type_ID")]
        public int Type_ID { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "Is_Apply")]
        public int Is_Apply { get; set; }

        [Column(Name = "Is_Recycle")]
        public int Is_Recycle { get; set; }

        [Column(Name = "Upper_Limit")]
        public int Upper_Limit { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string Type_Name { get; set; }

        public string Apply { get; set; }

        public string Recycle { get; set; }

        public int inventories { get; set; }

        public int intos { get; set; }

        public int inventory { get; set; }
    }
}
