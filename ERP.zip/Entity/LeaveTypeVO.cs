﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Leave_Type")]
    public class LeaveTypeVO
    {
        [Column(Name = "Type_ID", IsPrimaryKey = true)]
        public int Type_ID { get; set; }

        [Column(Name = "Type_Name")]
        public string Type_Name { get; set; }
    }
}
