﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Leave")]
    public class LeaveVO
    {
        [Column(Name = "Leave_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Leave_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Department")]
        public string Department { get; set; }

        [Column(Name = "Position")]
        public string Position { get; set; }

        [Column(Name = "Leave_Date")]
        public DateTime Leave_Date { get; set; }

        [Column(Name = "Leave_Days")]
        public double Leave_Days { get; set; }

        [Column(Name = "Leave_Type")]
        public int Leave_Type { get; set; }

        [Column(Name = "Leave_Reason")]
        public string Leave_Reason { get; set; }

        [Column(Name = "Certificate")]
        public int Certificate { get; set; }

        [Column(Name = "IsActive")]
        public int IsActive { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string Type_Name { get; set; }

        public string LeaveDate { get; set; }

        public double LeaveDays { get; set; }

        public bool IsExamine { get; set; }
    }
}
