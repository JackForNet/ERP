﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Module_Group")]
    public class ModuleGroupVO
    {
        [Column(Name = "Group_ID", IsPrimaryKey = true)]
        public int Group_ID { get; set; }

        [Column(Name = "Group_Name")]
        public string Group_Name { get; set; }

        [Column(Name = "Sort")]
        public int Sort { get; set; }

    }
}
