﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Module_Purview")]
    public class ModulePurviewVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Module_ID")]
        public int Module_ID { get; set; }

        [Column(Name = "Purview_ID")]
        public int Purview_ID { get; set; }
    }
}
