﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Module")]
    public class ModuleVO
    {
        [Column(Name = "Module_ID", IsPrimaryKey = true)]
        public int Module_ID { get; set; }

        [Column(Name = "Module_Name")]
        public string Module_Name { get; set; }

        [Column(Name = "Module_Url")]
        public string Module_Url { get; set; }

        [Column(Name = "Module_Icon")]
        public string Module_Icon { get; set; }

        [Column(Name = "Group_ID")]
        public int Group_ID { get; set; }

        [Column(Name = "Sort")]
        public int Sort { get; set; }

        public ModuleGroupVO Group { get; set; }
    }
}
