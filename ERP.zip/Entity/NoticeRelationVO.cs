﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Notice_Relation")]
    public class NoticeRelationVO
    {
        [Column(Name = "Relation_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Relation_ID { get; set; }

        [Column(Name = "Notice_ID")]
        public int Notice_ID { get; set; }

        [Column(Name = "Department_ID")]
        public int Department_ID { get; set; }

        [Column(Name = "Status")]
        public int Status { get; set; }
    }
}
