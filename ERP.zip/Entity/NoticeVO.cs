﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Notice")]
    public class NoticeVO
    {
        [Column(Name = "Notice_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Notice_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Title")]
        public string Title { get; set; }

        [Column(Name = "Substance")]
        public string Substance { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public bool IsExamine { get; set; }
        public string Departments { get; set; }
    }
}
