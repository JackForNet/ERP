﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    public class Payment_reportOV
    {
        public string Department_Name { get; set; }
        public string Company_Name { get; set; }

        public int Type_ID1 { get; set; }
        public double payment1 { get; set; }
        public double Advance1 { get; set; }

        public int Type_ID2 { get; set; }
        public double payment2 { get; set; }
        public double Advance2 { get; set; }

        public int Type_ID3 { get; set; }
        public double payment3 { get; set; }
        public double Advance3 { get; set; }

        public int Type_ID4 { get; set; }
        public double payment4 { get; set; }
        public double Advance4 { get; set; }

        public int Type_ID5 { get; set; }
        public double payment5 { get; set; }
        public double Advance5 { get; set; }

        public int Type_ID6 { get; set; }
        public double payment6 { get; set; }
        public double Advance6 { get; set; }

        public double payment { get; set; }
        public double Advance { get; set; }


    }
}
