﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Position_Item")]
    public class PositionItemVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Position_ID")]
        public int Position_ID { get; set; }

        [Column(Name = "Item_ID")]
        public int Item_ID { get; set; }
    }
}
