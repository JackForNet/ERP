﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Position_Title")]
    public class PositionTitleVO
    {
        [Column(Name = "Title_ID", IsPrimaryKey = true)]
        public int Title_ID { get; set; }

        [Column(Name = "Title_Name")]
        public string Title_Name { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }
    }
}
