﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Position")]
    public class PositionVO
    {
        [Column(Name = "Position_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Position_ID { get; set; }

        [Column(Name = "Template_ID")]
        public int Template_ID { get; set; }

        [Column(Name = "Position_Name")]
        public string Position_Name { get; set; }

        [Column(Name = "Department_ID")]
        public int Department_ID { get; set; }

        [Column(Name = "Superior_ID")]
        public int Superior_ID { get; set; }

        [Column(Name = "Title_ID")]
        public int Title_ID { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        public string Department_Name { get; set; }
        public string Status_Name { get; set; }

        public int Counts { get; set; }
    }
}
