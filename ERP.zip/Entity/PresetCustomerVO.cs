﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Preset_Customer")]
    public class PresetCustomerVO
    {
        [Column(Name = "Account", IsPrimaryKey = true)]
        public string Account { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Number")]
        public string Number { get; set; }

        [Column(Name = "Platform_ID")]
        public int Platform_ID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Manager_ID")]
        public int Manager_ID { get; set; }

        [Column(Name = "Department_ID")]
        public int Department_ID { get; set; }

        [Column(Name = "Data_URL")]
        public string Data_URL { get; set; }

        [Column(Name = "Add_Date")]
        public DateTime Add_Date { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        public string Platform_Name { get; set; }
        public string Staff_Name { get; set; }
        public string Staff_Number { get; set; }
        public string Manager_Name { get; set; }
        public string Department_Name { get; set; }
        public string Company_Name { get; set; }
        public int Company_ID { get; set; }


    }
}
