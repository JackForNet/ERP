﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Purview")]
    public class PurviewVO
    {
        [Column(Name = "Purview_ID", IsPrimaryKey = true)]
        public int Purview_ID { get; set; }

        [Column(Name = "Purview_Name")]
        public string Purview_Name { get; set; }
    }
}
