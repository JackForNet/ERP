﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Room_Reservation")]
    public class RoomReservationVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Subject")]
        public string Subject { get; set; }

        [Column(Name = "Room_ID")]
        public int Room_ID { get; set; }

        [Column(Name = "Start_Date")]
        public DateTime Start_Date { get; set; }

        [Column(Name = "End_Date")]
        public DateTime End_Date { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string CreateDate { get; set; }

        public string Room_Name { get; set; }

        public bool IsExamine { get; set; }

        public string Name { get; set; }

        public string Position { get; set; }

        public string Department { get; set; }
    }
}
