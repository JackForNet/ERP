﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Room")]
    public class RoomVO
    {
        [Column(Name = "Room_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Room_ID { get; set; }

        [Column(Name = "Room_Name")]
        public string Room_Name { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        public string Status_Name { get; set; }
    }
}
