﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Staff_Salary_Record")]
    public class StaffSalaryRecordVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Current_Salary")]
        public int? Current_Salary { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }
    }
}
