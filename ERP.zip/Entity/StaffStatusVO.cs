﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Staff_Status")]
    public class StaffStatusVO
    {
        [Column(Name = "Status_ID", IsPrimaryKey = true)]
        public int Status_ID { get; set; }

        [Column(Name = "Status_Name")]
        public string Status_Name { get; set; }
    }
}
