﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Staff")]
    public class StaffVO
    {
        [Column(Name = "Staff_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Staff_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Card_ID")]
        public int Card_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "User_ID")]
        public int User_ID { get; set; }

        [Column(Name = "Area_ID")]
        public int Area_ID { get; set; }

        [Column(Name = "WorkTime_ID")]
        public int WorkTime_ID { get; set; }

        [Column(Name = "Staff_Number")]
        public int Staff_Number { get; set; }

        [Column(Name = "Badge_Number")]
        public string Badge_Number { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Gender")]
        public string Gender { get; set; }

        [Column(Name = "Mobile")]
        public string Mobile { get; set; }

        [Column(Name = "Birthday")]
        public DateTime? Birthday { get; set; }

        [Column(Name = "Entry_Date")]
        public DateTime Entry_Date { get; set; }

        [Column(Name = "Avatar")]
        public string Avatar { get; set; }

        [Column(Name = "Huji")]
        public string Huji { get; set; }

        [Column(Name = "Huji_Type")]
        public string Huji_Type { get; set; }

        [Column(Name = "Health_Status")]
        public string Health_Status { get; set; }

        [Column(Name = "Marital_Status")]
        public string Marital_Status { get; set; }

        [Column(Name = "Fertility_Status")]
        public string Fertility_Status { get; set; }

        [Column(Name = "Live_Address")]
        public string Live_Address { get; set; }

        [Column(Name = "Graduate_School")]
        public string Graduate_School { get; set; }

        [Column(Name = "Major")]
        public string Major { get; set; }

        [Column(Name = "Education")]
        public string Education { get; set; }

        [Column(Name = "Emergency_Contact")]
        public string Emergency_Contact { get; set; }

        [Column(Name = "Emergency_Contact_Tel")]
        public string Emergency_Contact_Tel { get; set; }

        [Column(Name = "BankCard")]
        public string BankCard { get; set; }

        [Column(Name = "Archives_Number")]
        public string Archives_Number { get; set; }

        [Column(Name = "Sign_Date")]
        public DateTime? Sign_Date { get; set; }

        [Column(Name = "Probation_Salary")]
        public int? Probation_Salary { get; set; }

        [Column(Name = "Official_Salary")]
        public int? Official_Salary { get; set; }

        [Column(Name = "Current_Salary")]
        public int? Current_Salary { get; set; }

        [Column(Name = "Probation")]
        public int? Probation { get; set; }

        [Column(Name = "Probation_Date")]
        public DateTime? Probation_Date { get; set; }

        [Column(Name = "Native_Place")]
        public string Native_Place { get; set; }

        [Column(Name = "Electronic_Badge")]
        public string Electronic_Badge { get; set; }

        [Column(Name = "Photo_Numbers")]
        public int Photo_Numbers { get; set; }

        [Column(Name = "Profiles")]
        public int Profiles { get; set; }

        [Column(Name = "Three_Risk")]
        public int Three_Risk { get; set; }

        [Column(Name = "Five_Risk")]
        public int Five_Risk { get; set; }

        [Column(Name = "Accumulation_Fund")]
        public int Accumulation_Fund { get; set; }

        [Column(Name = "Risk_Commitment")]
        public int Risk_Commitment { get; set; }

        [Column(Name = "Memo")]
        public string Memo { get; set; }

        [Column(Name = "Quit_Date")]
        public DateTime? Quit_Date { get; set; }

        [Column(Name = "Quit_Reason")]
        public string Quit_Reason { get; set; }

        [Column(Name = "Quit_Type_ID")]
        public int? Quit_Type_ID { get; set; }

        [Column(Name = "Invited_ID")]
        public int Invited_ID { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

       
        public string Status_Name { get; set; }
        public string Card_Name { get; set; }
        public string Address { get; set; }
        public string Position_Name { get; set; }
        public string Department_Name { get; set; }

        public string Type_Name { get; set; }

        public DateTime Last_Check { get; set; }

        public int Title_ID { get; set; }

        public int Department_ID { get; set; }

        public int Company_ID { get; set; }

        public string User_Type { get; set; }
        public string User_Name { get; set; }

        public DateTime? Salary_Date { get; set; }

        public int Position_ID { get; set; }

        public string Company_Name { get; set; }

        public string DD_Name { get; set; }

        public string OM_Name { get; set; }

        public string MM_Name { get; set; }


        public CompanyVO Company { get; set; }
        public DepartmentVO Department { get; set; }
        public PositionVO Position { get; set; }
        public AccountVO Account { get; set; }
        public double Money { get; set; }
        public string NumberID { get; set; }


    }
}
