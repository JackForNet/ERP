﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Staff_WorkTime")]
    public class StaffWorkTimeVO
    {
         [Column(Name = "WID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int WID { get; set; }

        [Column(Name = "Start_Time")]
         public string Start_Time { get; set; }

        [Column(Name = "End_Time")]
        public string End_Time { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        
    }
}
