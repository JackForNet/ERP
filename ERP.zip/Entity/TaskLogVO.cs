﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Task_Log")]
    public class TaskLogVO
    {
        [Column(Name = "Log_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Log_ID { get; set; }

        [Column(Name = "Task_ID")]
        public int Task_ID { get; set; }

        [Column(Name = "Operator_ID")]
        public int Operator_ID { get; set; }

        [Column(Name = "Inform_ID")]
        public int Inform_ID { get; set; }

        [Column(Name = "Process_ID")]
        public int Process_ID { get; set; }

        [Column(Name = "Task_Status")]
        public int Task_Status { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        public string WorkFlow_Name { get; set; }
        public string Process_Name { get; set; }
        public string Operat_Name { get; set; }
        public string Inform_Name { get; set; }
        public string Process_URL { get; set; }
    }
}
