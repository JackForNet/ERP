﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Task")]
    public class TaskVO
    {
        [Column(Name = "Task_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Task_ID { get; set; }

        [Column(Name = "WorkFlow_ID")]
        public int WorkFlow_ID { get; set; }

        [Column(Name = "Account_ID")]
        public int Account_ID { get; set; }

        [Column(Name = "Sequence")]
        public int Sequence { get; set; }

        [Column(Name = "Remarks")]
        public string Remarks { get; set; }

        [Column(Name = "Status_ID")]
        public int Status_ID { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

        [Column(Name = "Update_Date")]
        public DateTime Update_Date { get; set; }


        [Column(Name = "Number")]
        public string Number { get; set; }

        public string WorkFlow_Name { get; set; }

        public string User_Name { get; set; }

        public string Status_Name { get; set; }

        public string WorkFlow_Url { get; set; }

        public bool IsFirst { get; set; }
    }
}
