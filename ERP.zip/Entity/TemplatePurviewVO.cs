﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Template_Purview")]
    public class TemplatePurviewVO
    {
        [Column(Name = "PID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int PID { get; set; }

        [Column(Name = "Template_ID")]
        public int Template_ID { get; set; }

        [Column(Name = "Module_ID")]
        public int Module_ID { get; set; }

        [Column(Name = "Purview_ID")]
        public int Purview_ID { get; set; }

        public string Template_Name { get; set; }
        public string Module_Name { get; set; }

    }
}
