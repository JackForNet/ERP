﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Template")]
    public class TemplateVO
    {
        [Column(Name = "Template_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Template_ID { get; set; }

        [Column(Name = "Name")]
        public string Name { get; set; }

        [Column(Name = "Memo")]
        public string Memo { get; set; }

        [Column(Name = "Company_ID")]
        public int Company_ID { get; set; }

        [Column(Name = "Status")]
        public int Status { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }

    }
}
