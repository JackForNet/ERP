﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;


namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "Work_Experience")]
    public class WorkExperienceVO
    {
        [Column(Name = "WEID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int WEID { get; set; }

        [Column(Name = "Staff_ID")]
        public int Staff_ID { get; set; }

        [Column(Name = "Start_Date")]
        public DateTime Start_Date { get; set; }

        [Column(Name = "End_Date")]
        public DateTime End_Date { get; set; }

        [Column(Name = "Work_Unit")]
        public string Work_Unit { get; set; }

        [Column(Name = "Job")]
        public string Job { get; set; }

        [Column(Name = "Cause_Change")]
        public string Cause_Change { get; set; }

        [Column(Name = "Reterence")]
        public string Reterence { get; set; }

        [Column(Name = "Reterence_Tel")]
        public string Reterence_Tel { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }
    }
}
