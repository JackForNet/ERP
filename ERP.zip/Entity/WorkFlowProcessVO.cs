﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "WorkFlow_Process")]
    public class WorkFlowProcessVO
    {
        [Column(Name = "Process_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Process_ID { get; set; }

        [Column(Name = "WorkFlow_ID")]
        public int WorkFlow_ID { get; set; }

        [Column(Name = "Process_Name")]
        public string Process_Name { get; set; }

        [Column(Name = "Process_URL")]
        public string Process_URL { get; set; }

        [Column(Name = "Remarks")]
        public string Remarks { get; set; }

        [Column(Name = "Position_Title_ID")]
        public int Position_Title_ID { get; set; }

        [Column(Name = "Exclude_Position_IDs")]
        public string Exclude_Position_IDs { get; set; }

        [Column(Name = "Sequence")]
        public int Sequence { get; set; }

        [Column(Name = "Is_Approve")]
        public int Is_Approve { get; set; }

        [Column(Name = "Status")]
        public int Status { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime CreateDate { get; set; }
    }
}
