﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.Mapping;

namespace ZhongLuan.ERP.Entity
{
    [Table(Name = "WorkFlow")]
    public class WorkFlowVO
    {
        [Column(Name = "WorkFlow_ID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int WorkFlow_ID { get; set; }

        [Column(Name = "WorkFlow_Name")]
        public string WorkFlow_Name { get; set; }

        [Column(Name = "WorkFlow_Url")]
        public string WorkFlow_Url { get; set; }

        [Column(Name = "Status")]
        public int Status { get; set; }

        [Column(Name = "Create_Date")]
        public DateTime Create_Date { get; set; }
    }
}
